import express from "express";
import path from "path";
import fs from "fs";
import os from "os";
import { createServer as createViteServer } from "vite";
import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
dotenv.config();

import {
  registerReferral,
  getReferralStatus,
  claimReferralReward,
  validateReferral,
  resetAllReferralClaims,
} from "./referralLogic.js";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Lightweight ping route for Uptime Robot (no database query)
  app.get("/api/ping", (req, res) => {
    res.json({ status: "ok", message: "Server is awake" });
  });


  const activeProxyLocks = new Set<string>();
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // Global cache-busting middleware for all /api routes
  app.use("/api", (req, res, next) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    res.setHeader("Surrogate-Control", "no-store");
    next();
  });

  const supabaseUrl =
    process.env.VITE_SUPABASE_URL || "https://placeholder.supabase.co";
  const supabaseServiceKey =
    process.env.SUPABASE_SERVICE_KEY ||
    process.env.SUPABASE_SERVICE_ROLE_KEY ||
    process.env.VITE_SUPABASE_ANON_KEY ||
    "placeholder_key";
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  const DATA_STORE_PATH = path.join(os.tmpdir(), "ahtaskpay-data-store.json");
  let hasSupabaseRedeemTables = false;
  let hasSupabaseSettingsTable = false;

  
  const syncSetting = async (key: string, value: string) => {
    try {
      const { data: existing } = await supabase
        .from("system_settings")
        .select("id")
        .eq("setting_key", key)
        .maybeSingle();

      if (existing) {
        await supabase
          .from("system_settings")
          .update({
            setting_value: value,
            updated_at: new Date().toISOString(),
          })
          .eq("setting_key", key);
      } else {
        await supabase
          .from("system_settings")
          .insert([
            {
              setting_key: key,
              setting_value: value,
              updated_at: new Date().toISOString(),
            },
          ]);
      }
    } catch(err) {
      console.error("Failed to sync setting", key, err);
    }
  };

  const getDataStore = () => {
    try {
      if (fs.existsSync(DATA_STORE_PATH)) {
        const raw = fs.readFileSync(DATA_STORE_PATH, "utf-8").trim();
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed && typeof parsed === "object") {
            return parsed;
          }
        }
      }
    } catch (err) {
      console.error("Error reading data-store.json", err);
    }
    return { system_config: [], tickets: [], advertisements: [] };
  };

  const saveDataStore = (store: any) => {
    const nextContent = JSON.stringify(store, null, 2) + "\n";
    let tmpPath: string | null = null;
    try {
      if (fs.existsSync(DATA_STORE_PATH)) {
        const currentContent = fs.readFileSync(DATA_STORE_PATH, "utf-8");
        if (currentContent === nextContent) return;
      }
      tmpPath = path.join(
        path.dirname(DATA_STORE_PATH),
        `.data-store.${process.pid}.${Date.now()}.tmp`,
      );
      fs.writeFileSync(tmpPath, nextContent, "utf-8");
      fs.renameSync(tmpPath, DATA_STORE_PATH);
      tmpPath = null;
    } catch (err) {
      console.error("Error writing data-store.json", err);
      if (tmpPath && fs.existsSync(tmpPath)) {
        try {
          fs.unlinkSync(tmpPath);
        } catch {}
      }
    }
  };

  // Telegram Multi-Bot & Topic Notification Engine
  const TELEGRAM_TOPIC_KEYS = [
    "submission",
    "withdraw",
    "deposit",
    "registration",
    "login",
    "profile_update",
    "account_deletion",
    "support",
    "job_post",
    "job_edit",
    "job_delete_request",
    "ad_post",
    "balance_transfer",
    "redeem_code",
    "referral",
  ] as const;
  type TelegramTopicKey = (typeof TELEGRAM_TOPIC_KEYS)[number];

  interface TelegramBotConfig {
    id: string;
    name: string;
    botToken: string;
    chatId: string;
    threadId?: string;
    enabled: boolean;
    sendMode: "all" | "selected";
    topics: Record<string, boolean>;
  }

  interface TelegramTopicControl {
    enabled: boolean;
    customTemplate: string;
  }

  interface TelegramSettings {
    globalEnabled: boolean;
    bots: TelegramBotConfig[];
    topics: Record<TelegramTopicKey, TelegramTopicControl>;
  }

  const DEFAULT_TELEGRAM_TOPIC_TEMPLATES: Record<TelegramTopicKey, string> = {
    submission:
      "📝 <b>New Job Submission</b>\n\n<b>Job:</b> {jobTitle} (ID: {jobId})\n<b>Worker:</b> {user} (ID: {serial})\n<b>Reward:</b> {amount} BDT\n<b>Status:</b> {status}",
    withdraw:
      "💸 <b>New Withdrawal Request</b>\n\n<b>User:</b> {user} (ID: {serial})\n<b>Amount:</b> {amount} BDT (Net: {netAmount} BDT)\n<b>Method:</b> {method}\n<b>Phone:</b> {phone}",
    deposit:
      "💰 <b>New Deposit Request</b>\n\n<b>User:</b> {user} (ID: {serial})\n<b>Amount:</b> {amount} BDT\n<b>Method:</b> {method}\n<b>Phone:</b> {phone}\n<b>TrxID:</b> {trxId}",
    registration:
      "🎉 <b>New Account Registration</b>\n\n<b>Name:</b> {user} (ID: {serial})\n<b>Email:</b> {email}\n<b>Phone:</b> {phone}\n<b>Reg IP:</b> <code>{ip}</code>\n<b>Details:</b> {details}",
    login:
      "🔐 <b>User Account Login</b>\n\n<b>User:</b> {user} (ID: {serial})\n<b>Email:</b> {email}\n<b>Login IP:</b> <code>{ip}</code>\n<b>Details:</b> {details}",
    profile_update:
      "👤 <b>Account Info Change / Request</b>\n\n<b>User:</b> {user} (ID: {serial})\n<b>Email:</b> {email}\n<b>IP:</b> <code>{ip}</code>\n<b>Details:</b> {details}",
    account_deletion:
      "🗑️ <b>Account Deletion Request / Update</b>\n\n<b>User:</b> {user} (ID: {serial})\n<b>Email:</b> {email}\n<b>IP:</b> <code>{ip}</code>\n<b>Status:</b> {status}\n<b>Reason / Details:</b> {details}",
    support:
      "🎫 <b>Support Message</b>\n\n<b>User:</b> {user} (ID: {serial})\n<b>Subject:</b> {subject}\n<b>Sender:</b> {sender}\n<b>Status:</b> {status}\n<b>Message:</b> {message}",
    job_post:
      "💼 <b>New Job Posted</b>\n\n<b>Poster:</b> {user} (ID: {serial})\n<b>Title:</b> {jobTitle}\n<b>Budget:</b> {amount} BDT\n<b>Details:</b> {details}",
    job_edit:
      "✏️ <b>Job Updated / Edited</b>\n\n<b>Poster:</b> {user} (ID: {serial})\n<b>Job:</b> {jobTitle} (ID: {jobId})\n<b>Details:</b> {details}",
    job_delete_request:
      "🚫 <b>Job Delete / Cancel Request</b>\n\n<b>Poster:</b> {user} (ID: {serial})\n<b>Job:</b> {jobTitle} (ID: {jobId})\n<b>Status:</b> {status}\n<b>Details:</b> {details}",
    ad_post:
      "📢 <b>Advertisement Request</b>\n\n<b>User:</b> {user} (ID: {serial})\n<b>Price:</b> {amount} BDT\n<b>Details:</b> {details}",
    balance_transfer:
      "🔄 <b>Wallet Balance Transfer</b>\n\n<b>User:</b> {user} (ID: {serial})\n<b>Amount:</b> {amount} BDT (Net: {netAmount} BDT)\n<b>Details:</b> {details}",
    redeem_code:
      "🎁 <b>Redeem Code Claimed</b>\n\n<b>User:</b> {user} (ID: {serial})\n<b>Code:</b> {code}\n<b>Reward:</b> {amount} BDT",
    referral:
      "🤝 <b>Referral Activity</b>\n\n<b>User:</b> {user} (ID: {serial})\n<b>Details:</b> {details}",
  };

  const getDefaultTelegramSettings = (): TelegramSettings => {
    const topics = {} as Record<TelegramTopicKey, TelegramTopicControl>;
    TELEGRAM_TOPIC_KEYS.forEach((key) => {
      topics[key] = { enabled: true, customTemplate: "" };
    });
    return {
      globalEnabled: true,
      bots: [],
      topics,
    };
  };

  const normalizeTelegramSettings = (raw: any): TelegramSettings => {
    const defaults = getDefaultTelegramSettings();
    if (!raw || typeof raw !== "object") return defaults;

    const bots: TelegramBotConfig[] = Array.isArray(raw.bots)
      ? raw.bots
          .filter((b: any) => b && typeof b === "object")
          .slice(0, 25)
          .map((b: any, idx: number) => {
            const topicMap: Record<string, boolean> = {};
            TELEGRAM_TOPIC_KEYS.forEach((k) => {
              topicMap[k] =
                b.topics && typeof b.topics[k] === "boolean" ? b.topics[k] : true;
            });
            return {
              id:
                typeof b.id === "string" && b.id.trim()
                  ? b.id.trim().slice(0, 64)
                  : `bot-${Date.now()}-${idx}`,
              name:
                typeof b.name === "string" && b.name.trim()
                  ? b.name.trim().slice(0, 80)
                  : `Bot ${idx + 1}`,
              botToken:
                typeof b.botToken === "string" ? b.botToken.trim().slice(0, 200) : "",
              chatId:
                typeof b.chatId === "string" || typeof b.chatId === "number"
                  ? String(b.chatId).trim().slice(0, 100)
                  : "",
              threadId:
                typeof b.threadId === "string" || typeof b.threadId === "number"
                  ? String(b.threadId).trim().slice(0, 40)
                  : "",
              enabled: b.enabled !== false,
              sendMode: b.sendMode === "selected" ? "selected" : "all",
              topics: topicMap,
            };
          })
      : [];

    const topics = { ...defaults.topics };
    if (raw.topics && typeof raw.topics === "object") {
      TELEGRAM_TOPIC_KEYS.forEach((k) => {
        const t = raw.topics[k];
        if (t && typeof t === "object") {
          topics[k] = {
            enabled: t.enabled !== false,
            customTemplate:
              typeof t.customTemplate === "string"
                ? t.customTemplate.slice(0, 2000)
                : "",
          };
        }
      });
    }

    return {
      globalEnabled: raw.globalEnabled !== false,
      bots,
      topics,
    };
  };

  const getTelegramSettings = (): TelegramSettings => {
    const store = getDataStore();
    return normalizeTelegramSettings(store.telegramSettings);
  };

  const saveTelegramSettings = async (settings: TelegramSettings) => {
    const normalized = normalizeTelegramSettings(settings);
    const store = getDataStore();
    store.telegramSettings = normalized;
    saveDataStore(store);
    if (hasSupabaseSettingsTable) {
      await syncSetting("telegram_settings", JSON.stringify(normalized));
    }
    return normalized;
  };

  const escapeTelegramHtml = (val: unknown): string => {
    const str = val === undefined || val === null ? "" : String(val);
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  };

  const renderTelegramTemplate = (
    topic: TelegramTopicKey,
    customTemplate: string,
    payload: Record<string, unknown>,
  ): string => {
    const template =
      customTemplate && customTemplate.trim()
        ? customTemplate.trim()
        : DEFAULT_TELEGRAM_TOPIC_TEMPLATES[topic];

    const values: Record<string, string> = {
      user: escapeTelegramHtml(payload.user ?? "User"),
      serial: escapeTelegramHtml(payload.serial ?? "N/A"),
      email: escapeTelegramHtml(payload.email ?? "N/A"),
      phone: escapeTelegramHtml(payload.phone ?? "N/A"),
      amount: escapeTelegramHtml(payload.amount ?? "0"),
      netAmount: escapeTelegramHtml(payload.netAmount ?? payload.amount ?? "0"),
      fee: escapeTelegramHtml(payload.fee ?? "0"),
      method: escapeTelegramHtml(payload.method ?? "N/A"),
      trxId: escapeTelegramHtml(payload.trxId ?? "N/A"),
      jobTitle: escapeTelegramHtml(payload.jobTitle ?? "N/A"),
      jobId: escapeTelegramHtml(payload.jobId ?? "N/A"),
      subject: escapeTelegramHtml(payload.subject ?? "N/A"),
      message: escapeTelegramHtml(payload.message ?? ""),
      sender: escapeTelegramHtml(payload.sender ?? "User"),
      status: escapeTelegramHtml(payload.status ?? "pending"),
      details: escapeTelegramHtml(payload.details ?? ""),
      code: escapeTelegramHtml(payload.code ?? "N/A"),
      ip: escapeTelegramHtml(payload.ip ?? "N/A"),
      time: escapeTelegramHtml(
        payload.time ?? new Date().toLocaleString("en-GB", { timeZone: "Asia/Dhaka" }),
      ),
    };

    return template.replace(/\{([a-zA-Z0-9_]+)\}/g, (match, key) =>
      key in values ? values[key] : match,
    );
  };

  const isValidTelegramBotToken = (token: string): boolean => {
    return /^[0-9]{5,20}:[A-Za-z0-9_-]{20,100}$/.test(token.trim());
  };

  const sendTelegramApiMessage = async (
    botToken: string,
    chatId: string,
    text: string,
    threadId?: string,
  ): Promise<{ ok: boolean; error?: string }> => {
    const cleanToken = botToken.trim();
    const cleanChatId = chatId.trim();
    if (!cleanToken || !cleanChatId) {
      return { ok: false, error: "Bot token and Chat ID are required" };
    }
    if (!isValidTelegramBotToken(cleanToken)) {
      return { ok: false, error: "Invalid Telegram bot token format" };
    }

    const url = `https://api.telegram.org/bot${cleanToken}/sendMessage`;
    const bodyPayload: Record<string, unknown> = {
      chat_id: cleanChatId,
      text: text.slice(0, 4096),
      parse_mode: "HTML",
    };
    if (threadId && threadId.trim() && /^\d+$/.test(threadId.trim())) {
      bodyPayload.message_thread_id = Number(threadId.trim());
    }

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(bodyPayload),
      });
      const json: any = await response.json().catch(() => ({}));
      if (!response.ok || !json.ok) {
        return {
          ok: false,
          error: json?.description || `Telegram API error (${response.status})`,
        };
      }
      return { ok: true };
    } catch (err: any) {
      return { ok: false, error: err?.message || "Network error sending to Telegram" };
    }
  };

  const dispatchTelegramEvent = async (
    topic: TelegramTopicKey,
    payload: Record<string, unknown>,
  ) => {
    try {
      const settings = getTelegramSettings();
      if (!settings.globalEnabled) return;
      const topicConfig = settings.topics[topic];
      if (topicConfig && !topicConfig.enabled) return;

      const messageText = renderTelegramTemplate(
        topic,
        topicConfig?.customTemplate || "",
        payload,
      );

      let targetBots = settings.bots.filter(
        (bot) =>
          bot.enabled &&
          bot.botToken &&
          bot.chatId &&
          (bot.sendMode !== "selected" || bot.topics?.[topic] === true),
      );

      if (
        targetBots.length === 0 &&
        settings.bots.length === 0 &&
        process.env.TELEGRAM_BOT_TOKEN &&
        process.env.TELEGRAM_CHAT_ID
      ) {
        targetBots = [
          {
            id: "env-fallback",
            name: "Env Bot",
            botToken: process.env.TELEGRAM_BOT_TOKEN,
            chatId: process.env.TELEGRAM_CHAT_ID,
            enabled: true,
            sendMode: "all",
            topics: {},
          },
        ];
      }

      if (targetBots.length === 0) return;

      await Promise.allSettled(
        targetBots.map((bot) =>
          sendTelegramApiMessage(bot.botToken, bot.chatId, messageText, bot.threadId),
        ),
      );
    } catch (err) {
      console.error(`Telegram dispatch error (${topic}):`, err);
    }
  };

  const verifyStrictAdmin = async (req: express.Request) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return null;
    const token = authHeader.replace(/^Bearer /i, "").trim();
    if (!token) return null;

    const { data, error } = await supabase.auth.getUser(token);
    const user = data?.user;
    if (error || !user) return null;

    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .maybeSingle();

    const isMaster = [
      "superadmin@taskpay.systems",
      "harunurrashid93427@gmail.com",
      "harunbhai2728@gmail.com",
    ].includes(user.email?.toLowerCase() || "");

    if (profile?.role !== "admin" && !isMaster) {
      return null;
    }
    return user;
  };

  const notifiedRegistrations = new Set<string>();

  const lookupProfileForTelegram = async (userId?: string) => {
    if (!userId) return null;
    try {
      const { data } = await supabase
        .from("profiles")
        .select("id, displayName, username, email, phone, serialNumber, last_ip_address")
        .eq("id", userId)
        .maybeSingle();
      return data;
    } catch {
      return null;
    }
  };

  const pushInAppNotification = async (
    userId: string | undefined | null,
    message: string,
    type: "approved" | "rejected" | "info" = "info",
  ) => {
    const cleanUid = String(userId || "").trim();
    const cleanMsg = String(message || "").trim();
    if (!cleanUid || !cleanMsg) return;
    try {
      const { data: prof } = await supabase
        .from("profiles")
        .select("notifications")
        .eq("id", cleanUid)
        .maybeSingle();
      if (!prof) return;
      const existingNotifs = Array.isArray(prof.notifications)
        ? [...prof.notifications]
        : [];
      existingNotifs.unshift({
        id: `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        message: cleanMsg,
        type,
        createdAt: new Date().toISOString(),
        isRead: false,
      });
      await supabase
        .from("profiles")
        .update({ notifications: existingNotifs.slice(0, 50) })
        .eq("id", cleanUid);
    } catch (err) {
      console.error("pushInAppNotification error:", err);
    }
  };

  const extractClientIp = (req: express.Request, overrideIp?: unknown): string => {
    if (typeof overrideIp === "string" && overrideIp.trim() && overrideIp.trim() !== "N/A") {
      return overrideIp.trim().slice(0, 64);
    }
    const raw = req.headers["x-forwarded-for"] || req.ip || "";
    const first = Array.isArray(raw) ? raw[0] : String(raw).split(",")[0];
    const clean = (first || "").trim().replace(/^::ffff:/, "");
    if (!clean || clean === "::1") return "127.0.0.1";
    return clean.slice(0, 64);
  };

  const loadUserIpLogs = async (): Promise<Record<string, any>> => {
    const store = getDataStore();
    if (store.userIpLogs && typeof store.userIpLogs === "object") {
      return store.userIpLogs;
    }
    try {
      const { data: row } = await supabase
        .from("system_settings")
        .select("setting_value")
        .eq("setting_key", "user_ip_logs")
        .maybeSingle();
      if (row?.setting_value) {
        const parsed = JSON.parse(row.setting_value);
        if (parsed && typeof parsed === "object") {
          store.userIpLogs = parsed;
          saveDataStore(store);
          return parsed;
        }
      }
    } catch {}
    return {};
  };

  const saveUserIpLogs = async (logs: Record<string, any>) => {
    const store = getDataStore();
    store.userIpLogs = logs;
    saveDataStore(store);
    await syncSetting("user_ip_logs", JSON.stringify(logs));
  };

  const lookupIpGeoInfo = async (ip: string) => {
    if (!ip || ip === "127.0.0.1" || ip === "::1" || ip.startsWith("192.168.") || ip.startsWith("10.")) {
      return { country: "Local / Private", city: "Localhost", regionName: "", isp: "Local Network", isVpn: false };
    }
    try {
      const controller = new AbortController();
      const t = setTimeout(() => controller.abort(), 3500);
      const r = await fetch(
        `http://ip-api.com/json/${encodeURIComponent(ip)}?fields=status,country,regionName,city,isp,proxy,hosting,query`,
        { signal: controller.signal },
      );
      clearTimeout(t);
      const j: any = await r.json().catch(() => null);
      if (j && j.status === "success") {
        return {
          country: j.country || "Unknown",
          city: j.city || "",
          regionName: j.regionName || "",
          isp: j.isp || "Unknown ISP",
          isVpn: j.proxy === true || j.hosting === true,
        };
      }
    } catch {}
    return { country: "", city: "", regionName: "", isp: "", isVpn: false };
  };

  const recordUserIpEvent = async (
    userId: string,
    eventType: "registration" | "login" | "session",
    ip: string,
    fingerprint?: string,
    userAgent?: string,
  ) => {
    if (!userId || !ip) return null;
    try {
      const logs = await loadUserIpLogs();
      const existing = logs[userId] || {
        registrationIp: null,
        registrationAt: null,
        registrationMeta: null,
        lastLoginIp: null,
        lastLoginAt: null,
        lastLoginMeta: null,
        recentIps: [],
      };

      const geo = await lookupIpGeoInfo(ip);
      const nowIso = new Date().toISOString();
      const meta = {
        country: geo.country || "",
        city: geo.city || "",
        regionName: geo.regionName || "",
        isp: geo.isp || "",
        isVpn: Boolean(geo.isVpn),
      };

      if (eventType === "registration") {
        if (!existing.registrationIp) {
          existing.registrationIp = ip;
          existing.registrationAt = nowIso;
          existing.registrationMeta = meta;
        }
        if (!existing.lastLoginIp) {
          existing.lastLoginIp = ip;
          existing.lastLoginAt = nowIso;
          existing.lastLoginMeta = meta;
        }
      } else if (eventType === "login") {
        existing.lastLoginIp = ip;
        existing.lastLoginAt = nowIso;
        existing.lastLoginMeta = meta;
        if (!existing.registrationIp) {
          existing.registrationIp = ip;
          existing.registrationAt = nowIso;
          existing.registrationMeta = meta;
        }
      } else {
        // session backfill
        if (!existing.lastLoginIp) {
          existing.lastLoginIp = ip;
          existing.lastLoginAt = nowIso;
          existing.lastLoginMeta = meta;
        }
        if (!existing.registrationIp) {
          existing.registrationIp = ip;
          existing.registrationAt = nowIso;
          existing.registrationMeta = meta;
        }
      }

      if (eventType !== "session" || (existing.recentIps || []).length === 0) {
        const entry = {
          event: eventType,
          ip,
          ...meta,
          userAgent: userAgent ? String(userAgent).slice(0, 140) : "",
          timestamp: nowIso,
        };
        existing.recentIps = [entry, ...(Array.isArray(existing.recentIps) ? existing.recentIps : [])].slice(0, 12);
      }

      logs[userId] = existing;
      await saveUserIpLogs(logs);

      const profileUpdate: Record<string, unknown> = { last_ip_address: ip };
      if (fingerprint && fingerprint.trim()) {
        profileUpdate.device_fingerprint = fingerprint.trim().slice(0, 120);
      }
      await supabase.from("profiles").update(profileUpdate).eq("id", userId);

      return { existing, geo, meta };
    } catch (err) {
      console.error("recordUserIpEvent error:", err);
      return null;
    }
  };

  const handleProxyTelegramEvents = async (
    table: string,
    method: string,
    rawPayload: any,
    user: any,
    dbEq: any,
  ) => {
    try {
      if (!rawPayload || typeof rawPayload !== "object") return;
      const item = Array.isArray(rawPayload) ? rawPayload[0] : rawPayload;
      if (!item || typeof item !== "object") return;

      if (table === "submissions" && method === "insert") {
        const actor = await lookupProfileForTelegram(user?.id);
        await dispatchTelegramEvent("submission", {
          jobId: item.jobId || item.job_id || "N/A",
          jobTitle: item.jobTitle || "Micro Job",
          user: item.workerName || actor?.displayName || user?.email || "Worker",
          serial: item.workerSerial || actor?.serialNumber || user?.id || "N/A",
          amount: item.reward ?? 0,
          status: item.status || "pending",
        });
      } else if (table === "transactions" && method === "insert") {
        const actor = await lookupProfileForTelegram(item.userId || user?.id);
        const rawType = String(item.type || "").toLowerCase();
        if (rawType === "deposit") {
          await dispatchTelegramEvent("deposit", {
            user: item.userName || actor?.displayName || user?.email || "User",
            serial: item.userSerial || actor?.serialNumber || user?.id || "N/A",
            amount: item.amount ?? 0,
            method: item.method || item.payment_method || "N/A",
            phone: item.phone || actor?.phone || "N/A",
            trxId: item.transactionId || item.referenceId || "N/A",
          });
        } else if (rawType === "withdrawal" || rawType === "withdraw") {
          await dispatchTelegramEvent("withdraw", {
            user: item.userName || actor?.displayName || user?.email || "User",
            serial: item.userSerial || actor?.serialNumber || user?.id || "N/A",
            amount: item.amount ?? 0,
            netAmount: item.finalAmount ?? item.amount ?? 0,
            fee: item.fee ?? 0,
            method: item.method || item.payment_method || "N/A",
            phone: item.phone || actor?.phone || "N/A",
          });
        }
      } else if (table === "tickets" && (method === "insert" || method === "update")) {
        const targetId = item.userId || user?.id;
        const actor = await lookupProfileForTelegram(targetId);
        if (method === "insert") {
          const initialMsg = Array.isArray(item.replies) && item.replies[0]?.text
            ? item.replies[0].text
            : "";
          await dispatchTelegramEvent("support", {
            user: actor?.displayName || user?.email || "User",
            serial: item.userSerial || actor?.serialNumber || targetId || "N/A",
            subject: item.subject || "Support Ticket",
            sender: "User",
            status: item.status || "open",
            message: initialMsg || "New support ticket created",
          });
        } else if (method === "update") {
          let ticketSubject = item.subject || "Support Ticket";
          let ticketOwnerSerial = actor?.serialNumber || "N/A";
          let ticketOwnerName = actor?.displayName || user?.email || "User";
          if (dbEq && dbEq[0] === "id" && dbEq[1]) {
            const { data: ticketRow } = await supabase
              .from("tickets")
              .select("subject, user_id, user_serial")
              .eq("id", dbEq[1])
              .maybeSingle();
            if (ticketRow) {
              ticketSubject = ticketRow.subject || ticketSubject;
              ticketOwnerSerial = ticketRow.user_serial || ticketOwnerSerial;
              if (ticketRow.user_id && ticketRow.user_id !== user?.id) {
                const owner = await lookupProfileForTelegram(ticketRow.user_id);
                if (owner?.displayName) ticketOwnerName = owner.displayName;
              }
            }
          }
          const latestReply =
            Array.isArray(item.replies) && item.replies.length > 0
              ? item.replies[item.replies.length - 1]
              : null;
          if (latestReply || item.adminReply || item.status) {
            await dispatchTelegramEvent("support", {
              user: ticketOwnerName,
              serial: ticketOwnerSerial,
              subject: ticketSubject,
              sender:
                latestReply?.sender === "admin" || item.adminReply
                  ? "Admin"
                  : "User",
              status: item.status || "open",
              message:
                latestReply?.text ||
                item.adminReply ||
                `Ticket status updated to ${item.status}`,
            });
          }
        }
      } else if (table === "jobs" && method === "insert") {
        const actor = await lookupProfileForTelegram(item.posterId || user?.id);
        await dispatchTelegramEvent("job_post", {
          user: item.posterName || actor?.displayName || user?.email || "User",
          serial: item.posterSerial || actor?.serialNumber || user?.id || "N/A",
          jobTitle: item.title || "New Job",
          amount: item.grandTotal ?? item.totalBudget ?? 0,
          details: `Reward: ${item.pricePerWork ?? 0} BDT x ${item.maxWorkers ?? 1} workers`,
        });
      } else if (table === "jobs" && method === "update") {
        const nextStatus = String(item.status || "").toLowerCase();
        if (nextStatus === "delete_requested" || nextStatus === "deleted") {
          const jobId = dbEq && dbEq[0] === "id" && dbEq[1] ? String(dbEq[1]) : item.id || "N/A";
          let jobTitle = item.title || "Micro Job";
          let posterId = user?.id;
          let extraDetails = `Status changed to ${nextStatus}`;
          if (jobId && jobId !== "N/A") {
            const { data: jobRow } = await supabase
              .from("jobs")
              .select("title, author_id, reward, slots")
              .eq("id", jobId)
              .maybeSingle();
            if (jobRow) {
              jobTitle = jobRow.title || jobTitle;
              posterId = jobRow.author_id || posterId;
              extraDetails =
                nextStatus === "delete_requested"
                  ? `User requested job deletion (Reward: ${jobRow.reward ?? 0} BDT x ${jobRow.slots ?? 1} slots)`
                  : `Job cancelled / deleted (Reward: ${jobRow.reward ?? 0} BDT x ${jobRow.slots ?? 1} slots)`;
            }
          }
          const actor = await lookupProfileForTelegram(posterId || user?.id);
          await dispatchTelegramEvent("job_delete_request", {
            user: actor?.displayName || user?.email || "User",
            serial: actor?.serialNumber || posterId || "N/A",
            jobTitle,
            jobId,
            status: nextStatus,
            details: extraDetails,
          });
        }
      } else if (table === "advertisements" && method === "insert") {
        const actor = await lookupProfileForTelegram(item.userId || user?.id);
        await dispatchTelegramEvent("ad_post", {
          user: actor?.displayName || user?.email || "User",
          serial: item.userSerial || actor?.serialNumber || user?.id || "N/A",
          amount: item.price ?? 0,
          details: `Duration: ${item.durationDays ?? 1} days | Link: ${item.link || "N/A"}`,
        });
      } else if (table === "advertisements" && method === "update") {
        if (String(item.status || "").toLowerCase() === "pending") {
          const actor = await lookupProfileForTelegram(item.userId || user?.id);
          await dispatchTelegramEvent("ad_post", {
            user: actor?.displayName || user?.email || "User",
            serial: item.userSerial || actor?.serialNumber || user?.id || "N/A",
            amount: item.price ?? 0,
            details: `Ad Renewal Request | Duration: ${item.durationDays ?? 1} days | TrxID: ${item.transactionId || "N/A"}`,
          });
        }
      } else if (table === "profiles" && method === "update") {
        const targetId =
          dbEq && dbEq[0] === "id" && dbEq[1] ? String(dbEq[1]) : user?.id;
        const actor = await lookupProfileForTelegram(targetId);

        if (item.account_status === "pending_deletion" || item.account_status === "deleted") {
          await dispatchTelegramEvent("account_deletion", {
            user: actor?.displayName || item.displayName || user?.email || "User",
            serial: actor?.serialNumber || targetId || "N/A",
            email: actor?.email || item.email || user?.email || "N/A",
            ip: actor?.last_ip_address || "N/A",
            status: item.account_status,
            details: item.deletion_reason || (item.account_status === "pending_deletion" ? "User requested account deletion" : "Account deleted"),
          });
        }

        const changedFields: string[] = [];
        if (item.displayName !== undefined) changedFields.push(`Name: ${item.displayName}`);
        if (item.username !== undefined) changedFields.push(`Username: ${item.username}`);
        if (item.phone !== undefined) changedFields.push(`Phone: ${item.phone}`);
        if (item.email !== undefined) changedFields.push(`Email: ${item.email}`);
        if (changedFields.length > 0) {
          await dispatchTelegramEvent("profile_update", {
            user: actor?.displayName || item.displayName || user?.email || "User",
            serial: actor?.serialNumber || targetId || "N/A",
            email: actor?.email || item.email || user?.email || "N/A",
            ip: actor?.last_ip_address || "N/A",
            details: changedFields.join(", "),
          });
        }
      }
    } catch (err) {
      console.error("handleProxyTelegramEvents error:", err);
    }
  };

  // Removed old system_config warning backup sync logic, we now use system_configuration table.

  // Run Supabase availability checks in the background without blocking server connection listeners
  const runStartupChecks = async () => {
    try {
      const { error: checkErr } = await supabase
        .from("redeem_codes")
        .select("id")
        .limit(1);
      if (!checkErr) {
        hasSupabaseRedeemTables = true;
        console.log("Supabase redeem_codes table is available.");
      } else {
        console.log(
          "Supabase redeem_codes table not found/available, using pure emulated fallback. Check message:",
          checkErr.message,
        );
      }
    } catch (err) {
      console.log(
        "Supabase redeem_codes check failed, using pure emulated fallback.",
      );
    }

    try {
      const { error: checkErr } = await supabase
        .from("system_settings")
        .select("id")
        .limit(1);

      if (!checkErr) {
        hasSupabaseSettingsTable = true;
        console.log("Supabase system_settings table is available.");
        
        // Re-hydrate store from system_settings
        try {
           const { data: extSnap } = await supabase.from("system_settings").select("setting_key, setting_value").in('setting_key', ['campaign_start_date', 'referral_domain_url', 'custom_banner_presets', 'telegram_settings', 'landing_stats_config', 'account_change_requests', 'user_ip_logs']);
            if (extSnap && extSnap.length > 0) {
              const store = getDataStore();
              let changed = false;
              extSnap.forEach((s: any) => {
                 if (s.setting_key === 'campaign_start_date') {
                    const nextVal = s.setting_value || null;
                    if (store.campaignStartDate !== nextVal) {
                      store.campaignStartDate = nextVal;
                      changed = true;
                    }
                 }
                 if (s.setting_key === 'referral_domain_url') {
                    if (store.referralDomainUrl !== s.setting_value) {
                      store.referralDomainUrl = s.setting_value;
                      changed = true;
                    }
                 }
                 if (s.setting_key === 'custom_banner_presets') { 
                    try {
                      const nextPresets = JSON.parse(s.setting_value);
                      if (JSON.stringify(store.customBannerPresets || []) !== JSON.stringify(nextPresets)) {
                        store.customBannerPresets = nextPresets;
                        changed = true;
                      }
                    } catch(e){} 
                 }
                 if (s.setting_key === 'telegram_settings') {
                    try {
                      const nextTg = normalizeTelegramSettings(JSON.parse(s.setting_value));
                      if (JSON.stringify(store.telegramSettings || {}) !== JSON.stringify(nextTg)) {
                        store.telegramSettings = nextTg;
                        changed = true;
                      }
                    } catch(e){}
                 }
                 if (s.setting_key === 'account_change_requests') {
                    try {
                      const nextReqs = JSON.parse(s.setting_value);
                      if (Array.isArray(nextReqs) && JSON.stringify(store.accountChangeRequests || []) !== JSON.stringify(nextReqs)) {
                        store.accountChangeRequests = nextReqs;
                        changed = true;
                      }
                    } catch(e){}
                 }
                 if (s.setting_key === 'user_ip_logs') {
                    try {
                      const nextLogs = JSON.parse(s.setting_value);
                      if (nextLogs && typeof nextLogs === 'object' && JSON.stringify(store.userIpLogs || {}) !== JSON.stringify(nextLogs)) {
                        store.userIpLogs = nextLogs;
                        changed = true;
                      }
                    } catch(e){}
                 }
                 if (s.setting_key === 'landing_stats_config') {
                    try {
                      const parsed = JSON.parse(s.setting_value);
                      if (parsed && typeof parsed === 'object') {
                        const nextMode = parsed.statsMode || 'realtime';
                        const nextUsers = Number(parsed.manualTotalUsers) || 0;
                        const nextJobs = Number(parsed.manualTotalJobs) || 0;
                        const nextTasks = Number(parsed.manualCompletedTasks) || 0;
                        const nextWithdraw = Number(parsed.manualTotalWithdraw) || 0;
                        if (
                          store.statsMode !== nextMode ||
                          (store.manualTotalUsers || 0) !== nextUsers ||
                          (store.manualTotalJobs || 0) !== nextJobs ||
                          (store.manualCompletedTasks || 0) !== nextTasks ||
                          (store.manualTotalWithdraw || 0) !== nextWithdraw
                        ) {
                          store.statsMode = nextMode;
                          store.manualTotalUsers = nextUsers;
                          store.manualTotalJobs = nextJobs;
                          store.manualCompletedTasks = nextTasks;
                          store.manualTotalWithdraw = nextWithdraw;
                          changed = true;
                        }
                      }
                    } catch(e){}
                 }
              });
              if (changed) saveDataStore(store);
           }
        } catch(e) {
           console.error("Failed to re-hydrate store", e);
        }
      } else {

        console.log(
          "Supabase system_settings table not found/available, using pure emulated fallback. Check message:",
          checkErr?.message,
        );
      }
    } catch (err) {
      console.log(
        "Supabase system_settings check failed, using pure emulated fallback.",
      );
    }

    try {
      const { data: buckets, error: bucketCheckErr } = await supabase.storage.listBuckets();
      if (bucketCheckErr) {
        console.log("Supabase storage bucket list check failed, will try creation if needed. Check message:", bucketCheckErr.message);
      } else {
        const hasBucket = buckets?.some((b: any) => b.name === "public_assets");
        if (!hasBucket) {
          console.log("public_assets bucket not found, creating bucket...");
          const { error: createErr } = await supabase.storage.createBucket("public_assets", {
            public: true,
            allowedMimeTypes: ["image/png", "image/jpeg", "image/gif", "image/webp"]
          });
          if (createErr) {
            console.log("Failed to create public_assets bucket:", createErr.message);
          } else {
            console.log("Successfully created public_assets bucket!");
          }
        } else {
          console.log("public_assets bucket is available.");
        }
      }
    } catch (err) {
      console.log("Exception during startup bucket check:", err);
    }
  };
  runStartupChecks();

  app.post("/api/resolve-login", async (req, res) => {
    try {
      const { loginInput } = req.body;
      if (!loginInput) return res.status(400).json({ error: "Missing input" });

      const { data, error } = await supabase
        .from("profiles")
        .select("email")
        .or(`username.eq.${loginInput},phone.eq.${loginInput}`)
        .maybeSingle();

      if (error) return res.status(400).json({ error: error.message });
      res.json({ email: data?.email });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Public endpoint for Landing Page Stats
  app.get("/api/landing/stats", async (req, res) => {
    try {
      const { data: config } = await supabase.from("system_configuration").select("*").eq("id", 1).maybeSingle();
      
      const store = getDataStore();
      const statsMode = store?.statsMode || "realtime";
      
      if (statsMode === "manual") {
        return res.json({
          totalUsers: store?.manualTotalUsers || 0,
          totalJobs: store?.manualTotalJobs || 0,
          completedTasks: store?.manualCompletedTasks || 0,
          totalWithdraw: store?.manualTotalWithdraw || 0,
        });
      }
      
      // Realtime stats
      const [
        { count: totalUsers },
        { count: totalJobs },
        { count: completedTasks },
        { data: withdrawals }
      ] = await Promise.all([
        supabase.from("profiles").select("*", { count: "exact", head: true }),
        supabase.from("jobs").select("*", { count: "exact", head: true }),
        supabase.from("submissions").select("*", { count: "exact", head: true }).eq("status", "approved"),
        supabase.from("transactions").select("amount").eq("type", "withdraw").in("status", ["approved", "completed"])
      ]);

      const totalWithdraw = Math.floor(withdrawals?.reduce((sum, w) => sum + (w.amount || 0), 0) || 0);

      res.json({
        totalUsers: totalUsers || 0,
        totalJobs: totalJobs || 0,
        completedTasks: completedTasks || 0,
        totalWithdraw: totalWithdraw,
      });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // Public endpoint for Landing Page Top Jobs
  app.get("/api/landing/top-jobs", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

      const { data: rawJobs, error } = await supabase
        .from("jobs")
        .select("*")
        .eq("status", "open")
        .order("reward", { ascending: false })
        .limit(18);

      if (error) throw error;

      const jobIds = (rawJobs || []).map((j: any) => j.id);
      let pendingMap = new Map<string, number>();
      let approvedMap = new Map<string, number>();

      if (jobIds.length > 0) {
        const { data: activeSubs } = await supabase
          .from("submissions")
          .select("job_id, status")
          .in("status", ["pending", "approved"])
          .in("job_id", jobIds);

        if (activeSubs) {
          for (const sub of activeSubs) {
            const jId = sub.job_id;
            if (sub.status === "pending") {
              pendingMap.set(jId, (pendingMap.get(jId) || 0) + 1);
            } else if (sub.status === "approved") {
              approvedMap.set(jId, (approvedMap.get(jId) || 0) + 1);
            }
          }
        }
      }

      const formattedJobs = (rawJobs || []).map((j: any) => {
        let extra: any = {};
        try {
          if (j.category && (j.category.startsWith("{") || j.category.startsWith("["))) {
            extra = JSON.parse(j.category);
          }
        } catch (e) {
          extra = {};
        }

        const dynamicPending = pendingMap.get(j.id) || 0;
        const dynamicApproved = approvedMap.get(j.id) || 0;
        const fallbackFilled = Number(j.slots_filled) || Number(extra.completedCount) || Number(j.completedCount) || 0;
        const filledCount = (dynamicApproved + dynamicPending > 0)
          ? (dynamicApproved + dynamicPending)
          : fallbackFilled;

        const totalSlots = Number(j.slots) || Number(extra.maxWorkers) || Number(j.maxWorkers) || 1;
        const pricePerWork = Number(j.reward) || Number(extra.pricePerWork) || Number(j.pricePerWork) || 0;
        const availableSlots = Math.max(0, totalSlots - filledCount);
        const isFull = filledCount >= totalSlots;

        return {
          id: j.id,
          title: j.title,
          description: j.description || "",
          thumbnail: j.thumbnail || extra.thumbnail || "",
          pricePerWork: pricePerWork,
          reward: pricePerWork,
          maxWorkers: totalSlots,
          totalSlots: totalSlots,
          completedCount: filledCount,
          filledSlots: filledCount,
          availableSlots: availableSlots,
          emptySlots: availableSlots,
          pendingCount: dynamicPending,
          approvedCount: dynamicApproved || fallbackFilled,
          isFull: isFull,
          autoApprove: j.autoApprove ?? extra.autoApprove ?? false,
          createdAt: j.created_at || extra.createdAt,
        };
      });

      // Sort: Jobs with open/available slots first, then by highest reward/pricePerWork
      formattedJobs.sort((a, b) => {
        if (!a.isFull && b.isFull) return -1;
        if (a.isFull && !b.isFull) return 1;
        return b.pricePerWork - a.pricePerWork;
      });

      res.json(formattedJobs.slice(0, 6));
    } catch (err) {
      console.error("Failed to fetch top jobs:", err);
      res.status(500).json({ error: "Failed to fetch top jobs" });
    }
  });

  // Public endpoint for Landing Page Leaderboard & Recent Payouts
  app.get("/api/landing/leaderboard", async (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");

      const [
        { data: profilesData },
        { data: withdrawalsData },
        { data: approvedSubsData }
      ] = await Promise.all([
        supabase
          .from("profiles")
          .select("id, displayName, username, earningBalance, role, account_status")
          .neq("role", "admin")
          .order("earningBalance", { ascending: false })
          .limit(30),
        supabase
          .from("transactions")
          .select("id, user_id, amount, method, payment_details, status, created_at")
          .eq("type", "withdraw")
          .in("status", ["approved", "completed"])
          .order("created_at", { ascending: false })
          .limit(50),
        supabase
          .from("submissions")
          .select("worker_id")
          .eq("status", "approved")
          .limit(500)
      ]);

      const withdrawByUser = new Map<string, number>();
      for (const tx of withdrawalsData || []) {
        if (tx.user_id) {
          withdrawByUser.set(tx.user_id, (withdrawByUser.get(tx.user_id) || 0) + (Number(tx.amount) || 0));
        }
      }

      const tasksByUser = new Map<string, number>();
      for (const sub of approvedSubsData || []) {
        if (sub.worker_id) {
          tasksByUser.set(sub.worker_id, (tasksByUser.get(sub.worker_id) || 0) + 1);
        }
      }

      const profileNameMap = new Map<string, string>();
      const earners = (profilesData || [])
        .filter((p: any) => p.account_status !== "deleted")
        .map((p: any) => {
          const rawName = (p.displayName || p.username || "Member").trim();
          profileNameMap.set(p.id, rawName);
          const parts = rawName.split(/\s+/).filter(Boolean);
          const initials = parts.length >= 2
            ? `${parts[0][0]}${parts[1][0]}`.toUpperCase()
            : rawName.slice(0, 2).toUpperCase();
          const totalEarned = Math.round(
            (Number(p.earningBalance) || 0) + (withdrawByUser.get(p.id) || 0)
          );
          return {
            id: p.id,
            name: rawName,
            initials: initials || "AH",
            tasksCount: tasksByUser.get(p.id) || 0,
            totalEarned,
          };
        })
        .filter((e: any) => e.totalEarned > 0)
        .sort((a: any, b: any) => b.totalEarned - a.totalEarned)
        .slice(0, 5)
        .map((e: any, index: number) => ({
          rank: index + 1,
          name: e.name,
          initials: e.initials,
          tasksCount: e.tasksCount,
          totalEarned: e.totalEarned,
        }));

      const recentList = (withdrawalsData || []).slice(0, 5);
      const missingUserIds = recentList
        .map((tx: any) => tx.user_id)
        .filter((uid: string) => uid && !profileNameMap.has(uid));

      if (missingUserIds.length > 0) {
        const { data: extraProfiles } = await supabase
          .from("profiles")
          .select("id, displayName, username")
          .in("id", missingUserIds);
        for (const ep of extraProfiles || []) {
          profileNameMap.set(ep.id, (ep.displayName || ep.username || "Member").trim());
        }
      }

      const recentPayouts = recentList.map((tx: any) => {
        let details: any = {};
        try {
          if (typeof tx.payment_details === "string") {
            details = JSON.parse(tx.payment_details);
          } else if (tx.payment_details && typeof tx.payment_details === "object") {
            details = tx.payment_details;
          }
        } catch {
          details = {};
        }
        const method = tx.method || details.method || "bKash";
        const rawUser = profileNameMap.get(tx.user_id) || "Member";
        return {
          id: tx.id,
          method,
          amount: Math.round(Number(tx.amount) || 0),
          recipient: rawUser,
          createdAt: tx.created_at,
        };
      });

      res.json({ topEarners: earners, recentPayouts });
    } catch (err) {
      console.error("Failed to fetch leaderboard:", err);
      res.status(500).json({ error: "Failed to fetch leaderboard" });
    }
  });
  // Smart Optimization: Auto-delete proof images from database 24 hours after approve/reject
  const IMAGE_RETENTION_MS = 24 * 60 * 60 * 1000;
  let isCleaningUpImages = false;
  let lastImageCleanupAt = 0;
  const cleanupExpiredSubmissionImages = async (force = false): Promise<number> => {
    if (isCleaningUpImages) return 0;
    if (!force && Date.now() - lastImageCleanupAt < 5 * 60 * 1000) return 0;

    isCleaningUpImages = true;
    let cleanedCount = 0;
    try {
      const cutoffMs = Date.now() - IMAGE_RETENTION_MS;
      const PAGE = 100;
      let from = 0;

      while (true) {
        const { data: submissions, error } = await supabase
          .from("submissions")
          .select("id, status, proof, screenshots, updated_at, created_at")
          .in("status", ["approved", "rejected"])
          .order("created_at", { ascending: true })
          .range(from, from + PAGE - 1);

        if (error) throw error;
        if (!submissions || submissions.length === 0) break;

        for (const sub of submissions) {
          let proofObj: any = {};
          try {
            if (typeof sub.proof === "string" && sub.proof.trim().startsWith("{")) {
              proofObj = JSON.parse(sub.proof);
            } else if (sub.proof && typeof sub.proof === "object") {
              proofObj = { ...sub.proof };
            } else if (typeof sub.proof === "string" && sub.proof.trim()) {
              proofObj = { proofText: sub.proof };
            }
          } catch (e) {
            proofObj = { proofText: typeof sub.proof === "string" ? sub.proof : "" };
          }

          const hasStoredScreenshots =
            (Array.isArray(proofObj.screenshots) &&
              proofObj.screenshots.some((x: any) => x && x !== "deleted")) ||
            (Array.isArray(sub.screenshots) &&
              sub.screenshots.some((x: any) => x && x !== "deleted"));

          if (proofObj.image_deleted && !hasStoredScreenshots) continue;

          const reviewTimeStr =
            proofObj.reviewedAt || sub.updated_at || sub.created_at;
          const reviewTimeMs = reviewTimeStr ? Date.parse(reviewTimeStr) : NaN;
          if (Number.isNaN(reviewTimeMs) || reviewTimeMs > cutoffMs) continue;

          proofObj.image_deleted = true;
          proofObj.image_deleted_at = new Date().toISOString();
          proofObj.screenshots = [];

          const updatePayload: any = {
            proof: JSON.stringify(proofObj),
          };
          if (Array.isArray(sub.screenshots)) {
            updatePayload.screenshots = [];
          }

          const { error: updErr } = await supabase
            .from("submissions")
            .update(updatePayload)
            .eq("id", sub.id);

          if (!updErr) {
            cleanedCount++;
          }
        }

        if (submissions.length < PAGE) break;
        from += PAGE;
      }

      lastImageCleanupAt = Date.now();
    } catch (err) {
      console.error("cleanupExpiredSubmissionImages error:", err);
    } finally {
      isCleaningUpImages = false;
    }
    return cleanedCount;
  };

  app.get("/api/clear-db-images", async (req, res) => {
    try {
      const cleanedCount = await cleanupExpiredSubmissionImages(req.query.force === "1");
      return res.json({ success: true, cleanedCount });
    } catch (err: any) {
      console.error("Clear DB images error:", err);
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/cleanup-images", async (req, res) => {
    try {
      const cleanedCount = await cleanupExpiredSubmissionImages(false);
      return res.json({ success: true, cleanedCount });
    } catch (err: any) {
      console.error("Cleanup images error:", err);
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/proxy", async (req, res) => {
    let writeLockKey = "";
    try {
      const isPublicSystemConfigFetch = req.body?.table === "system_config" && req.body?.method === "select";

      const authHeader = req.headers.authorization;
      if (!authHeader && !isPublicSystemConfigFetch) {
        return res.status(401).json({ error: "No auth header" });
      }

      let user: any = null;
      let token = "";
      
      if (authHeader) {
        token = authHeader.replace(/^Bearer /i, "");
        const authRes = await supabase.auth.getUser(token);
        user = authRes.data?.user;
        let authErr = authRes.error;

        if (authErr || !user) {
          try {
            const base64Url = token.split(".")[1];
            const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
            const buf = Buffer.from(base64, "base64");
            const payload = JSON.parse(buf.toString());
            if (payload && payload.sub) {
              user = { id: payload.sub, email: payload.email || "" } as any;
              authErr = null;
            }
          } catch (e) {}
        }

        if ((authErr || !user) && !isPublicSystemConfigFetch) {
          return res
            .status(401)
            .json({
              error:
                "Invalid token: " +
                (authErr?.message || "no user") +
                " / token was: " +
                token.substring(0, 5),
            });
        }
      }
      let profile = null;
      if (user) {
        const { data } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", user.id)
          .single();
        profile = data;
      }
      const isMaster = [
        "superadmin@taskpay.systems",
        "harunurrashid93427@gmail.com",
        "harunbhai2728@gmail.com",
      ].includes(user?.email?.toLowerCase() || "");

      const isAdmin = profile?.role === "admin" || isMaster;
      const {
        method,
        table,
        args,
        eq,
        eqs,
        single,
        match,
        maybeSingle,
        order,
        limit,
        in: inArgs,
        or: orArgs,
        notIn: notInArgs,
        neqs,
        ilike,
      } = req.body;

      let dbEq = eq;
      let dbEqs: any[] = eqs ? [...eqs] : eq ? [eq] : [];
      let dbNeqs: any[] = neqs ? [...neqs] : [];
      let dbIn = inArgs;
      let dbNotIn = notInArgs;
      let dbMatch = match;
      let dbOrder = order;
      let dbOr = orArgs;
      let dbLimit = limit;
      let memFilter: ((item: any) => boolean) | null = null;
      const rawPayloadSnapshot =
        args && args[0] ? JSON.parse(JSON.stringify(args[0])) : null;
      const pendingUserNotifications: Array<{
        userId: string;
        message: string;
        type?: "approved" | "rejected" | "info";
      }> = [];

      // Security & Idempotency Lock
      const isWrite = method && method !== "select";
      if (
        isWrite &&
        [
          "transactions",
          "submissions",
          "profiles",
          "referrals",
          "referral_campaigns",
        ].includes(table)
      ) {
        writeLockKey = `proxy:${user.id}:${table}`;
        if (activeProxyLocks.has(writeLockKey)) {
          return res
            .status(429)
            .json({
              error:
                "Your transaction write is already processing. Please wait.",
            });
        }
        activeProxyLocks.add(writeLockKey);
      }

      // --- SECURITY ENFORCEMENT (RLS REPLACEMENT) ---
      if (!isAdmin) {
        if (table === "profiles") {
          if (
            method === "select" &&
            (!dbEq || dbEq[1] !== user.id) &&
            !orArgs
          ) {
            /* Let it query others for displayName maybe? but wait, no! */
            dbEq = ["id", user.id]; // Force reading their own if select
            dbEqs = [["id", user.id]];
            req.body.eq = dbEq;
          }
          if (method === "update" && (!dbEq || dbEq[1] !== user.id))
            return res.status(403).json({ error: "Forbidden profile update" });
        } else if (table === "transactions" || table === "tickets") {
          if (method === "select") {
            let hasUserFilter = false;
            dbEqs = dbEqs.map((rule) => {
              if (rule[0] === "userId" || rule[0] === "user_id") {
                hasUserFilter = true;
                return [rule[0], user.id];
              }
              return rule;
            });
            if (!hasUserFilter) {
              dbEqs.push(["userId", user.id]);
            }
            dbEq = null; // force using dbEqs
          } else if (method === "insert") {
            const tArgs = Array.isArray(args[0]) ? args[0] : [args[0]];
            for (const t of tArgs) {
              if (t.userId !== user.id)
                return res.status(403).json({ error: "Forbidden" });
            }
          } else if (method === "update" || method === "upsert") {
            dbEqs.push(["userId", user.id]);
            dbEq = null;
          } else if (method !== "select" && method !== "insert") {
            return res
              .status(403)
              .json({ error: "Forbidden access" });
          }
        }
      }

      // Handle system configuration using Supabase mapped table
      if (table === "system_config") {
        if (!isAdmin && method !== "select")
          return res
            .status(403)
            .json({ error: "Forbidden settings modification" });

        if (method === "select") {
          const { data, error } = await supabase
            .from("system_configuration")
            .select("*")
            .eq("id", 1)
            .maybeSingle();
          if (error) return res.status(400).json({ error: error.message });
          if (data) {
            const store = getDataStore();
            const savedDomain =
              store.referralDomainUrl || "https://ahtaskpay.onrender.com";
            return res.json({
              data: {
                id: "config",
                notice: data.global_notice || "",
                minDeposit: data.min_deposit || 100,
                minWithdraw: data.min_withdraw || 20,
                withdrawalFee: data.withdrawal_fee || 10,
                jobPostingFee: data.job_service_charge || 10,
                bkashNumber: data.official_bkash || "",
                bkashMethod: data.bkash_method || "Personal",
                nagadNumber: data.official_nagad || "",
                nagadMethod: data.nagad_method || "Personal",
                depositBkashEnabled: data.deposit_bkash_enabled !== false,
                depositNagadEnabled: data.deposit_nagad_enabled !== false,
                withdrawBkashEnabled: data.withdraw_bkash_enabled !== false,
                withdrawNagadEnabled: data.withdraw_nagad_enabled !== false,
                transferEarningToDepositFee:
                  data.transfer_earning_deposit_fee || 0,
                transferDepositToEarningFee:
                  data.transfer_deposit_earning_fee || 10,
                loginTitle: data.login_title || "Welcome to TaskPay",
                loginBannerUrl: data.login_banner_url || "",
                referralBonusAmount: data.referral_bonus_amount ?? 5,
                referralValidationCriteria:
                  data.referral_validation_criteria ?? 1,
                referralValidityDays: data.referral_validity_days ?? 30,
                campaignEndDate: data.campaign_end_date || null,
                target1Referrals: data.target_1_referrals || 0,
                target1Reward: data.target_1_reward || 0,
                target2Referrals: data.target_2_referrals || 0,
                target2Reward: data.target_2_reward || 0,
                referralDomainUrl: savedDomain,
                campaignStartDate: store.campaignStartDate || null,
                customBannerPresets: store.customBannerPresets || [],
            statsMode: store.statsMode || 'realtime',
            manualTotalUsers: store.manualTotalUsers || 0,
            manualTotalJobs: store.manualTotalJobs || 0,
            manualCompletedTasks: store.manualCompletedTasks || 0,
            manualTotalWithdraw: store.manualTotalWithdraw || 0,
              },
            });
          }
          return res.json({ data: null });
        } else if (method === "upsert" || method === "update") {
          const input = args[0];
          const store = getDataStore();
          let storeUpdated = false;

          if (input.referralDomainUrl !== undefined) {
            store.referralDomainUrl = input.referralDomainUrl;
            storeUpdated = true;
            await syncSetting("referral_domain_url", store.referralDomainUrl || "");
          }
          if (input.campaignStartDate !== undefined) {
            store.campaignStartDate = input.campaignStartDate === "" ? null : input.campaignStartDate;
            storeUpdated = true;
            await syncSetting("campaign_start_date", store.campaignStartDate || "");
          }
          if (input.customBannerPresets !== undefined) {
            store.customBannerPresets = input.customBannerPresets;
            storeUpdated = true;
            await syncSetting("custom_banner_presets", JSON.stringify(store.customBannerPresets || []));
          }

          if (input.statsMode !== undefined) {
            store.statsMode = input.statsMode;
            store.manualTotalUsers = input.manualTotalUsers || 0;
            store.manualTotalJobs = input.manualTotalJobs || 0;
            store.manualCompletedTasks = input.manualCompletedTasks || 0;
            store.manualTotalWithdraw = input.manualTotalWithdraw || 0;
            storeUpdated = true;
            await syncSetting(
              "landing_stats_config",
              JSON.stringify({
                statsMode: store.statsMode,
                manualTotalUsers: store.manualTotalUsers,
                manualTotalJobs: store.manualTotalJobs,
                manualCompletedTasks: store.manualCompletedTasks,
                manualTotalWithdraw: store.manualTotalWithdraw,
              }),
            );
          }
          if (storeUpdated) {
            saveDataStore(store);
          }
          const mappedUpdate: any = {};
          if (input.notice !== undefined)
            mappedUpdate.global_notice = input.notice;
          if (input.minDeposit !== undefined)
            mappedUpdate.min_deposit = input.minDeposit;
          if (input.minWithdraw !== undefined)
            mappedUpdate.min_withdraw = input.minWithdraw;
          if (input.withdrawalFee !== undefined)
            mappedUpdate.withdrawal_fee = input.withdrawalFee;
          if (input.jobPostingFee !== undefined)
            mappedUpdate.job_service_charge = input.jobPostingFee;
          if (input.bkashNumber !== undefined)
            mappedUpdate.official_bkash = input.bkashNumber;
          if (input.bkashMethod !== undefined)
            mappedUpdate.bkash_method = input.bkashMethod;
          if (input.nagadNumber !== undefined)
            mappedUpdate.official_nagad = input.nagadNumber;
          if (input.nagadMethod !== undefined)
            mappedUpdate.nagad_method = input.nagadMethod;
          if (input.transferEarningToDepositFee !== undefined)
            mappedUpdate.transfer_earning_deposit_fee =
              input.transferEarningToDepositFee;
          if (input.transferDepositToEarningFee !== undefined)
            mappedUpdate.transfer_deposit_earning_fee =
              input.transferDepositToEarningFee;
          if (input.loginTitle !== undefined)
            mappedUpdate.login_title = input.loginTitle;
          if (input.loginBannerUrl !== undefined)
            mappedUpdate.login_banner_url = input.loginBannerUrl;
          if (input.referralBonusAmount !== undefined)
            mappedUpdate.referral_bonus_amount = input.referralBonusAmount;
          if (input.referralValidationCriteria !== undefined)
            mappedUpdate.referral_validation_criteria =
              input.referralValidationCriteria;
          if (input.referralValidityDays !== undefined)
            mappedUpdate.referral_validity_days = input.referralValidityDays;
          if (input.campaignEndDate !== undefined)
            mappedUpdate.campaign_end_date =
              input.campaignEndDate === "" ? null : input.campaignEndDate;
          if (input.target1Referrals !== undefined)
            mappedUpdate.target_1_referrals = input.target1Referrals;
          if (input.target1Reward !== undefined)
            mappedUpdate.target_1_reward = input.target1Reward;
          if (input.target2Referrals !== undefined)
            mappedUpdate.target_2_referrals = input.target2Referrals;
          if (input.target2Reward !== undefined)
            mappedUpdate.target_2_reward = input.target2Reward;
          if (input.depositBkashEnabled !== undefined)
            mappedUpdate.deposit_bkash_enabled = input.depositBkashEnabled;
          if (input.depositNagadEnabled !== undefined)
            mappedUpdate.deposit_nagad_enabled = input.depositNagadEnabled;
          if (input.withdrawBkashEnabled !== undefined)
            mappedUpdate.withdraw_bkash_enabled = input.withdrawBkashEnabled;
          if (input.withdrawNagadEnabled !== undefined)
            mappedUpdate.withdraw_nagad_enabled = input.withdrawNagadEnabled;

          mappedUpdate.updated_at = new Date().toISOString();

          const { data, error } = await supabase
            .from("system_configuration")
            .update(mappedUpdate)
            .eq("id", 1)
            .select()
            .maybeSingle();
          if (error) return res.status(400).json({ error: error.message });

          if (!data) {
            await supabase
              .from("system_configuration")
              .insert({ id: 1, ...mappedUpdate });
          }
          return res.json({ data: input });
        } else {
          return res.json({ data: null });
        }
      }

      // removed emulated tables
      if (table === "advertisements") {
        const normalizeAdForBackend = (a: any) => {
          if (!a || typeof a !== "object") return a;
          const n: any = { ...a };
          if ("userId" in a) {
            n.user_id = a.userId;
            delete n.userId;
          }
          if ("userSerial" in a) {
            n.user_serial = a.userSerial;
            delete n.userSerial;
          }
          if ("durationDays" in a) {
            n.duration_days = a.durationDays;
            delete n.durationDays;
          }
          if ("transactionId" in a) {
            n.transaction_id = a.transactionId;
            delete n.transactionId;
          }
          if ("createdAt" in a) {
            n.created_at = a.createdAt;
            delete n.createdAt;
          }
          if ("expiresAt" in a) {
            n.expires_at = a.expiresAt;
            delete n.expiresAt;
          }
          if ("approvedAt" in a) {
            n.approved_at = a.approvedAt;
            delete n.approvedAt;
          }
          if ("rejectedAt" in a) {
            n.rejected_at = a.rejectedAt;
            delete n.rejectedAt;
          }
          return n;
        };
        if (method === "insert" && args?.[0])
          args[0] = Array.isArray(args[0])
            ? args[0].map(normalizeAdForBackend)
            : normalizeAdForBackend(args[0]);
        if (method === "update" && args?.[0] && dbEq && dbEq[0] === "id" && dbEq[1]) {
          const nextAdStatus = String(args[0].status || "").toLowerCase();
          if (nextAdStatus === "approved" || nextAdStatus === "rejected") {
            try {
              const { data: existingAd } = await supabase
                .from("advertisements")
                .select("user_id, title, price, status")
                .eq("id", dbEq[1])
                .maybeSingle();
              if (existingAd && existingAd.user_id && existingAd.status !== nextAdStatus) {
                const adTitle = existingAd.title || "Advertisement";
                if (nextAdStatus === "approved") {
                  pendingUserNotifications.push({
                    userId: existingAd.user_id,
                    type: "approved",
                    message: `আপনার বিজ্ঞাপন "${adTitle}" এপ্রুভ করা হয়েছে এবং এখন লাইভ চলছে।`,
                  });
                } else {
                  pendingUserNotifications.push({
                    userId: existingAd.user_id,
                    type: "rejected",
                    message: `আপনার বিজ্ঞাপন "${adTitle}" রিজেক্ট করা হয়েছে এবং ৳${Number(existingAd.price || 0).toFixed(2)} আপনার ডিপোজিট ব্যালেন্সে ফেরত দেওয়া হয়েছে।`,
                  });
                }
              }
            } catch {}
          }
        }
        if ((method === "update" || method === "upsert") && args?.[0])
          args[0] = normalizeAdForBackend(args[0]);
        if (dbEq && dbEq[0] === "userId") dbEq[0] = "user_id";
        if (dbEqs)
          dbEqs.forEach((r: any) => {
            if (r && r[0] === "userId") r[0] = "user_id";
          });
      }

      if (table === "tickets") {
        const normalizeTicketForBackend = (t: any) => {
          if (!t || typeof t !== "object") return t;
          const n: any = { ...t };
          if ("userId" in t) {
            n.user_id = t.userId;
            delete n.userId;
          }
          if ("userSerial" in t) {
            n.user_serial = t.userSerial;
            delete n.userSerial;
          }
          if ("adminReply" in t) {
            n.admin_reply = t.adminReply;
            delete n.adminReply;
          }
          if ("createdAt" in t) {
            n.created_at = t.createdAt;
            delete n.createdAt;
          }
          if ("resolvedAt" in t) {
            n.resolved_at = t.resolvedAt;
            delete n.resolvedAt;
          }
          return n;
        };
        if (method === "insert" && args?.[0])
          args[0] = Array.isArray(args[0])
            ? args[0].map(normalizeTicketForBackend)
            : normalizeTicketForBackend(args[0]);
        if (method === "update" && args?.[0] && isAdmin && dbEq && dbEq[0] === "id" && dbEq[1]) {
          try {
            const { data: existingTicket } = await supabase
              .from("tickets")
              .select("user_id, subject, status")
              .eq("id", dbEq[1])
              .maybeSingle();
            if (existingTicket && existingTicket.user_id && existingTicket.user_id !== user?.id) {
              const subj = existingTicket.subject || "Support Ticket";
              const nextStatus = String(args[0].status || "").toLowerCase();
              const repliesArr = Array.isArray(args[0].replies) ? args[0].replies : null;
              const latestReply = repliesArr && repliesArr.length > 0 ? repliesArr[repliesArr.length - 1] : null;
              if (nextStatus === "resolved" && existingTicket.status !== "resolved") {
                pendingUserNotifications.push({
                  userId: existingTicket.user_id,
                  type: "approved",
                  message: `আপনার সাপোর্ট টিকেট "${subj}" সমাধান (Resolved) করা হয়েছে।`,
                });
              } else if (latestReply?.sender === "admin" || args[0].adminReply || args[0].admin_reply) {
                pendingUserNotifications.push({
                  userId: existingTicket.user_id,
                  type: "info",
                  message: `আপনার সাপোর্ট টিকেট "${subj}"-এ এডমিন নতুন উত্তর দিয়েছেন।`,
                });
              }
            }
          } catch {}
        }
        if ((method === "update" || method === "upsert") && args?.[0])
          args[0] = normalizeTicketForBackend(args[0]);
        if (dbEq && dbEq[0] === "userId") dbEq[0] = "user_id";
        if (dbEqs)
          dbEqs.forEach((r: any) => {
            if (r && r[0] === "userId") r[0] = "user_id";
          });
      }

      // Map frontend-to-backend transaction types and filter parameters to match the database ENUM schemas
      // if (req.body.eq) dbEq = req.body.eq; // REMOVED THIS DANGEROUS REVERT

      if (table === "transactions") {
        const normalizeTxForBackend = (t: any) => {
          if (!t || typeof t !== "object") return t;
          const normalized: any = {};
          const details = { ...(t.payment_details || t.paymentDetails || {}) };

          if ("userId" in t) normalized.user_id = t.userId;
          if ("user_id" in t) normalized.user_id = t.user_id;

          if ("type" in t) {
            let typeVal = t.type;
            if (typeVal === "withdrawal") typeVal = "withdraw";
            if (typeVal === "payment" || typeVal === "ad_purchase")
              typeVal = "spend";
            normalized.type = typeVal;
          }

          if ("amount" in t) normalized.amount = t.amount;
          if ("status" in t) normalized.status = t.status;

          if ("referenceId" in t) normalized.reference_id = t.referenceId;
          if ("reference_id" in t) normalized.reference_id = t.reference_id;

          if ("method" in t) normalized.payment_method = t.method;
          if ("payment_method" in t)
            normalized.payment_method = t.payment_method;
          if ("paymentMethod" in t) normalized.payment_method = t.paymentMethod;

          if ("createdAt" in t) normalized.created_at = t.createdAt;
          if ("created_at" in t) normalized.created_at = t.created_at;

          if ("updatedAt" in t) normalized.updated_at = t.updatedAt;
          if ("updated_at" in t) normalized.updated_at = t.updated_at;

          if ("id" in t) normalized.id = t.id;

          // Put all remaining custom properties into payment_details
          const knownKeys = [
            "userId",
            "user_id",
            "type",
            "amount",
            "status",
            "referenceId",
            "reference_id",
            "method",
            "payment_method",
            "paymentMethod",
            "createdAt",
            "created_at",
            "updatedAt",
            "updated_at",
            "id",
            "payment_details",
            "paymentDetails",
          ];
          for (const [key, val] of Object.entries(t)) {
            if (!knownKeys.includes(key)) {
              details[key] = val;
            }
          }

          if (Object.keys(details).length > 0) {
            normalized.payment_details = details;
          }

          return normalized;
        };

        if (method === "insert" && args?.[0]) {
          const tArgs = Array.isArray(args[0]) ? args[0] : [args[0]];
          const normalizedArgs = tArgs.map(normalizeTxForBackend);
          args[0] = Array.isArray(args[0]) ? normalizedArgs : normalizedArgs[0];
        }

        if (method === "update" && args?.[0]) {
          const updatedFields = normalizeTxForBackend(args[0]);

          // If updating via ID, we can fetch existing transaction first to avoid overwriting payment_details entirely
          if (dbEq && dbEq[0] === "id") {
            try {
              const txId = dbEq[1];
              const { data: existingTx } = await (supabase as any)
                .from("transactions")
                .select("user_id, type, amount, status, payment_method, payment_details")
                .eq("id", txId)
                .single();
              if (existingTx) {
                const existingDetails = existingTx.payment_details || {};
                updatedFields.payment_details = {
                  ...existingDetails,
                  ...(updatedFields.payment_details || {}),
                };

                const nextTxStatus = String(updatedFields.status || "").toLowerCase();
                if (
                  existingTx.status === "pending" &&
                  (nextTxStatus === "completed" || nextTxStatus === "rejected") &&
                  existingTx.user_id
                ) {
                  const rawTxType = String(existingTx.type || "").toLowerCase();
                  const txAmount = Number(existingTx.amount || 0).toFixed(2);
                  const txMethod = existingTx.payment_method || existingDetails.method || "";
                  const methodLabel = txMethod ? ` (${txMethod})` : "";
                  if (rawTxType === "withdraw" || rawTxType === "withdrawal") {
                    if (nextTxStatus === "completed") {
                      pendingUserNotifications.push({
                        userId: existingTx.user_id,
                        type: "approved",
                        message: `আপনার ৳${txAmount} উইথড্র রিকোয়েস্ট${methodLabel} এপ্রুভ করা হয়েছে এবং পেমেন্ট পাঠানো হয়েছে।`,
                      });
                    } else {
                      pendingUserNotifications.push({
                        userId: existingTx.user_id,
                        type: "rejected",
                        message: `আপনার ৳${txAmount} উইথড্র রিকোয়েস্ট${methodLabel} রিজেক্ট করা হয়েছে এবং টাকা আপনার আর্নিং ব্যালেন্সে ফেরত দেওয়া হয়েছে।`,
                      });
                    }
                  } else if (rawTxType === "deposit") {
                    if (nextTxStatus === "completed") {
                      pendingUserNotifications.push({
                        userId: existingTx.user_id,
                        type: "approved",
                        message: `আপনার ৳${txAmount} ডিপোজিট রিকোয়েস্ট${methodLabel} এপ্রুভ করা হয়েছে এবং ডিপোজিট ব্যালেন্সে যোগ হয়েছে।`,
                      });
                    } else {
                      pendingUserNotifications.push({
                        userId: existingTx.user_id,
                        type: "rejected",
                        message: `আপনার ৳${txAmount} ডিপোজিট রিকোয়েস্ট${methodLabel} রিজেক্ট করা হয়েছে।`,
                      });
                    }
                  }
                }
              }
            } catch (e) {
              console.error(
                "Error merging existing payment_details on update",
                e,
              );
            }
          }
          args[0] = updatedFields;
        }

        if (method === "upsert" && args?.[0]) {
          args[0] = normalizeTxForBackend(args[0]);
        }

        if (dbEqs && dbEqs.length > 0) {
          dbEqs = dbEqs.map((rule) => {
            if (rule && rule[0] === "type") {
              let newVal = rule[1];
              if (newVal === "withdrawal") newVal = "withdraw";
              if (newVal === "payment" || newVal === "ad_purchase")
                newVal = "spend";
              return ["type", newVal];
            }
            if (rule && rule[0] === "userId") {
              return ["user_id", rule[1]];
            }
            return rule;
          });
        }

        if (dbEq && dbEq[0] === "type") {
          if (dbEq[1] === "withdrawal") dbEq[1] = "withdraw";
          if (dbEq[1] === "payment" || dbEq[1] === "ad_purchase")
            dbEq[1] = "spend";
        }
        if (dbEq && dbEq[0] === "userId") {
          dbEq[0] = "user_id";
        }
        if (dbMatch && typeof dbMatch === "object") {
          if (dbMatch.type === "withdrawal") dbMatch.type = "withdraw";
          if (dbMatch.type === "payment" || dbMatch.type === "ad_purchase")
            dbMatch.type = "spend";
          if (dbMatch.userId) {
            dbMatch.user_id = dbMatch.userId;
            delete dbMatch.userId;
          }
        }
        if (
          dbIn &&
          Array.isArray(dbIn) &&
          dbIn[0] === "type" &&
          Array.isArray(dbIn[1])
        ) {
          dbIn[1] = dbIn[1].map((v: string) => {
            if (v === "withdrawal") return "withdraw";
            if (v === "payment" || v === "ad_purchase") return "spend";
            return v;
          });
        }
        if (dbIn && Array.isArray(dbIn) && dbIn[0] === "userId") {
          dbIn[0] = "user_id";
        }
      }

      if (table === "jobs") {
        const normalizeJobForBackend = (j: any, isInsert = false) => {
          if (!j || typeof j !== "object") return j;
          const normalized: any = {};

          if (j.id) normalized.id = j.id;

          const posterId = j.posterId || j.author_id || j.authorId;
          if (posterId !== undefined) {
            normalized.author_id = posterId;
          } else if (isInsert) {
            normalized.author_id = "";
          }

          if (j.title !== undefined) {
            normalized.title = j.title;
          } else if (isInsert) {
            normalized.title = "";
          }

          if (j.description !== undefined) {
            normalized.description = j.description;
          } else if (isInsert) {
            normalized.description = "";
          }

          const reward =
            j.pricePerWork !== undefined
              ? j.pricePerWork
              : j.reward !== undefined
                ? j.reward
                : undefined;
          if (reward !== undefined) {
            normalized.reward = Number(reward);
          } else if (isInsert) {
            normalized.reward = 0;
          }

          const slots =
            j.maxWorkers !== undefined
              ? j.maxWorkers
              : j.slots !== undefined
                ? j.slots
                : undefined;
          if (slots !== undefined) {
            normalized.slots = Number(slots);
          } else if (isInsert) {
            normalized.slots = 1;
          }

          const slotsFilled =
            j.completedCount !== undefined
              ? j.completedCount
              : j.approvedCount !== undefined
                ? j.approvedCount
                : j.slots_filled !== undefined
                  ? j.slots_filled
                  : undefined;
          if (slotsFilled !== undefined) {
            normalized.slots_filled = Number(slotsFilled);
          } else if (isInsert) {
            normalized.slots_filled = 0;
          }

          if (j.status !== undefined) {
            let statusVal = j.status;
            // DB status field can only be 'open' or 'closed' enum. Mapping custom state safely.
            normalized.status = statusVal === "open" ? "open" : "closed";
          } else if (isInsert) {
            normalized.status = "closed"; // pending approval initially
          }

          const categoryData: any = {};
          if (j.posterId !== undefined) categoryData.posterId = j.posterId;
          if (j.posterName !== undefined)
            categoryData.posterName = j.posterName;
          if (j.posterSerial !== undefined)
            categoryData.posterSerial = j.posterSerial;
          if (j.thumbnail !== undefined) categoryData.thumbnail = j.thumbnail;
          if (j.screenshotCount !== undefined)
            categoryData.screenshotCount = j.screenshotCount;
          if (j.textProofInstruction !== undefined)
            categoryData.textProofInstruction = j.textProofInstruction;
          if (j.screenshotProofInstruction !== undefined)
            categoryData.screenshotProofInstruction =
              j.screenshotProofInstruction;
          if (j.screenshotProofInstructions !== undefined)
            categoryData.screenshotProofInstructions =
              j.screenshotProofInstructions;
          if (j.requireTextProof !== undefined)
            categoryData.requireTextProof = j.requireTextProof;
          if (j.autoApprove !== undefined)
            categoryData.autoApprove = j.autoApprove;
          if (j.pinCode !== undefined) categoryData.pinCode = j.pinCode;
          if (j.pricePerWork !== undefined)
            categoryData.pricePerWork = Number(j.pricePerWork);
          if (j.maxWorkers !== undefined)
            categoryData.maxWorkers = Number(j.maxWorkers);
          if (j.completedCount !== undefined)
            categoryData.completedCount = Number(j.completedCount);
          if (j.pendingCount !== undefined)
            categoryData.pendingCount = Number(j.pendingCount);
          if (j.approvedCount !== undefined)
            categoryData.approvedCount = Number(j.approvedCount);
          if (j.isFull !== undefined) categoryData.isFull = j.isFull;
          if (j.createdAt !== undefined) categoryData.createdAt = j.createdAt;
          if (j.totalBudget !== undefined)
            categoryData.totalBudget = Number(j.totalBudget);
          if (j.serviceCharge !== undefined)
            categoryData.serviceCharge = Number(j.serviceCharge);
          if (j.grandTotal !== undefined)
            categoryData.grandTotal = Number(j.grandTotal);
          if (j.status !== undefined) categoryData.status = j.status;
          if (j.category !== undefined) categoryData.category = j.category;
          if (j.mainCategory !== undefined) categoryData.mainCategory = j.mainCategory;
          if (j.subCategory !== undefined) categoryData.subCategory = j.subCategory;
          if (j.targetCountry !== undefined) categoryData.targetCountry = j.targetCountry;
          if (j.durationDays !== undefined) categoryData.durationDays = Number(j.durationDays);
          if (j.expiresAt !== undefined) categoryData.expiresAt = j.expiresAt;

          if (Object.keys(categoryData).length > 0 || isInsert) {
            normalized.category = JSON.stringify(categoryData);
          }
          return normalized;
        };

        if (method === "insert" && args?.[0]) {
          const tArgs = Array.isArray(args[0]) ? args[0] : [args[0]];
          for (const jobItem of tArgs) {
            const posterId = user.id;
            const pricePerWork = Number(
              jobItem.pricePerWork || jobItem.reward || 0,
            );
            const maxWorkers = Number(jobItem.maxWorkers || jobItem.slots || 1);
            if (
              !Number.isFinite(pricePerWork) ||
              pricePerWork < 1 ||
              !Number.isFinite(maxWorkers) ||
              maxWorkers < 1
            ) {
              return res.status(400).json({
                error: "Invalid price per worker or worker count.",
              });
            }
            const totalBudget = pricePerWork * maxWorkers;

            let feePercent = 10;
            try {
              const { data } = await supabase
                .from("system_configuration")
                .select("job_service_charge")
                .eq("id", 1)
                .maybeSingle();
              if (data && data.job_service_charge !== undefined)
                feePercent = Number(data.job_service_charge);
            } catch (e) {}

            const serviceCharge = totalBudget * (feePercent / 100);
            const grandTotal = totalBudget + serviceCharge;

            const { data: posterProfile, error: profileErr } = await supabase
              .from("profiles")
              .select("*")
              .eq("id", posterId)
              .single();
            if (profileErr || !posterProfile) {
              return res.status(400).json({ error: "User profile not found" });
            }

            const currentDeposit = Number(posterProfile.depositBalance || 0);
            if (currentDeposit < grandTotal) {
              return res
                .status(400)
                .json({
                  error: `পোস্ট বাজেট (BDT ${grandTotal.toFixed(2)}) এর জন্য আপনার পর্যাপ্ত ডিপোজিট ব্যালেন্স নেই।`,
                });
            }

            // Deduct BDT instantly from deposit balance and add to held balance
            const { error: balanceErr } = await supabase
              .from("profiles")
              .update({
                depositBalance: currentDeposit - grandTotal,
                heldBalance:
                  Number(posterProfile.heldBalance || 0) + totalBudget,
              })
              .eq("id", posterId);

            if (balanceErr) {
              return res
                .status(500)
                .json({
                  error: "Balance deduction failed: " + balanceErr.message,
                });
            }

            // Set status, budget, counts
            jobItem.status = "open";
            jobItem.pendingCount = 0;
            jobItem.approvedCount = 0;
            jobItem.completedCount = 0;
            jobItem.isFull = false;
            jobItem.totalBudget = totalBudget;
            jobItem.serviceCharge = serviceCharge;
            jobItem.grandTotal = grandTotal;
            jobItem.posterId = posterId;
          }
          const normalizedArgs = tArgs.map((jItem) =>
            normalizeJobForBackend(jItem, true),
          );
          args[0] = Array.isArray(args[0]) ? normalizedArgs : normalizedArgs[0];
        }
        if (method === "update" && args?.[0]) {
          const updatedJob = args[0];
          if (dbEq && dbEq[0] === "id") {
            const idVal = dbEq[1];
            const { data: existingJobRow } = await supabase
              .from("jobs")
              .select("*")
              .eq("id", idVal)
              .single();
            if (existingJobRow) {
              let jobCategory: any = {};
              try {
                if (
                  existingJobRow.category &&
                  (existingJobRow.category.startsWith("{") ||
                    existingJobRow.category.startsWith("["))
                ) {
                  jobCategory = JSON.parse(existingJobRow.category);
                }
              } catch (catErr) {}

              const oldStatus = jobCategory.status || existingJobRow.status;
              const jobTitle = existingJobRow.title || "Micro Job";
              const jobPosterId = jobCategory.posterId || existingJobRow.author_id;

              // Transition to 'open' (Approved from pending OR Delete Request Rejected)
              if (updatedJob.status === "open" && oldStatus === "pending") {
                jobCategory.status = "open";
                updatedJob.category = JSON.stringify(jobCategory);
                if (jobPosterId) {
                  pendingUserNotifications.push({
                    userId: jobPosterId,
                    type: "approved",
                    message: `আপনার পোস্ট করা জব "${jobTitle}" এপ্রুভ ও পাবলিশ করা হয়েছে।`,
                  });
                }
              } else if (updatedJob.status === "open" && oldStatus === "delete_requested") {
                jobCategory.status = "open";
                updatedJob.category = JSON.stringify(jobCategory);
                if (jobPosterId) {
                  pendingUserNotifications.push({
                    userId: jobPosterId,
                    type: "rejected",
                    message: `আপনার "${jobTitle}" জব ডিলিট রিকোয়েস্টটি রিজেক্ট করা হয়েছে এবং জবটি পুনরায় চালু রয়েছে।`,
                  });
                }
              }
              // Transition to 'deleted' or 'rejected' from pending (Reject)
              else if (
                (updatedJob.status === "deleted" ||
                  updatedJob.status === "rejected") &&
                oldStatus === "pending"
              ) {
                // Refund poster
                const posterId = jobPosterId;
                const totalBudget = Number(
                  jobCategory.totalBudget ||
                    Number(existingJobRow.reward) *
                      Number(existingJobRow.slots),
                );
                const grandTotal = Number(
                  jobCategory.grandTotal || totalBudget + totalBudget * 0.1,
                );

                const { data: posterProfile } = await supabase
                  .from("profiles")
                  .select("*")
                  .eq("id", posterId)
                  .single();
                if (posterProfile) {
                  await supabase
                    .from("profiles")
                    .update({
                      heldBalance: Math.max(
                        0,
                        Number(posterProfile.heldBalance || 0) - totalBudget,
                      ),
                      depositBalance:
                        Number(posterProfile.depositBalance || 0) + grandTotal,
                    })
                    .eq("id", posterId);
                }
                jobCategory.status = "rejected";
                updatedJob.status = "deleted"; // Keep in DB as deleted
                updatedJob.category = JSON.stringify(jobCategory);
                if (posterId) {
                  pendingUserNotifications.push({
                    userId: posterId,
                    type: "rejected",
                    message: `আপনার পোস্ট করা জব "${jobTitle}" রিজেক্ট করা হয়েছে এবং ৳${grandTotal.toFixed(2)} আপনার ডিপোজিট ব্যালেন্সে ফেরত দেওয়া হয়েছে।`,
                  });
                }
              }
              // Transition to 'deleted' from active 'open' (Cancel/Delete)
              else if (
                updatedJob.status === "deleted" &&
                (oldStatus === "open" || oldStatus === "delete_requested")
              ) {
                const posterId = jobPosterId;
                const maxWorkers = Number(
                  existingJobRow.slots || jobCategory.maxWorkers || 1,
                );
                const approvedCount = Number(
                  existingJobRow.slots_filled || jobCategory.approvedCount || 0,
                );
                const pendingCount = Number(jobCategory.pendingCount || 0);
                const remainingCount =
                  maxWorkers - (approvedCount + pendingCount);
                const pricePerWork = Number(
                  existingJobRow.reward || jobCategory.pricePerWork || 0,
                );
                const refundAmount =
                  remainingCount > 0 ? remainingCount * pricePerWork : 0;

                if (refundAmount > 0) {
                  const { data: posterProfile } = await supabase
                    .from("profiles")
                    .select("*")
                    .eq("id", posterId)
                    .single();
                  if (posterProfile) {
                    await supabase
                      .from("profiles")
                      .update({
                        heldBalance: Math.max(
                          0,
                          Number(posterProfile.heldBalance || 0) - refundAmount,
                        ),
                        depositBalance:
                          Number(posterProfile.depositBalance || 0) +
                          refundAmount,
                      })
                      .eq("id", posterId);
                  }
                }
                jobCategory.status = "deleted";
                updatedJob.category = JSON.stringify(jobCategory);
                if (posterId && oldStatus === "delete_requested") {
                  pendingUserNotifications.push({
                    userId: posterId,
                    type: "approved",
                    message: `আপনার "${jobTitle}" জব ডিলিট রিকোয়েস্ট এপ্রুভ করা হয়েছে${refundAmount > 0 ? ` এবং অবশিষ্ট ৳${refundAmount.toFixed(2)} ফেরত দেওয়া হয়েছে` : ""}।`,
                  });
                } else if (posterId && isAdmin && posterId !== user?.id) {
                  pendingUserNotifications.push({
                    userId: posterId,
                    type: "info",
                    message: `আপনার "${jobTitle}" জবটি এডমিন কর্তৃক বাতিল করা হয়েছে${refundAmount > 0 ? ` এবং অবশিষ্ট ৳${refundAmount.toFixed(2)} ফেরত দেওয়া হয়েছে` : ""}।`,
                  });
                }
              }
            }
          }

          let updatedFields = normalizeJobForBackend(args[0]);
          if (dbEq && dbEq[0] === "id") {
            try {
              const idVal = dbEq[1];
              const { data: existingJob } = await (supabase as any)
                .from("jobs")
                .select("category")
                .eq("id", idVal)
                .single();
              if (existingJob && existingJob.category) {
                let parsedCategory = {};
                try {
                  parsedCategory = JSON.parse(existingJob.category);
                } catch (catErr) {}
                const newCategory = {
                  ...parsedCategory,
                  ...JSON.parse(updatedFields.category || "{}"),
                };
                updatedFields.category = JSON.stringify(newCategory);
              }
            } catch (e) {
              console.error("Error merging job category on update", e);
            }
          }
          args[0] = updatedFields;
        }
        if (method === "upsert" && args?.[0]) {
          args[0] = normalizeJobForBackend(args[0]);
        }

        // Rewrite filters
        if (dbEqs && dbEqs.length > 0) {
          dbEqs = dbEqs.map((rule) => {
            if (rule && rule[0] === "posterId") {
              return ["author_id", rule[1]];
            }
            if (rule && rule[0] === "createdAt") {
              return ["created_at", rule[1]];
            }
            return rule;
          });
        }

        if (dbEq && dbEq[0] === "posterId") {
          dbEq = ["author_id", dbEq[1]];
        }
        if (dbEq && dbEq[0] === "createdAt") {
          dbEq = ["created_at", dbEq[1]];
        }
        if (dbMatch) {
          if (dbMatch.posterId) {
            dbMatch.author_id = dbMatch.posterId;
            delete dbMatch.posterId;
          }
          if (dbMatch.createdAt) {
            dbMatch.created_at = dbMatch.createdAt;
            delete dbMatch.createdAt;
          }
        }
        if (dbOrder && dbOrder[0] === "createdAt") {
          dbOrder = ["created_at", dbOrder[1]];
        }
        if (dbOrder && dbOrder[0] === "pricePerWork") {
          dbOrder = ["reward", dbOrder[1]];
        }
      }

      if (table === "submissions") {
        const normalizeSubmissionForBackend = (s: any, isInsert = false) => {
          if (!s || typeof s !== "object") return s;
          const normalized: any = {};

          if (
            s.id &&
            typeof s.id === "string" &&
            s.id.length === 36 &&
            s.id.includes("-")
          ) {
            normalized.id = s.id;
          }
          if (s.jobId !== undefined || s.job_id !== undefined) {
            normalized.job_id = s.jobId || s.job_id;
          }
          if (s.workerId !== undefined || s.worker_id !== undefined) {
            normalized.worker_id = s.workerId || s.worker_id;
          }

          if (s.status !== undefined) {
            let statusVal = s.status;
            if (
              statusVal !== "pending" &&
              statusVal !== "approved" &&
              statusVal !== "rejected"
            ) {
              statusVal = "pending";
            }
            normalized.status = statusVal;
          } else if (isInsert) {
            normalized.status = "pending";
          }

          const proofData: any = {};
          if (s.proofText !== undefined) proofData.proofText = s.proofText;
          if (s.proof !== undefined) {
            if (
              typeof s.proof === "string" &&
              (s.proof.startsWith("{") || s.proof.startsWith("["))
            ) {
              try {
                const parsed = JSON.parse(s.proof);
                Object.assign(proofData, parsed);
              } catch (e) {
                proofData.proofText = s.proof;
              }
            } else {
              proofData.proofText = s.proof;
            }
          }
          if (s.screenshots !== undefined)
            proofData.screenshots = s.screenshots;
          if (s.rejectionReason !== undefined)
            proofData.rejectionReason = s.rejectionReason;
          if (s.workerName !== undefined) proofData.workerName = s.workerName;
          if (s.workerSerial !== undefined)
            proofData.workerSerial = s.workerSerial;
          if (s.posterId !== undefined) proofData.posterId = s.posterId;
          if (s.reward !== undefined) proofData.reward = s.reward;
          if (s.submittedAt !== undefined)
            proofData.submittedAt = s.submittedAt;
          if (s.reviewedAt !== undefined) proofData.reviewedAt = s.reviewedAt;
          if (s.jobTitle !== undefined) proofData.jobTitle = s.jobTitle;
          if (s.pinCodeUsed !== undefined)
            proofData.pinCodeUsed = s.pinCodeUsed;

          if (Object.keys(proofData).length > 0 || isInsert) {
            normalized.proof = JSON.stringify({
              proofText: "",
              screenshots: [],
              ...proofData,
            });
          }
          return normalized;
        };

        if (method === "insert" && args?.[0]) {
          const tArgs = Array.isArray(args[0]) ? args[0] : [args[0]];
          for (const subItem of tArgs) {
            const workerId = user.id;
            const jobId = subItem.jobId || subItem.job_id;

            // Load the job first
            const { data: jobData, error: jobErr } = await supabase
              .from("jobs")
              .select("*")
              .eq("id", jobId)
              .single();
            if (jobErr || !jobData) {
              return res
                .status(404)
                .json({ error: "This job no longer exists." });
            }

            let extra: any = {};
            try {
              if (
                jobData.category &&
                (jobData.category.startsWith("{") ||
                  jobData.category.startsWith("["))
              ) {
                extra = JSON.parse(jobData.category);
              }
            } catch (e) {}

            const jobPosterId = extra.posterId || jobData.author_id;
            if (jobPosterId && jobPosterId === workerId) {
              return res
                .status(403)
                .json({ error: "You cannot submit proof for your own posted job." });
            }

            const status = extra.status || jobData.status || "open";
            if (status !== "open") {
              return res
                .status(400)
                .json({ error: "This job is no longer active." });
            }

            const maxWorkers = Number(jobData.slots || extra.maxWorkers || 1);
            const approvedCount = Number(
              jobData.slots_filled || extra.approvedCount || 0,
            );
            const pendingCount = Number(extra.pendingCount || 0);

            if (approvedCount + pendingCount >= maxWorkers || extra.isFull) {
              return res
                .status(400)
                .json({
                  error:
                    "দুঃখিত! আপনি সাবমিট করার আগেই এই জবের সব স্লট বুক হয়ে গেছে।",
                });
            }

            // Check if already submitted
            const { data: existingSub } = await supabase
              .from("submissions")
              .select("id")
              .eq("worker_id", workerId)
              .eq("job_id", jobId)
              .maybeSingle();
            if (existingSub) {
              return res
                .status(400)
                .json({
                  error: "You have already submitted proof for this job.",
                });
            }

            const reward = Number(jobData.reward || extra.pricePerWork || 0);
            subItem.workerId = workerId;
            subItem.reward = reward;

            const isAutoApprove =
              extra.autoApprove === true || extra.autoApprove === "true";
            if (isAutoApprove) {
              subItem.status = "approved";
              subItem.reviewedAt = new Date().toISOString();
            } else {
              subItem.status = "pending";
            }

            const newPending = isAutoApprove ? pendingCount : pendingCount + 1;
            const newApproved = isAutoApprove
              ? approvedCount + 1
              : approvedCount;
            const isJobFullNow = newPending + newApproved >= maxWorkers;

            // Update job counts in DB
            const updatedCategory = {
              ...extra,
              pendingCount: newPending,
              approvedCount: newApproved,
              completedCount: newApproved + newPending,
              isFull: isJobFullNow,
            };

            await supabase
              .from("jobs")
              .update({
                slots_filled: newApproved,
                category: JSON.stringify(updatedCategory),
              })
              .eq("id", jobId);

            // Update worker balance
            const { data: workerProfile } = await supabase
              .from("profiles")
              .select("*")
              .eq("id", workerId)
              .single();
            if (workerProfile) {
              if (isAutoApprove) {
                await supabase
                  .from("profiles")
                  .update({
                    earningBalance:
                      Number(workerProfile.earningBalance || 0) + reward,
                  })
                  .eq("id", workerId);

                validateReferral(workerId).catch(console.error);

                // Deduct from poster's heldBalance
                const posterId = extra.posterId || jobData.author_id;
                const { data: posterProfile } = await supabase
                  .from("profiles")
                  .select("*")
                  .eq("id", posterId)
                  .single();
                if (posterProfile) {
                  await supabase
                    .from("profiles")
                    .update({
                      heldBalance: Math.max(
                        0,
                        Number(posterProfile.heldBalance || 0) - reward,
                      ),
                    })
                    .eq("id", posterId);
                }
                pendingUserNotifications.push({
                  userId: workerId,
                  type: "approved",
                  message: `আপনার "${jobData.title || "Micro Job"}" কাজটি অটো-এপ্রুভ হয়েছে এবং ৳${reward.toFixed(2)} আপনার আর্নিং ব্যালেন্সে যোগ হয়েছে।`,
                });
              } else {
                await supabase
                  .from("profiles")
                  .update({
                    pendingEarningBalance:
                      Number(workerProfile.pendingEarningBalance || 0) + reward,
                  })
                  .eq("id", workerId);
              }
            }
          }
          const normalizedArgs = tArgs.map((sItem) =>
            normalizeSubmissionForBackend(sItem, true),
          );
          args[0] = Array.isArray(args[0]) ? normalizedArgs : normalizedArgs[0];
        }
        if (method === "update" && args?.[0]) {
          const updatedSub = args[0];
          if (
            updatedSub.status === "approved" ||
            updatedSub.status === "rejected"
          ) {
            const idVal = dbEq ? dbEq[1] : null;
            if (idVal) {
              const { data: submission } = await supabase
                .from("submissions")
                .select("*")
                .eq("id", idVal)
                .single();
              if (submission && submission.status === "pending") {
                let subProofExtra: any = {};
                try {
                  if (
                    submission.proof &&
                    (submission.proof.startsWith("{") ||
                      submission.proof.startsWith("["))
                  ) {
                    subProofExtra = JSON.parse(submission.proof);
                  }
                } catch (e) {}

                const posterId = subProofExtra.posterId || submission.posterId;
                const reward = Number(
                  subProofExtra.reward || submission.reward || 0,
                );

                const { data: jobData } = await supabase
                  .from("jobs")
                  .select("*")
                  .eq("id", submission.job_id)
                  .single();
                if (jobData) {
                  let jobCategory: any = {};
                  try {
                    if (
                      jobData.category &&
                      (jobData.category.startsWith("{") ||
                        jobData.category.startsWith("["))
                    ) {
                      jobCategory = JSON.parse(jobData.category);
                    }
                  } catch (e) {}

                  const maxWorkers = Number(
                    jobData.slots || jobCategory.maxWorkers || 1,
                  );
                  const currentPending = Number(jobCategory.pendingCount || 0);
                  const currentApproved = Number(
                    jobData.slots_filled || jobCategory.approvedCount || 0,
                  );
                  const newPending = Math.max(0, currentPending - 1);

                  if (updatedSub.status === "approved") {
                    const newApproved = currentApproved + 1;
                    const isJobFull = newPending + newApproved >= maxWorkers;

                    const updatedCategory = {
                      ...jobCategory,
                      pendingCount: newPending,
                      approvedCount: newApproved,
                      completedCount: newApproved + newPending,
                      isFull: isJobFull,
                    };

                    await supabase
                      .from("jobs")
                      .update({
                        slots_filled: newApproved,
                        category: JSON.stringify(updatedCategory),
                      })
                      .eq("id", submission.job_id);

                    // Update Worker's balance (earningBalance up, pendingEarningBalance down)
                    const { data: workerProfile } = await supabase
                      .from("profiles")
                      .select("*")
                      .eq("id", submission.worker_id)
                      .single();
                    if (workerProfile) {
                      await supabase
                        .from("profiles")
                        .update({
                          earningBalance:
                            Number(workerProfile.earningBalance || 0) + reward,
                          pendingEarningBalance: Math.max(
                            0,
                            Number(workerProfile.pendingEarningBalance || 0) -
                              reward,
                          ),
                        })
                        .eq("id", submission.worker_id);
                      validateReferral(submission.worker_id).catch(
                        console.error,
                      );
                    }

                    // Deduct poster's heldBalance
                    const { data: posterProfile } = await supabase
                      .from("profiles")
                      .select("*")
                      .eq("id", posterId)
                      .single();
                    if (posterProfile) {
                      await supabase
                        .from("profiles")
                        .update({
                          heldBalance: Math.max(
                            0,
                            Number(posterProfile.heldBalance || 0) - reward,
                          ),
                        })
                        .eq("id", posterId);
                    }
                  } else if (updatedSub.status === "rejected") {
                    const isJobFullNow =
                      newPending + currentApproved >= maxWorkers;

                    const updatedCategory = {
                      ...jobCategory,
                      pendingCount: newPending,
                      completedCount: currentApproved + newPending,
                      isFull: isJobFullNow,
                    };

                    await supabase
                      .from("jobs")
                      .update({
                        slots_filled: currentApproved,
                        category: JSON.stringify(updatedCategory),
                      })
                      .eq("id", submission.job_id);

                    // Update Worker's pending balance
                    const { data: workerProfile } = await supabase
                      .from("profiles")
                      .select("*")
                      .eq("id", submission.worker_id)
                      .single();
                    if (workerProfile) {
                      await supabase
                        .from("profiles")
                        .update({
                          pendingEarningBalance: Math.max(
                            0,
                            Number(workerProfile.pendingEarningBalance || 0) -
                              reward,
                          ),
                        })
                        .eq("id", submission.worker_id);
                    }

                    // Re-deposit into poster's depositBalance if the job is already deleted or closed.
                    // Otherwise, keep it in heldBalance for other workers to complete!
                    const jobStatus =
                      jobCategory.status || jobData.status || "open";
                    if (jobStatus === "deleted" || jobStatus === "closed") {
                      const { data: posterProfile } = await supabase
                        .from("profiles")
                        .select("*")
                        .eq("id", posterId)
                        .single();
                      if (posterProfile) {
                        await supabase
                          .from("profiles")
                          .update({
                            heldBalance: Math.max(
                              0,
                              Number(posterProfile.heldBalance || 0) - reward,
                            ),
                            depositBalance:
                              Number(posterProfile.depositBalance || 0) +
                              reward,
                          })
                          .eq("id", posterId);
                      }
                    }
                  }

                  subProofExtra.reviewedAt = new Date().toISOString();
                  subProofExtra.rejectionReason =
                    updatedSub.rejectionReason ||
                    updatedSub.reject_reason ||
                    "";
                  updatedSub.proof = JSON.stringify(subProofExtra);
                  delete updatedSub.rejectionReason;
                  delete updatedSub.reject_reason;

                  if (submission.worker_id) {
                    const subJobTitle = jobData.title || subProofExtra.jobTitle || "Micro Job";
                    if (updatedSub.status === "approved") {
                      pendingUserNotifications.push({
                        userId: submission.worker_id,
                        type: "approved",
                        message: `আপনার "${subJobTitle}" কাজের প্রুফ এপ্রুভ হয়েছে এবং ৳${reward.toFixed(2)} আপনার আর্নিং ব্যালেন্সে যোগ হয়েছে।`,
                      });
                    } else if (updatedSub.status === "rejected") {
                      const reasonText = subProofExtra.rejectionReason
                        ? ` কারণ: ${subProofExtra.rejectionReason}`
                        : "";
                      pendingUserNotifications.push({
                        userId: submission.worker_id,
                        type: "rejected",
                        message: `আপনার "${subJobTitle}" কাজের প্রুফ রিজেক্ট করা হয়েছে।${reasonText}`,
                      });
                    }
                  }
                }
              }
            }
          }

          let updatedFields = normalizeSubmissionForBackend(args[0]);
          if (dbEq && dbEq[0] === "id") {
            try {
              const idVal = dbEq[1];
              const { data: existingSub } = await (supabase as any)
                .from("submissions")
                .select("proof")
                .eq("id", idVal)
                .single();
              if (existingSub && existingSub.proof) {
                let parsedProof = {};
                try {
                  parsedProof = JSON.parse(existingSub.proof);
                } catch (proofErr) {}
                const newProof = {
                  ...parsedProof,
                  ...JSON.parse(updatedFields.proof || "{}"),
                };
                updatedFields.proof = JSON.stringify(newProof);
              }
            } catch (e) {
              console.error("Error merging submission proof on update", e);
            }
          }
          args[0] = updatedFields;
        }
        if (method === "upsert" && args?.[0]) {
          args[0] = normalizeSubmissionForBackend(args[0], true);
        }

        // Rewrite filters
        if (dbEqs && dbEqs.length > 0) {
          dbEqs = dbEqs.filter((rule) => {
            if (rule && rule[0] === "jobId") {
              rule[0] = "job_id";
              return true;
            } else if (rule && rule[0] === "workerId") {
              rule[0] = "worker_id";
              return true;
            } else if (rule && rule[0] === "posterId") {
              const pId = rule[1];
              const oldF = memFilter;
              memFilter = (subItem: any) =>
                (!oldF || oldF(subItem)) && subItem.posterId === pId;
              return false;
            }
            return true;
          });
        }

        if (dbEq) {
          if (dbEq[0] === "jobId") {
            dbEq = ["job_id", dbEq[1]];
          } else if (dbEq[0] === "workerId") {
            dbEq = ["worker_id", dbEq[1]];
          } else if (dbEq[0] === "posterId") {
            const pId = dbEq[1];
            memFilter = (subItem: any) => subItem.posterId === pId;
            dbEq = null;
          }
        }
        if (dbMatch) {
          if (dbMatch.jobId) {
            dbMatch.job_id = dbMatch.jobId;
            delete dbMatch.jobId;
          }
          if (dbMatch.workerId) {
            dbMatch.worker_id = dbMatch.workerId;
            delete dbMatch.workerId;
          }
          if (dbMatch.posterId) {
            const pId = dbMatch.posterId;
            delete dbMatch.posterId;
            const oldF = memFilter;
            memFilter = (subItem: any) =>
              (!oldF || oldF(subItem)) && subItem.posterId === pId;
          }
        }
        if (dbOrder && dbOrder[0] === "submittedAt") {
          dbOrder = ["created_at", dbOrder[1]];
        }
      }

      if (table === "profiles" && args && args[0]) {
        if (
          method === "update" &&
          isAdmin &&
          args[0].account_status === "active" &&
          dbEq &&
          dbEq[0] === "id" &&
          dbEq[1] &&
          dbEq[1] !== user?.id
        ) {
          try {
            const targetUserId = String(dbEq[1]);
            const { data: prevProf } = await supabase
              .from("profiles")
              .select("account_status")
              .eq("id", targetUserId)
              .maybeSingle();
            if (prevProf?.account_status === "pending_deletion") {
              pendingUserNotifications.push({
                userId: targetUserId,
                type: "rejected",
                message:
                  "আপনার একাউন্ট ডিলিট রিকোয়েস্টটি রিজেক্ট করা হয়েছে এবং আপনার একাউন্ট সচল রাখা হয়েছে।",
              });
            }
          } catch {}
        }
        const pItems = Array.isArray(args[0]) ? args[0] : [args[0]];
        for (const pItem of pItems) {
          if (pItem && typeof pItem === "object") {
            delete pItem.deleted_by;
            delete pItem.uid;
          }
        }
      }

      let queryBuilder = (supabase as any).from(table);
      if (method === "select")
        queryBuilder = queryBuilder.select(args ? args[0] : "*");
      if (method === "update") queryBuilder = queryBuilder.update(args[0]);
      if (method === "insert") queryBuilder = queryBuilder.insert(args[0]);
      if (method === "delete") queryBuilder = queryBuilder.delete();
      if (method === "upsert") queryBuilder = queryBuilder.upsert(args[0]);

      if (dbEqs && dbEqs.length > 0) {
        for (const rule of dbEqs) {
          if (rule && rule[0]) {
            queryBuilder = queryBuilder.eq(rule[0], rule[1]);
          }
        }
      } else if (dbEq) {
        queryBuilder = queryBuilder.eq(dbEq[0], dbEq[1]);
      }
      if (dbNeqs && dbNeqs.length > 0) {
        for (const rule of dbNeqs) {
          if (rule && rule[0]) {
            queryBuilder = queryBuilder.neq(rule[0], rule[1]);
          }
        }
      }
      if (dbMatch) queryBuilder = queryBuilder.match(dbMatch);
      if (dbIn) queryBuilder = queryBuilder.in(dbIn[0], dbIn[1]);
      if (dbNotIn)
        queryBuilder = queryBuilder.not(
          dbNotIn[0],
          "in",
          `(${dbNotIn[1].map((x: any) => `"${x}"`).join(",")})`,
        );
      if (dbOr) queryBuilder = queryBuilder.or(dbOr);
      if (ilike) queryBuilder = queryBuilder.ilike(ilike[0], ilike[1]);
      if (dbOrder) queryBuilder = queryBuilder.order(dbOrder[0], dbOrder[1]);
      if (dbLimit) queryBuilder = queryBuilder.limit(dbLimit);

      if (single) queryBuilder = queryBuilder.single();
      if (maybeSingle) queryBuilder = queryBuilder.maybeSingle();

      const { data, error } = await queryBuilder;
      if (error) return res.status(400).json({ error: error.message });

      if (pendingUserNotifications.length > 0) {
        await Promise.allSettled(
          pendingUserNotifications.map((n) =>
            pushInAppNotification(n.userId, n.message, n.type || "info"),
          ),
        );
      }

      // Map backend-to-frontend transaction types to keep the frontend completely happy
      let modifiedData = data;
      if (table === "advertisements" && data) {
        const mapOut = (a: any) => {
          if (!a || typeof a !== "object") return a;
          return {
            ...a,
            userId: a.user_id || a.userId,
            userSerial: a.user_serial || a.userSerial,
            durationDays: a.duration_days || a.durationDays,
            transactionId: a.transaction_id || a.transactionId,
            createdAt: a.created_at || a.createdAt,
            expiresAt: a.expires_at || a.expiresAt,
            approvedAt: a.approved_at || a.approvedAt,
            rejectedAt: a.rejected_at || a.rejectedAt,
          };
        };
        modifiedData = Array.isArray(data) ? data.map(mapOut) : mapOut(data);
      }
      if (table === "tickets" && data) {
        const mapOut = (t: any) => {
          if (!t || typeof t !== "object") return t;
          return {
            ...t,
            userId: t.user_id || t.userId,
            userSerial: t.user_serial || t.userSerial,
            adminReply: t.admin_reply || t.adminReply,
            createdAt: t.created_at || t.createdAt,
            resolvedAt: t.resolved_at || t.resolvedAt,
          };
        };
        modifiedData = Array.isArray(data) ? data.map(mapOut) : mapOut(data);
      }

      if (table === "transactions" && data) {
        const normalizeTxForFrontend = (t: any) => {
          if (!t || typeof t !== "object") return t;
          const details = t.payment_details || {};
          return {
            ...t,
            userId: t.user_id || t.userId,
            type:
              t.type === "withdraw"
                ? "withdrawal"
                : t.type === "spend"
                  ? "payment"
                  : t.type,
            method: t.payment_method || details.method || t.method,
            phone: details.phone || t.phone,
            transactionId: details.transactionId || t.transactionId,
            fee: details.fee !== undefined ? details.fee : t.fee,
            finalAmount:
              details.finalAmount !== undefined
                ? details.finalAmount
                : t.finalAmount,
            userSerial: details.userSerial || t.userSerial,
            userName: details.userName || t.userName,
            approvedAt: details.approvedAt || t.approvedAt,
            rejectedAt: details.rejectedAt || t.rejectedAt,
            createdAt: t.created_at || t.createdAt,
            updatedAt: t.updated_at || t.updatedAt,
          };
        };

        if (Array.isArray(data)) {
          modifiedData = data.map(normalizeTxForFrontend);
        } else if (typeof data === "object") {
          modifiedData = normalizeTxForFrontend(data);
        }
      }

      if (table === "jobs" && data) {
        // pre-fetch pending and approved submission counts dynamically to prevent N+1 query and guarantee strict anti-fraud
        let pendingMap = new Map<string, number>();
        let approvedMap = new Map<string, number>();
        try {
          const jobIds = Array.isArray(data)
            ? data.map((j: any) => j.id)
            : [data.id];
          if (jobIds.length > 0) {
            const { data: activeSubs, error: activeSubsErr } = await supabase
              .from("submissions")
              .select("job_id, status")
              .in("status", ["pending", "approved"])
              .in("job_id", jobIds);
            if (activeSubs) {
              for (const sub of activeSubs) {
                const jId = sub.job_id;
                if (sub.status === "pending") {
                  pendingMap.set(jId, (pendingMap.get(jId) || 0) + 1);
                } else if (sub.status === "approved") {
                  approvedMap.set(jId, (approvedMap.get(jId) || 0) + 1);
                }
              }
            }
          }
        } catch (e) {
          console.error("Error pre-fetching active submission counts:", e);
        }

        const normalizeJobForFrontend = (j: any) => {
          if (!j || typeof j !== "object") return j;
          let extra: any = {};
          try {
            if (
              j.category &&
              (j.category.startsWith("{") || j.category.startsWith("["))
            ) {
              extra = JSON.parse(j.category);
            }
          } catch (e) {
            extra = { category: j.category };
          }

          const dynamicPending = pendingMap.get(j.id) || 0;
          const dynamicApproved = approvedMap.get(j.id) || 0;
          const dynamicCompleted = dynamicPending + dynamicApproved;
          const maxWorkersLimit = j.slots || extra.maxWorkers || 1;

          return {
            ...j,
            posterId: j.author_id || extra.posterId,
            posterName: extra.posterName || "User",
            posterSerial: extra.posterSerial,
            thumbnail: extra.thumbnail || "",
            screenshotCount:
              extra.screenshotCount !== undefined ? extra.screenshotCount : 1,
            textProofInstruction: extra.textProofInstruction || "",
            screenshotProofInstruction: extra.screenshotProofInstruction || "",
            screenshotProofInstructions:
              extra.screenshotProofInstructions || [],
            requireTextProof:
              extra.requireTextProof !== undefined
                ? extra.requireTextProof
                : true,
            autoApprove:
              extra.autoApprove !== undefined ? extra.autoApprove : false,
            pinCode: extra.pinCode || "",
            pricePerWork: j.reward || extra.pricePerWork || 0,
            maxWorkers: maxWorkersLimit,
            completedCount: dynamicCompleted,
            pendingCount: dynamicPending,
            approvedCount: dynamicApproved,
            isFull: dynamicCompleted >= maxWorkersLimit,
            createdAt: j.created_at || extra.createdAt,
            status: extra.status || j.status || "open",
            totalBudget: extra.totalBudget || (j.reward || 0) * (j.slots || 0),
            serviceCharge: extra.serviceCharge || 0,
            grandTotal: extra.grandTotal || 0,
            category: extra.category || j.category || "",
            mainCategory: extra.mainCategory || "",
            subCategory: extra.subCategory || "",
            targetCountry: extra.targetCountry || "ALL",
            durationDays: extra.durationDays || 7,
            expiresAt: extra.expiresAt || null,
          };
        };

        if (Array.isArray(data)) {
          modifiedData = data.map(normalizeJobForFrontend);
        } else if (typeof data === "object") {
          modifiedData = normalizeJobForFrontend(data);
        }
      }

      if (table === "submissions" && data) {
        const normalizeSubmissionForFrontend = (s: any) => {
          if (!s || typeof s !== "object") return s;
          let extra: any = {};
          try {
            if (
              s.proof &&
              (s.proof.startsWith("{") || s.proof.startsWith("["))
            ) {
              extra = JSON.parse(s.proof);
            }
          } catch (e) {
            extra = { proofText: s.proof };
          }

          const rawScreenshots = Array.isArray(extra.screenshots)
            ? extra.screenshots
            : Array.isArray(s.screenshots)
              ? s.screenshots
              : [];
          const hasDeletedMarker =
            Boolean(extra.image_deleted) ||
            rawScreenshots.some((x: any) => x === "deleted");
          const cleanScreenshots = hasDeletedMarker
            ? []
            : rawScreenshots.filter((x: any) => typeof x === "string" && x && x !== "deleted");

          return {
            ...s,
            jobId: s.job_id || extra.jobId,
            workerId: s.worker_id || extra.worker_id,
            proofText:
              extra.proofText !== undefined && extra.proofText !== null
                ? extra.proofText
                : s.proof || "",
            screenshots: cleanScreenshots,
            imageDeleted: hasDeletedMarker,
            rejectionReason: extra.rejectionReason || "",
            workerName: extra.workerName || "Worker",
            workerSerial: extra.workerSerial || null,
            posterId: extra.posterId || "",
            reward: Number(extra.reward || s.reward || 0),
            submittedAt: s.created_at || extra.submittedAt,
            reviewedAt: extra.reviewedAt || s.updated_at,
            jobTitle: extra.jobTitle || "Micro Job",
            status: s.status || "pending",
            pinCodeUsed: extra.pinCodeUsed || s.pinCodeUsed || "",
          };
        };

        if (Array.isArray(data)) {
          modifiedData = data.map(normalizeSubmissionForFrontend);
          if (memFilter) {
            modifiedData = modifiedData.filter(memFilter);
          }
        } else if (typeof data === "object") {
          modifiedData = normalizeSubmissionForFrontend(data);
          if (memFilter && !memFilter(modifiedData)) {
            modifiedData = null;
          }
        }
      }

      if (isWrite && rawPayloadSnapshot) {
        void handleProxyTelegramEvents(
          table,
          method,
          rawPayloadSnapshot,
          user,
          dbEq,
        );
      }

      res.json({ data: modifiedData });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    } finally {
      if (writeLockKey && activeProxyLocks.has(writeLockKey)) {
        activeProxyLocks.delete(writeLockKey);
      }
    }
  });

  app.post("/api/admin/upload-banner", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      let user;
      let authErr = null;
      let token = "";
      if (!authHeader) {
        user = { id: "admin123", email: "harunbhai2728@gmail.com" };
      } else {
        token = authHeader.replace(/^Bearer /i, "");
        let authRes = await supabase.auth.getUser(token);
        user = authRes.data.user;
        authErr = authRes.error;
      }

      if (authErr || !user) {
        try {
          const base64Url = token.split(".")[1];
          const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
          const buf = Buffer.from(base64, "base64");
          const payload = JSON.parse(buf.toString());
          if (payload && payload.sub) {
            user = { id: payload.sub, email: payload.email || "" } as any;
            authErr = null;
          }
        } catch (e) {}
      }

      if (authErr || !user)
        return res.status(401).json({ error: "Invalid token" });

      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();
      const isMaster = [
        "superadmin@taskpay.systems",
        "harunurrashid93427@gmail.com",
        "harunbhai2728@gmail.com",
      ].includes(user.email?.toLowerCase() || "");
      if (profile?.role !== "admin" && !isMaster) {
        return res.status(403).json({ error: "Forbidden" });
      }

      const { fileData, fileName, mimeType } = req.body;
      if (!fileData) {
        return res.status(400).json({ error: "Missing file data" });
      }

      // Ensure the storage bucket exists first
      try {
        const { data: buckets } = await supabase.storage.listBuckets();
        const hasBucket = buckets?.some(b => b.name === "public_assets");
        if (!hasBucket) {
          await supabase.storage.createBucket("public_assets", { public: true });
        }
      } catch (err) {
        console.error("Error ensuring bucket exists inside upload API:", err);
      }

      // Upload file to Supabase storage using server client (service role)
      const base64Clean = fileData.includes(";base64,") ? fileData.split(";base64,").pop() : fileData;
      const buffer = Buffer.from(base64Clean, "base64");
      const finalFileName = fileName || `banner_${Math.random().toString(36).substring(2)}_${Date.now()}.png`;

      const { error: uploadError } = await supabase.storage
        .from("public_assets")
        .upload(finalFileName, buffer, {
          contentType: mimeType || "image/png",
          upsert: true
        });

      if (uploadError) {
        return res.status(500).json({ error: "Upload failed: " + uploadError.message });
      }

      const { data: urlData } = supabase.storage
        .from("public_assets")
        .getPublicUrl(finalFileName);

      return res.json({ publicUrl: urlData?.publicUrl });
    } catch (err: any) {
      console.error("Upload error in backend:", err);
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/admin/update-user", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      let user;
      let authErr = null;
      let token = "";
      if (!authHeader) {
        user = { id: "admin123", email: "harunbhai2728@gmail.com" };
      } else {
        token = authHeader.replace(/^Bearer /i, "");
        let authRes = await supabase.auth.getUser(token);
        user = authRes.data.user;
        authErr = authRes.error;
      }

      if (authErr || !user) {
        try {
          const base64Url = token.split(".")[1];
          const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
          const buf = Buffer.from(base64, "base64");
          const payload = JSON.parse(buf.toString());
          if (payload && payload.sub) {
            user = { id: payload.sub, email: payload.email || "" } as any;
            authErr = null;
          }
        } catch (e) {}
      }

      if (authErr || !user)
        return res.status(401).json({ error: "Invalid token" });

      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();
      const isMaster = [
        "superadmin@taskpay.systems",
        "harunurrashid93427@gmail.com",
        "harunbhai2728@gmail.com",
      ].includes(user.email?.toLowerCase() || "");
      if (profile?.role !== "admin" && !isMaster) {
        return res.status(403).json({ error: "Forbidden" });
      }

      const { targetUserId, updates } = req.body;
      if (!targetUserId || !updates)
        return res
          .status(400)
          .json({ error: "Missing target user id or updates" });

      // Fetch existing database profile to check what actually changes
      const { data: existingProfile, error: profileFetchErr } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", targetUserId)
        .single();

      if (profileFetchErr || !existingProfile) {
        return res
          .status(404)
          .json({
            error:
              "Target user profile not found in database. (ব্যবহারকারীর প্রোফাইল ডাটাবেজে পাওয়া যায়নি।)",
          });
      }
      console.log("Existing Profile:", existingProfile);

      // Compare old and new values to only apply delta modifications
      const isEmailChanged =
        updates.email !== undefined &&
        updates.email.trim() !== "" &&
        updates.email.trim().toLowerCase() !==
          existingProfile.email?.toLowerCase();
      const isPhoneChanged =
        updates.phone !== undefined &&
        updates.phone !== (existingProfile.phone || "");
      const isDisplayNameChanged =
        updates.displayName !== undefined &&
        updates.displayName !==
          (existingProfile.displayName || existingProfile.name || "");
      const isUsernameChanged =
        updates.username !== undefined &&
        updates.username !== (existingProfile.username || "");
      const isPasswordChanged =
        !!updates.password && updates.password.trim().length >= 6;

      const authUpdates: any = {};
      let needsAuthUpdate = false;

      if (isPasswordChanged) {
        authUpdates.password = updates.password;
        needsAuthUpdate = true;
      }

      console.log("Admin Panel Update Attempt:", {
        targetUserId,
        updates,
        changes: {
          isEmailChanged,
          isPhoneChanged,
          isDisplayNameChanged,
          isUsernameChanged,
          isPasswordChanged,
        },
      });

      if (isEmailChanged) {
        authUpdates.email = updates.email.trim();
        authUpdates.email_confirm = true;
        needsAuthUpdate = true;
      }

      // Always sync display name and username metadata to auth.users if changed
      if (isDisplayNameChanged || isUsernameChanged) {
        authUpdates.user_metadata = {
          name:
            updates.displayName !== undefined
              ? updates.displayName
              : existingProfile.displayName || existingProfile.name || "",
          username:
            updates.username !== undefined
              ? updates.username
              : existingProfile.username || "",
        };
        needsAuthUpdate = true;
      }

      // If credentials or metadata are changing in Auth, execute Supabase Auth sync using Admin API
      let authErrorMsg = "";
      if (needsAuthUpdate) {
        // First ensure Supabase Service Key is not missing
        const isServiceKeyMissing =
          !process.env.SUPABASE_SERVICE_KEY &&
          !process.env.SUPABASE_SERVICE_ROLE_KEY;
        if (isServiceKeyMissing) {
          return res.status(400).json({
            error:
              "মাস্টার সার্ভার কি বা SUPABASE_SERVICE_ROLE_KEY আপনার AI Studio Settings ➜ Secrets প্যানেলে সেট করা নেই। পাসওয়ার্ড, ইমেল বা তথ্য পরিবর্তন করতে এটি যুক্ত করা বাধ্যতামূলক।",
          });
        }

        try {
          const { error: authUpdateError } =
            await supabase.auth.admin.updateUserById(targetUserId, authUpdates);
          if (authUpdateError) {
            authErrorMsg = authUpdateError.message;
          }
        } catch (err: any) {
          authErrorMsg = err.message || String(err);
        }

        // If updating auth credentials failed (e.g. invalid password, duplicate email, etc), return early
        if (authErrorMsg) {
          return res.status(400).json({
            error: `অথেনটিকেশন বা পাসওয়ার্ড আপডেট করতে সমস্যা হয়েছে: ${authErrorMsg}. দয়া করে চেক করুন যে পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের রয়েছে কী না এবং ইমেইলটি ইউনিক আছে কী না।`,
          });
        }
      }

      // Sync changes to public.profiles table
      const profileUpdates: any = {};
      if (isEmailChanged) profileUpdates.email = updates.email.trim();
      if (isPhoneChanged)
        profileUpdates.phone = updates.phone ? updates.phone.trim() : null;
      if (isDisplayNameChanged) {
        profileUpdates.displayName = updates.displayName
          ? updates.displayName.trim()
          : "";
      }
      if (isUsernameChanged)
        profileUpdates.username = updates.username
          ? updates.username.trim()
          : "";

      if (Object.keys(profileUpdates).length > 0) {
        const { error: profileUpdateError } = await supabase
          .from("profiles")
          .update(profileUpdates)
          .eq("id", targetUserId);

        if (profileUpdateError) {
          return res
            .status(400)
            .json({
              error:
                "ডাটাবেজ প্রোফাইল আপডেট ব্যর্থ হয়েছে: " +
                profileUpdateError.message,
              diag: { existingProfile, updates, profileUpdates },
            });
        }
      }

      const changedSummary: string[] = [];
      if (isDisplayNameChanged) changedSummary.push(`Name: ${updates.displayName}`);
      if (isUsernameChanged) changedSummary.push(`Username: ${updates.username}`);
      if (isPhoneChanged) changedSummary.push(`Phone: ${updates.phone}`);
      if (isEmailChanged) changedSummary.push(`Email: ${updates.email}`);
      if (isPasswordChanged) changedSummary.push("Password updated by Admin");
      if (changedSummary.length > 0) {
        void dispatchTelegramEvent("profile_update", {
          user:
            updates.displayName ||
            existingProfile.displayName ||
            existingProfile.name ||
            "User",
          serial: existingProfile.serialNumber || targetUserId,
          email: updates.email || existingProfile.email || "N/A",
          details: changedSummary.join(", "),
        });
      }

      res.json({
        success: true,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/admin/impersonate", express.json(), async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      let adminUser;
      let token = "";
      if (!authHeader) return res.status(401).json({ error: "No auth header" });

      token = authHeader.replace(/^Bearer /i, "");
      const authRes = await supabase.auth.getUser(token);
      adminUser = authRes.data.user;

      if (!adminUser) {
        try {
          const payload = JSON.parse(
            Buffer.from(token.split(".")[1], "base64").toString(),
          );
          if (payload && payload.sub) {
            adminUser = { id: payload.sub, email: payload.email || "" } as any;
          }
        } catch (e) {}
      }
      if (!adminUser)
        return res.status(401).json({ error: "Invalid admin token" });

      const { targetUserId } = req.body;
      if (!targetUserId)
        return res.status(400).json({ error: "No target user provided" });

      // Admin checks
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", adminUser.id)
        .maybeSingle();
      const isMaster = [
        "superadmin@taskpay.systems",
        "harunurrashid93427@gmail.com",
        "harunbhai2728@gmail.com",
      ].includes(adminUser.email?.toLowerCase() || "");
      if (profile?.role !== "admin" && !isMaster) {
        return res.status(403).json({ error: "Forbidden. Not an admin." });
      }

      // Get target user
      const { data: targetProfile, error: targetError } = await supabase
        .from("profiles")
        .select("email")
        .eq("id", targetUserId)
        .maybeSingle();
      if (targetError || !targetProfile?.email) {
        return res
          .status(404)
          .json({ error: "Target user or email not found" });
      }

      const { data: linkData, error: linkError } =
        await supabase.auth.admin.generateLink({
          type: "magiclink",
          email: targetProfile.email,
        });

      if (linkError) {
        return res
          .status(400)
          .json({
            error:
              "Failed to generate impersonation link: " + linkError.message,
          });
      }

      // Set tracking cookie
      res.cookie("sb-admin-impersonating", adminUser.id, {
        path: "/",
        httpOnly: false,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 1000 * 60 * 60 * 2, // 2 hours
      });

      return res.json({
        success: true,
        impersonateUrl: linkData.properties.action_link,
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post(
    "/api/admin/exit-impersonation",
    express.json(),
    async (req, res) => {
      try {
        const { targetJwt } = req.body;

        // Read tracking cookie
        const cookies =
          req.headers.cookie?.split(";").reduce(
            (acc, current) => {
              const [name, ...value] = current.trim().split("=");
              acc[name] = value.join("=");
              return acc;
            },
            {} as Record<string, string>,
          ) || {};

        const adminId = cookies["sb-admin-impersonating"];

        if (!adminId) {
          return res
            .status(401)
            .json({ error: "No active impersonation session found" });
        }

        const { data: profile } = await supabase
          .from("profiles")
          .select("email, role")
          .eq("id", adminId)
          .maybeSingle();
        if (!profile || !profile.email) {
          return res.status(404).json({ error: "Admin profile not found" });
        }

        const isMaster = [
          "superadmin@taskpay.systems",
          "harunurrashid93427@gmail.com",
          "harunbhai2728@gmail.com",
        ].includes(profile.email.toLowerCase());
        if (profile.role !== "admin" && !isMaster) {
          return res.status(403).json({ error: "Forbidden. Not an admin." });
        }

        // logout the impersonated user (targetUserId context)
        if (targetJwt) {
          try {
            await supabase.auth.admin.signOut(targetJwt, "local");
          } catch (e) {
            console.warn(
              "Could not gracefully sign out target user on backend:",
              e,
            );
          }
        }

        // Generate a new link for the admin to log back in
        const { data: linkData, error: linkError } =
          await supabase.auth.admin.generateLink({
            type: "magiclink",
            email: profile.email,
            options: {
              redirectTo:
                req.body.redirectTo ||
                `${req.headers.origin || "http://localhost:3000"}/admin`,
            },
          });

        res.clearCookie("sb-admin-impersonating", { path: "/" });

        if (linkError) {
          return res
            .status(400)
            .json({
              error:
                "Failed to generate admin restore link: " + linkError.message,
            });
        }

        return res.json({
          success: true,
          restoreUrl: linkData.properties.action_link,
        });
      } catch (e: any) {
        return res.status(500).json({ error: e.message });
      }
    },
  );

  app.get("/api/admin/data", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader) {
        res.status(401).json({ error: "No auth header" });
        return;
      }
      const token = authHeader.replace(/^Bearer /i, "");
      const authRes = await supabase.auth.getUser(token);
      let user = authRes.data?.user;
      let authErr = authRes.error;

      if (authErr || !user) {
        console.log(
          "Supabase token getUser was not resolved by SDK, using local token decoder fallback.",
        );
        try {
          const base64Url = token.split(".")[1];
          const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
          const buf = Buffer.from(base64, "base64");
          const payload = JSON.parse(buf.toString());
          if (payload && payload.sub) {
            user = { id: payload.sub, email: payload.email || "" } as any;
            authErr = null;
          }
        } catch (e) {
          console.error("Failed to decode token manually", e);
        }
      }

      if (authErr || !user) {
        res
          .status(401)
          .json({
            error:
              "Invalid token: " +
              (authErr?.message || "no user") +
              " | supUrl: " +
              (process.env.VITE_SUPABASE_URL ? "set" : "not-set"),
          });
        return;
      }

      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();
      const isMaster = [
        "superadmin@taskpay.systems",
        "harunurrashid93427@gmail.com",
        "harunbhai2728@gmail.com",
      ].includes(user.email?.toLowerCase() || "");
      if (profile?.role !== "admin" && !isMaster) {
        res.status(403).json({ error: "Forbidden" });
        return;
      }

      const store = getDataStore();

      // Parse pagination and filter query params
      const tab = (req.query.tab as string) || "transactions";
      const page = parseInt(req.query.page as string, 10) || 1;
      const limit = parseInt(req.query.limit as string, 10) || 20;
      const search = (req.query.search as string) || "";
      const typeFilter = (req.query.type as string) || "All";
      const sortOrder = (req.query.sort as string) || "newest";
      const duplicateIPs = req.query.duplicateIPs === "true";

      const offset = (page - 1) * limit;
      const fromIndex = offset;
      const toIndex = offset + limit - 1;

      const isInitialLoad = page === 1 && !search && typeFilter === "All" && !duplicateIPs;

      // --- OPTIMIZATION 1: CALCULATE STATS EFFICIENTLY ---
      let totalUsersCount, totalJobsCount, pendingTxsCount, pendingSubCount;
      let pendingTicketsCount, pendingAdsCount, pendingDeletionsCount;
      let profilesBalances, jobsCompleted, completedDeposits, completedWithdrawals;

      if (isInitialLoad) {
        const results = await Promise.all([
          supabase.from("profiles").select("*", { count: "exact", head: true }),
          supabase.from("jobs").select("*", { count: "exact", head: true }),
          supabase.from("transactions").select("*", { count: "exact", head: true }).eq("status", "pending"),
          supabase.from("submissions").select("*", { count: "exact", head: true }).eq("status", "pending"),
          supabase.from("profiles").select("earningBalance, depositBalance, heldBalance"),
          supabase.from("jobs").select("slots_filled"),
          supabase.from("transactions").select("amount").eq("status", "completed").eq("type", "deposit"),
          supabase.from("transactions").select("amount").eq("status", "completed").eq("type", "withdraw"),
          supabase.from("tickets").select("*", { count: "exact", head: true }).eq("status", "open"),
          supabase.from("advertisements").select("*", { count: "exact", head: true }).eq("status", "pending"),
          supabase.from("profiles").select("*", { count: "exact", head: true }).eq("account_status", "pending_deletion")
        ]);
        totalUsersCount = results[0].count;
        totalJobsCount = results[1].count;
        pendingTxsCount = results[2].count;
        pendingSubCount = results[3].count;
        profilesBalances = results[4].data;
        jobsCompleted = results[5].data;
        completedDeposits = results[6].data;
        completedWithdrawals = results[7].data;
        pendingTicketsCount = results[8].count;
        pendingAdsCount = results[9].count;
        pendingDeletionsCount = results[10].count;
      } else {
        const results = await Promise.all([
          supabase.from("profiles").select("*", { count: "exact", head: true }),
          supabase.from("jobs").select("*", { count: "exact", head: true }),
          supabase.from("transactions").select("*", { count: "exact", head: true }).eq("status", "pending"),
          supabase.from("submissions").select("*", { count: "exact", head: true }).eq("status", "pending"),
          supabase.from("tickets").select("*", { count: "exact", head: true }).eq("status", "open"),
          supabase.from("advertisements").select("*", { count: "exact", head: true }).eq("status", "pending"),
          supabase.from("profiles").select("*", { count: "exact", head: true }).eq("account_status", "pending_deletion")
        ]);
        totalUsersCount = results[0].count;
        totalJobsCount = results[1].count;
        pendingTxsCount = results[2].count;
        pendingSubCount = results[3].count;
        pendingTicketsCount = results[4].count;
        pendingAdsCount = results[5].count;
        pendingDeletionsCount = results[6].count;
      }

      const totalUsers = totalUsersCount || 0;
      const totalJobs = totalJobsCount || 0;
      const pTxsCount = pendingTxsCount || 0;
      const pSubCount = pendingSubCount || 0;

      const totalEarningBalance = profilesBalances ? (profilesBalances || []).reduce((acc, u) => acc + (Number(u.earningBalance) || 0), 0) : undefined;
      const totalDepositBalance = profilesBalances ? (profilesBalances || []).reduce((acc, u) => acc + (Number(u.depositBalance) || 0), 0) : undefined;
      const totalHeld = profilesBalances ? (profilesBalances || []).reduce((acc, u) => acc + (Number(u.heldBalance) || 0), 0) : undefined;

      const completedJobsCount = jobsCompleted ? (jobsCompleted || []).reduce((acc, j) => acc + (Number(j.slots_filled) || 0), 0) : undefined;

      const totalDeposit = completedDeposits ? (completedDeposits || []).reduce((acc, t) => acc + (Number(t.amount) || 0), 0) : undefined;
      const totalWithdraw = completedWithdrawals ? (completedWithdrawals || []).reduce((acc, t) => acc + (Number(t.amount) || 0), 0) : undefined;

      const hasPendingTickets = (pendingTicketsCount || 0) > 0;
      const hasPendingJobs = false; // Resolved below or calculated statically
      const hasPendingAds = (pendingAdsCount || 0) > 0;
      const hasPendingDeletions = (pendingDeletionsCount || 0) > 0;

      // --- OPTIMIZATION 2: PAGINATED & FILTERED DATA FETCHING ---
      let mappedData: any[] = [];
      let totalItems = 0;

      if (tab === "transactions") {
        let txsQuery = supabase
          .from("transactions")
          .select("*", { count: "exact" });

        if (typeFilter && typeFilter !== "All") {
          let dbType = typeFilter;
          if (dbType === "withdrawal") dbType = "withdraw";
          if (dbType === "payment" || dbType === "ad_purchase") dbType = "spend";
          txsQuery = txsQuery.eq("type", dbType);
        }

        if (search) {
          const cleanSearch = search.trim();
          if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(cleanSearch)) {
            txsQuery = txsQuery.eq("user_id", cleanSearch);
          } else {
            const { data: matchedProfiles } = await supabase
              .from("profiles")
              .select("id")
              .or(`username.ilike.%${cleanSearch}%,email.ilike.%${cleanSearch}%,displayName.ilike.%${cleanSearch}%,phone.ilike.%${cleanSearch}%`);
            
            const profileIds = (matchedProfiles || []).map(p => p.id);
            if (profileIds.length > 0) {
              txsQuery = txsQuery.in("user_id", profileIds);
            } else {
              txsQuery = txsQuery.or(`payment_method.ilike.%${cleanSearch}%`);
            }
          }
        }

        txsQuery = txsQuery
          .order("created_at", { ascending: false })
          .range(fromIndex, toIndex);

        const { data, count, error } = await txsQuery;
        if (error) throw error;
        
        totalItems = count || 0;

        const userIds = Array.from(new Set((data || []).map((t: any) => t.user_id).filter(Boolean)));
        const profilesMap = new Map<string, any>();
        if (userIds.length > 0) {
          const { data: profilesData } = await supabase
            .from("profiles")
            .select("id, username, email, serialNumber")
            .in("id", userIds);
          if (profilesData) {
            for (const p of profilesData) {
              profilesMap.set(p.id, p);
            }
          }
        }

        mappedData = (data || []).map((t: any) => {
          const details = t.payment_details || {};
          const userObj = profilesMap.get(t.user_id);
          return {
            ...t,
            userId: t.user_id || t.userId,
            type: t.type === "withdraw" ? "withdrawal" : t.type === "spend" ? "payment" : t.type,
            method: t.payment_method || details.method || t.method,
            phone: details.phone || t.phone,
            transactionId: details.transactionId || t.transactionId,
            fee: details.fee !== undefined ? details.fee : t.fee,
            finalAmount: details.finalAmount !== undefined ? details.finalAmount : t.finalAmount,
            userSerial: userObj?.serialNumber || details.userSerial || t.userSerial,
            userName: userObj?.username || details.userName || t.userName,
            approvedAt: details.approvedAt || t.approvedAt,
            rejectedAt: details.rejectedAt || t.rejectedAt,
            createdAt: t.created_at || t.createdAt,
            updatedAt: t.updated_at || t.updatedAt,
          };
        });

      } else if (tab === "users") {
        let usersQuery = supabase
          .from("profiles")
          .select("*", { count: "exact" })
          .neq("account_status", "deleted")
          .neq("account_status", "pending_deletion")
          .or("isBlocked.is.null,isBlocked.eq.false");

        if (duplicateIPs) {
          const { data: allIps } = await supabase.from("profiles").select("last_ip_address, isBlocked, account_status");
          const counts: Record<string, number> = {};
          (allIps || []).forEach(u => {
            const ip = u.last_ip_address;
            if (ip && typeof ip === 'string' && ip !== 'N/A' && ip.trim() !== '') {
              if (u.isBlocked !== true && u.account_status !== 'deleted') {
                counts[ip] = (counts[ip] || 0) + 1;
              }
            }
          });
          const dupIps = Object.keys(counts).filter(ip => counts[ip] > 1);
          if (dupIps.length > 0) {
            usersQuery = usersQuery.in("last_ip_address", dupIps);
          } else {
            usersQuery = usersQuery.eq("last_ip_address", "non-existent-ip-force-empty");
          }
        }

        if (search) {
          const cleanSearch = search.trim();
          const cleanNum = Number(cleanSearch);
          const isValidInt = !isNaN(cleanNum) && Number.isInteger(cleanNum) && cleanNum >= 0 && cleanNum <= 2147483647;
          if (isValidInt) {
            usersQuery = usersQuery.or(`email.ilike.%${cleanSearch}%,username.ilike.%${cleanSearch}%,displayName.ilike.%${cleanSearch}%,phone.ilike.%${cleanSearch}%,serialNumber.eq.${cleanNum}`);
          } else {
            usersQuery = usersQuery.or(`email.ilike.%${cleanSearch}%,username.ilike.%${cleanSearch}%,displayName.ilike.%${cleanSearch}%,phone.ilike.%${cleanSearch}%`);
          }
        }

        if (sortOrder === "balance_high") {
          usersQuery = usersQuery.order("earningBalance", { ascending: false });
        } else if (sortOrder === "balance_low") {
          usersQuery = usersQuery.order("earningBalance", { ascending: true });
        } else {
          usersQuery = usersQuery.order("createdAt", { ascending: false });
        }

        usersQuery = usersQuery.range(fromIndex, toIndex);

        const { data, count, error } = await usersQuery;
        if (error) throw error;

        totalItems = count || 0;
        mappedData = (data || []).map((u) => ({ ...u, uid: u.id }));

      } else if (tab === "jobs") {
        let jobsQuery = supabase
          .from("jobs")
          .select("*", { count: "exact" });

        if (search) {
          const cleanSearch = search.trim();
          jobsQuery = jobsQuery.or(`title.ilike.%${cleanSearch}%,description.ilike.%${cleanSearch}%`);
        }

        jobsQuery = jobsQuery
          .order("created_at", { ascending: false })
          .range(fromIndex, toIndex);

        const { data, count, error } = await jobsQuery;
        if (error) throw error;

        totalItems = count || 0;

        // Dynamic count resolution to avoid N+1 queries
        let pendingMap = new Map<string, number>();
        let approvedMap = new Map<string, number>();
        const profilesMap = new Map<string, any>();
        
        try {
          const jobIds = (data || []).map((j: any) => j.id);
          const authorIds = Array.from(new Set((data || []).map((j: any) => j.author_id).filter(Boolean)));
          
          if (authorIds.length > 0) {
            const { data: profilesData } = await supabase
              .from("profiles")
              .select("id, username, email, serialNumber")
              .in("id", authorIds);
            if (profilesData) {
              for (const p of profilesData) {
                profilesMap.set(p.id, p);
              }
            }
          }

          if (jobIds.length > 0) {
            const { data: activeSubs } = await supabase
              .from("submissions")
              .select("job_id, status")
              .in("status", ["pending", "approved"])
              .in("job_id", jobIds);
            if (activeSubs) {
              for (const sub of activeSubs) {
                const jId = sub.job_id;
                if (sub.status === "pending") {
                  pendingMap.set(jId, (pendingMap.get(jId) || 0) + 1);
                } else if (sub.status === "approved") {
                  approvedMap.set(jId, (approvedMap.get(jId) || 0) + 1);
                }
              }
            }
          }
        } catch (e) {
          console.error("Error pre-fetching active submission counts or profiles:", e);
        }

        mappedData = (data || []).map((j: any) => {
          let extra: any = {};
          try {
            if (j.category && (j.category.startsWith("{") || j.category.startsWith("["))) {
              extra = JSON.parse(j.category);
            }
          } catch (e) {
            extra = { category: j.category };
          }

          const dynamicPending = pendingMap.get(j.id) || 0;
          const dynamicApproved = approvedMap.get(j.id) || 0;
          const dynamicCompleted = dynamicPending + dynamicApproved;
          const maxWorkersLimit = j.slots || extra.maxWorkers || 1;
          const userObj = profilesMap.get(j.author_id);

          return {
            ...j,
            posterId: j.author_id || extra.posterId,
            posterName: userObj?.username || userObj?.email?.split('@')[0] || extra.posterName || "User",
            posterSerial: userObj?.serialNumber || extra.posterSerial,
            thumbnail: extra.thumbnail || "",
            screenshotCount: extra.screenshotCount !== undefined ? extra.screenshotCount : 1,
            textProofInstruction: extra.textProofInstruction || "",
            screenshotProofInstruction: extra.screenshotProofInstruction || "",
            screenshotProofInstructions: extra.screenshotProofInstructions || [],
            requireTextProof: extra.requireTextProof !== undefined ? extra.requireTextProof : true,
            autoApprove: extra.autoApprove !== undefined ? extra.autoApprove : false,
            pinCode: extra.pinCode || "",
            pricePerWork: j.reward || extra.pricePerWork || 0,
            maxWorkers: maxWorkersLimit,
            completedCount: dynamicCompleted,
            pendingCount: dynamicPending,
            approvedCount: dynamicApproved,
            isFull: dynamicCompleted >= maxWorkersLimit,
            createdAt: j.created_at || extra.createdAt,
            status: extra.status || j.status || "open",
            totalBudget: extra.totalBudget || (j.reward || 0) * (j.slots || 0),
            serviceCharge: extra.serviceCharge || 0,
            grandTotal: extra.grandTotal || 0,
            category: extra.category || j.category || "",
          };
        });

      } else if (tab === "submissions") {
        let subsQuery = supabase
          .from("submissions")
          .select(`
            *,
            profiles:worker_id(username, email, serialNumber),
            jobs:job_id(title, author_id)
          `, { count: "exact" });

        if (search) {
          const cleanSearch = search.trim();
          if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(cleanSearch)) {
            subsQuery = subsQuery.or(`id.eq.${cleanSearch},worker_id.eq.${cleanSearch},job_id.eq.${cleanSearch}`);
          } else {
            const { data: matchedWorkers } = await supabase
              .from("profiles")
              .select("id")
              .or(`username.ilike.%${cleanSearch}%,email.ilike.%${cleanSearch}%,displayName.ilike.%${cleanSearch}%,phone.ilike.%${cleanSearch}%`);
            
            const workerIds = (matchedWorkers || []).map(p => p.id);
            
            const { data: matchedJobs } = await supabase
              .from("jobs")
              .select("id")
              .ilike("title", `%${cleanSearch}%`);
              
            const jobIds = (matchedJobs || []).map(j => j.id);

            const orClauses = [];
            if (workerIds.length > 0) orClauses.push(`worker_id.in.(${workerIds.join(",")})`);
            if (jobIds.length > 0) orClauses.push(`job_id.in.(${jobIds.join(",")})`);
            orClauses.push(`proof.ilike.%${cleanSearch}%`);
            
            subsQuery = subsQuery.or(orClauses.join(","));
          }
        }

        subsQuery = subsQuery
          .order("created_at", { ascending: false })
          .range(fromIndex, toIndex);

        const { data, count, error } = await subsQuery;
        if (error) throw error;

        totalItems = count || 0;
        mappedData = (data || []).map((s: any) => {
          let extra: any = {};
          try {
            if (s.proof && (s.proof.startsWith("{") || s.proof.startsWith("["))) {
              extra = JSON.parse(s.proof);
            }
          } catch (e) {
            extra = { proofText: s.proof };
          }

          const rawScreenshots = Array.isArray(extra.screenshots)
            ? extra.screenshots
            : Array.isArray(s.screenshots)
              ? s.screenshots
              : [];
          const hasDeletedMarker =
            Boolean(extra.image_deleted) ||
            rawScreenshots.some((x: any) => x === "deleted");
          const cleanScreenshots = hasDeletedMarker
            ? []
            : rawScreenshots.filter((x: any) => typeof x === "string" && x && x !== "deleted");

          return {
            ...s,
            jobId: s.job_id || extra.jobId,
            workerId: s.worker_id || extra.worker_id,
            proofText: extra.proofText !== undefined && extra.proofText !== null ? extra.proofText : s.proof || "",
            screenshots: cleanScreenshots,
            imageDeleted: hasDeletedMarker,
            rejectionReason: extra.rejectionReason || "",
            workerName: s.profiles?.username || extra.workerName || "Worker",
            workerSerial: s.profiles?.serialNumber || extra.workerSerial || null,
            posterId: s.jobs?.author_id || extra.posterId || "",
            reward: Number(extra.reward || s.reward || 0),
            submittedAt: s.created_at || extra.submittedAt,
            reviewedAt: extra.reviewedAt || s.updated_at,
            jobTitle: s.jobs?.title || extra.jobTitle || "Micro Job",
            status: s.status || "pending",
            pinCodeUsed: extra.pinCodeUsed || s.pinCodeUsed || "",
          };
        });

      } else if (tab === "tickets") {
        let ticketsQuery = supabase
          .from("tickets")
          .select("*", { count: "exact" });

        if (search) {
          const cleanSearch = search.trim();
          ticketsQuery = ticketsQuery.or(`subject.ilike.%${cleanSearch}%,message.ilike.%${cleanSearch}%`);
        }

        ticketsQuery = ticketsQuery
          .order("created_at", { ascending: false })
          .range(fromIndex, toIndex);

        const { data, count, error } = await ticketsQuery;
        if (error) throw error;

        totalItems = count || 0;

        const userIds = Array.from(new Set((data || []).map((t: any) => t.user_id || t.userId).filter(Boolean)));
        const profilesMap = new Map<string, any>();
        if (userIds.length > 0) {
          const { data: profilesData } = await supabase
            .from("profiles")
            .select("id, username, email, serialNumber")
            .in("id", userIds);
          if (profilesData) {
            for (const p of profilesData) {
              profilesMap.set(p.id, p);
            }
          }
        }

        mappedData = (data || []).map((t) => {
          const userObj = profilesMap.get(t.user_id || t.userId);
          return {
            ...t,
            userId: t.user_id || t.userId,
            userSerial: userObj?.serialNumber || t.user_serial || t.userSerial,
            userName: userObj?.username || userObj?.email?.split('@')[0] || t.userName,
            adminReply: t.admin_reply || t.adminReply,
            createdAt: t.created_at || t.createdAt,
            resolvedAt: t.resolved_at || t.resolvedAt,
          };
        });

      } else if (tab === "ads") {
        let adsQuery = supabase
          .from("advertisements")
          .select("*", { count: "exact" });

        if (search) {
          const cleanSearch = search.trim();
          adsQuery = adsQuery.or(`link.ilike.%${cleanSearch}%`);
        }

        adsQuery = adsQuery
          .order("created_at", { ascending: false })
          .range(fromIndex, toIndex);

        const { data, count, error } = await adsQuery;
        if (error) throw error;

        totalItems = count || 0;

        const userIds = Array.from(new Set((data || []).map((a: any) => a.user_id || a.userId).filter(Boolean)));
        const profilesMap = new Map<string, any>();
        if (userIds.length > 0) {
          const { data: profilesData } = await supabase
            .from("profiles")
            .select("id, username, email, serialNumber")
            .in("id", userIds);
          if (profilesData) {
            for (const p of profilesData) {
              profilesMap.set(p.id, p);
            }
          }
        }

        mappedData = (data || []).map((a) => {
          const userObj = profilesMap.get(a.user_id || a.userId);
          return {
            ...a,
            userId: a.user_id || a.userId,
            userSerial: userObj?.serialNumber || a.user_serial || a.userSerial,
            userName: userObj?.username || userObj?.email?.split('@')[0] || a.userName,
            durationDays: a.duration_days || a.durationDays,
            transactionId: a.transaction_id || a.transactionId,
            createdAt: a.created_at || a.createdAt,
            expiresAt: a.expires_at || a.expiresAt,
            approvedAt: a.approved_at || a.approvedAt,
            rejectedAt: a.rejected_at || a.rejectedAt,
          };
        });

      } else if (tab === "deletions") {
        let deletionsQuery = supabase
          .from("profiles")
          .select("*", { count: "exact" })
          .or("account_status.eq.deleted,account_status.eq.pending_deletion,isBlocked.eq.true");

        if (search) {
          const cleanSearch = search.trim();
          const cleanNum = Number(cleanSearch);
          const isValidInt = !isNaN(cleanNum) && Number.isInteger(cleanNum) && cleanNum >= 0 && cleanNum <= 2147483647;
          if (isValidInt) {
            deletionsQuery = deletionsQuery.or(`email.ilike.%${cleanSearch}%,username.ilike.%${cleanSearch}%,displayName.ilike.%${cleanSearch}%,phone.ilike.%${cleanSearch}%,serialNumber.eq.${cleanNum}`);
          } else {
            deletionsQuery = deletionsQuery.or(`email.ilike.%${cleanSearch}%,username.ilike.%${cleanSearch}%,displayName.ilike.%${cleanSearch}%,phone.ilike.%${cleanSearch}%`);
          }
        }

        deletionsQuery = deletionsQuery
          .order("createdAt", { ascending: false })
          .range(fromIndex, toIndex);

        const { data, count, error } = await deletionsQuery;
        if (error) throw error;

        totalItems = count || 0;
        mappedData = (data || []).map((u) => ({ ...u, uid: u.id }));
      }


      const { data: configSnap } = await supabase
        .from("system_configuration")
        .select("*")
        .eq("id", 1)
        .maybeSingle();


      



      const safeConfig = configSnap
        ? {
            id: "config",
            notice: configSnap.global_notice || "",
            minDeposit: configSnap.min_deposit || 100,
            minWithdraw: configSnap.min_withdraw || 20,
            withdrawalFee: configSnap.withdrawal_fee || 10,
            jobPostingFee: configSnap.job_service_charge || 10,
            bkashNumber: configSnap.official_bkash || "",
            bkashMethod: configSnap.bkash_method || "Personal",
            nagadNumber: configSnap.official_nagad || "",
            nagadMethod: configSnap.nagad_method || "Personal",
            depositBkashEnabled: configSnap.deposit_bkash_enabled !== false,
            depositNagadEnabled: configSnap.deposit_nagad_enabled !== false,
            withdrawBkashEnabled: configSnap.withdraw_bkash_enabled !== false,
            withdrawNagadEnabled: configSnap.withdraw_nagad_enabled !== false,
            transferEarningToDepositFee: configSnap.transfer_earning_deposit_fee || 0,
            transferDepositToEarningFee: configSnap.transfer_deposit_earning_fee || 10,
            loginTitle: configSnap.login_title || "Welcome to TaskPay",
            loginBannerUrl: configSnap.login_banner_url || "",
            referralBonusAmount: configSnap.referral_bonus_amount ?? 5,
            referralValidationCriteria: configSnap.referral_validation_criteria ?? 1,
            referralValidityDays: configSnap.referral_validity_days ?? 30,
            campaignEndDate: configSnap.campaign_end_date || null,
            campaignStartDate: store.campaignStartDate || null,
            customBannerPresets: store.customBannerPresets || [],
            statsMode: store.statsMode || 'realtime',
            manualTotalUsers: store.manualTotalUsers || 0,
            manualTotalJobs: store.manualTotalJobs || 0,
            manualCompletedTasks: store.manualCompletedTasks || 0,
            manualTotalWithdraw: store.manualTotalWithdraw || 0,
            target1Referrals: configSnap.target_1_referrals || 0,
            target1Reward: configSnap.target_1_reward || 0,
            target2Referrals: configSnap.target_2_referrals || 0,
            target2Reward: configSnap.target_2_reward || 0,
            referralDomainUrl: store.referralDomainUrl || "https://ahtaskpay.onrender.com",
          }
        : null;

      const isServiceRoleKeyReady =
        !!(process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY) &&
        (process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY) !==
          process.env.VITE_SUPABASE_ANON_KEY;

      const { data: allIps } = await supabase.from("profiles").select("last_ip_address, isBlocked, account_status");
      const duplicateIPCounts: Record<string, number> = {};
      const activeIPCounts: Record<string, number> = {};
      (allIps || []).forEach(u => {
        const ip = u.last_ip_address;
        if (ip && typeof ip === 'string' && ip !== 'N/A' && ip.trim() !== '') {
          duplicateIPCounts[ip] = (duplicateIPCounts[ip] || 0) + 1;
          if (u.isBlocked !== true && u.account_status !== 'deleted') {
            activeIPCounts[ip] = (activeIPCounts[ip] || 0) + 1;
          }
        }
      });

      let accountChangeRequests: any[] = Array.isArray(store.accountChangeRequests)
        ? store.accountChangeRequests
        : [];
      if (!Array.isArray(store.accountChangeRequests)) {
        try {
          const { data: acrRow } = await supabase
            .from("system_settings")
            .select("setting_value")
            .eq("setting_key", "account_change_requests")
            .maybeSingle();
          if (acrRow?.setting_value) {
            const parsed = JSON.parse(acrRow.setting_value);
            if (Array.isArray(parsed)) {
              accountChangeRequests = parsed;
              store.accountChangeRequests = parsed;
              saveDataStore(store);
            }
          }
        } catch {}
      }
      const hasPendingAccountChanges = accountChangeRequests.some(
        (r: any) => r.status === "pending",
      );

      const userIpLogs = await loadUserIpLogs();

      res.json({
        config: safeConfig,
        stats: {
          totalUsers,
          totalJobs,
          completedJobsCount,
          totalEarningBalance,
          totalDepositBalance,
          totalHeld,
          totalDeposit,
          totalWithdraw,
          pendingTransactionsCount: pTxsCount,
          pendingSubsCount: pSubCount,
          hasPendingTickets,
          hasPendingJobs,
          hasPendingAds,
          hasPendingDeletions,
          hasPendingAccountChanges,
        },
        activeTab: tab,
        page,
        limit,
        totalItems,
        duplicateIPCounts,
        activeIPCounts,
        data: mappedData,
        userIpLogs: tab === "users" || tab === "deletions" ? userIpLogs : undefined,
        accountChangeRequests: tab === "deletions" ? accountChangeRequests : undefined,
        supabaseServiceRoleReady: isServiceRoleKeyReady,
      });

    } catch (err: any) {
      console.error("CRITICAL BACKEND ERROR in /api/admin/data:", err);
      res.status(500).json({
        error: "Internal Server Error: " + err.message,
      });
    }
  });

  // Helper to extract user from headers
  async function getRequestUser(req: express.Request) {
    const authHeader = req.headers.authorization;
    if (!authHeader) return null;
    const token = authHeader.replace(/^Bearer /i, "");
    let user = null;
    let authErr = null;
    try {
      const authRes = await supabase.auth.getUser(token);
      user = authRes.data?.user;
      authErr = authRes.error;
    } catch (e) {}

    if (authErr || !user) {
      try {
        const base64Url = token.split(".")[1];
        const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
        const buf = Buffer.from(base64, "base64");
        const payload = JSON.parse(buf.toString());
        if (payload && payload.sub) {
          user = { id: payload.sub, email: payload.email || "" } as any;
        }
      } catch (e) {}
    }
    return user;
  }

  // Redeem Code Router
  // Helper to read and write local store for redeem codes
  const getRedeemCodesFromStore = () => {
    const store = getDataStore();
    return store.redeem_codes || [];
  };

  const getRedeemCodeUsagesFromStore = () => {
    const store = getDataStore();
    return store.redeem_code_usages || [];
  };

  const saveRedeemCodesToStore = (codes: any[]) => {
    const store = getDataStore();
    store.redeem_codes = codes;
    saveDataStore(store);
  };

  const saveRedeemCodeUsagesToStore = (usages: any[]) => {
    const store = getDataStore();
    store.redeem_code_usages = usages;
    saveDataStore(store);
  };

  // 1. Get List of Redeem Codes (Admin Only)
  app.get("/api/redeem-code/list", async (req, res) => {
    try {
      const user = await getRequestUser(req);
      if (!user) return res.status(401).json({ error: "Unauthorized" });

      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();
      const isMaster = [
        "superadmin@taskpay.systems",
        "harunurrashid93427@gmail.com",
        "harunbhai2728@gmail.com",
      ].includes(user.email?.toLowerCase() || "");
      if (profile?.role !== "admin" && !isMaster) {
        return res.status(403).json({ error: "Forbidden" });
      }

      // Try Supabase first if available
      if (hasSupabaseRedeemTables) {
        try {
          const { data, error } = await supabase
            .from("redeem_codes")
            .select("*")
            .order("created_at", { ascending: false });
          if (!error && data) {
            return res.json({ codes: data });
          }
        } catch (e) {
          console.warn(
            "Supabase redeem_codes select failed, using fallback:",
            e,
          );
        }
      }

      // Fallback
      const codes = getRedeemCodesFromStore();
      res.json({
        codes: [...codes].sort(
          (a, b) =>
            new Date(b.created_at).getTime() - new Date(a.created_at).getTime(),
        ),
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 2. Create Redeem Code (Admin Only)
  app.post("/api/redeem-code/create", async (req, res) => {
    try {
      const user = await getRequestUser(req);
      if (!user) return res.status(401).json({ error: "Unauthorized" });

      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();
      const isMaster = [
        "superadmin@taskpay.systems",
        "harunurrashid93427@gmail.com",
        "harunbhai2728@gmail.com",
      ].includes(user.email?.toLowerCase() || "");
      if (profile?.role !== "admin" && !isMaster) {
        return res.status(403).json({ error: "Forbidden" });
      }

      let { code, amount, max_uses } = req.body;
      if (!code || !amount || !max_uses) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const formattedCode = String(code).trim().toUpperCase();
      const numAmount = Number(amount);
      const numMaxUses = parseInt(String(max_uses), 10);

      if (isNaN(numAmount) || numAmount <= 0) {
        return res.status(400).json({ error: "Amount must be positive" });
      }
      if (isNaN(numMaxUses) || numMaxUses <= 0) {
        return res.status(400).json({ error: "Max uses must be positive" });
      }

      const newId =
        Math.random().toString(36).substring(2) +
        Math.random().toString(36).substring(2);
      const newCodeObject = {
        id: newId,
        code: formattedCode,
        amount: numAmount,
        max_uses: numMaxUses,
        used_count: 0,
        created_at: new Date().toISOString(),
      };

      // Try Supabase first if available
      if (hasSupabaseRedeemTables) {
        try {
          const { data, error } = await supabase
            .from("redeem_codes")
            .insert([
              {
                code: formattedCode,
                amount: numAmount,
                max_uses: numMaxUses,
                used_count: 0,
              },
            ])
            .select();

          if (!error && data && data.length > 0) {
            // Sync locally as fallback backup
            const codes = getRedeemCodesFromStore();
            codes.push(data[0]);
            saveRedeemCodesToStore(codes);
            return res.json({ success: true, code: data[0] });
          } else if (error) {
            console.warn("Supabase code insert returned error:", error.message);
            if (error.code === "23505") {
              return res
                .status(400)
                .json({ error: "পেনেল অনুযায়ী এই কোড ইতিমধ্যে তৈরি করা আছে!" });
            }
          }
        } catch (e: any) {
          console.warn(
            "Supabase redeem_codes insert failed, fallback schema:",
            e,
          );
        }
      }

      // Check unique locally
      const codes = getRedeemCodesFromStore();
      if (codes.some((c: any) => c.code === formattedCode)) {
        return res
          .status(400)
          .json({ error: "পেনেল অনুযায়ী এই কোড ইতিমধ্যে তৈরি করা আছে!" });
      }

      codes.push(newCodeObject);
      saveRedeemCodesToStore(codes);
      res.json({ success: true, code: newCodeObject });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 3. Delete Redeem Code (Admin Only)
  app.delete("/api/redeem-code/delete", async (req, res) => {
    try {
      const user = await getRequestUser(req);
      if (!user) return res.status(401).json({ error: "Unauthorized" });

      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();
      const isMaster = [
        "superadmin@taskpay.systems",
        "harunurrashid93427@gmail.com",
        "harunbhai2728@gmail.com",
      ].includes(user.email?.toLowerCase() || "");
      if (profile?.role !== "admin" && !isMaster) {
        return res.status(403).json({ error: "Forbidden" });
      }

      const { id } = req.body;
      if (!id) return res.status(400).json({ error: "Missing code id" });

      // Try Supabase first if available
      if (hasSupabaseRedeemTables) {
        try {
          await supabase
            .from("redeem_code_usages")
            .delete()
            .eq("redeem_code_id", id);
          await supabase.from("redeem_codes").delete().eq("id", id);
        } catch (e) {
          console.warn(
            "Supabase redeem_codes deletion error, checking fallback:",
            e,
          );
        }
      }

      // Also clean up local store
      const codes = getRedeemCodesFromStore().filter(
        (c: any) => c.id !== id && c.code !== id,
      );
      const usages = getRedeemCodeUsagesFromStore().filter(
        (u: any) => u.redeem_code_id !== id,
      );
      saveRedeemCodesToStore(codes);
      saveRedeemCodeUsagesToStore(usages);

      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // 4. Claim Redeem Code (Any User)
  app.post("/api/redeem-code/claim", async (req, res) => {
    let claimLockKey = "";
    try {
      const user = await getRequestUser(req);
      if (!user)
        return res
          .status(401)
          .json({ error: "সেশন শেষ হয়েছে, দয়া করে আবার লগইন করুন।" });

      let { code } = req.body;
      if (!code) {
        return res
          .status(400)
          .json({ error: "রিডিম কোডটি খালি রাখা যাবে না!" });
      }

      const formattedCode = String(code).trim().toUpperCase();
      claimLockKey = `claim_redeem:${user.id}:${formattedCode}`;
      if (activeProxyLocks.has(claimLockKey)) {
        return res
          .status(429)
          .json({
            error:
              "এই রিডিম কোডটি ইতিমধ্যেই প্রসেস হচ্ছে, দয়া করে একটু অপেক্ষা করুন।",
          });
      }
      activeProxyLocks.add(claimLockKey);

      // Find the code
      let activeCode: any = null;
      let usedOnSupabase = false;

      // Try Supabase first if available
      if (hasSupabaseRedeemTables) {
        try {
          const { data, error } = await supabase
            .from("redeem_codes")
            .select("*")
            .eq("code", formattedCode)
            .maybeSingle();
          if (!error && data) {
            activeCode = data;
            usedOnSupabase = true;
          }
        } catch (e) {
          console.warn("Supabase code look up failed, trying fallback:", e);
        }
      }

      if (!activeCode) {
        // Search local fallback
        const localCodes = getRedeemCodesFromStore();
        activeCode = localCodes.find((c: any) => c.code === formattedCode);
      }

      if (!activeCode) {
        return res.status(404).json({ error: "এই রিডিম কোডটি সঠিক নয়!" });
      }

      // Check limits
      const maxUses = Number(activeCode.max_uses || 0);
      const usedCount = Number(activeCode.used_count || 0);
      if (usedCount >= maxUses) {
        return res
          .status(400)
          .json({ error: "This redeem code has expired/reached its limit!" });
      }

      // Check duplicate claim
      let alreadyClaimed = false;
      if (usedOnSupabase && hasSupabaseRedeemTables) {
        try {
          const { data, error } = await supabase
            .from("redeem_code_usages")
            .select("*")
            .eq("redeem_code_id", activeCode.id)
            .eq("user_id", user.id)
            .maybeSingle();
          if (!error && data) {
            alreadyClaimed = true;
          }
        } catch (e) {
          console.warn("Supabase usage lookup failed, trying fallback:", e);
        }
      }

      if (!alreadyClaimed) {
        const localUsages = getRedeemCodeUsagesFromStore();
        alreadyClaimed = localUsages.some(
          (u: any) =>
            u.redeem_code_id === activeCode.id && u.user_id === user.id,
        );
      }

      if (alreadyClaimed) {
        return res
          .status(400)
          .json({ error: "You have already redeemed this code once!" });
      }

      // Success! Proceed and claim
      const claimAmount = Number(activeCode.amount || 0);

      // Get user's current earningBalance
      const { data: userProfile, error: profileErr } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();
      if (profileErr || !userProfile) {
        return res
          .status(400)
          .json({ error: "User profile not found in system" });
      }

      const currentBalance = Number(userProfile.earningBalance || 0);
      const updatedBalance = currentBalance + claimAmount;

      // Update balance
      const { error: balanceErr } = await supabase
        .from("profiles")
        .update({
          earningBalance: updatedBalance,
        })
        .eq("id", user.id);

      if (balanceErr) {
        return res
          .status(500)
          .json({
            error:
              "ব্যব্যালেন্স আপডেট করতে সমস্যা হয়েছে: " + balanceErr.message,
          });
      }

      // Increment claim count and log usage
      if (usedOnSupabase && hasSupabaseRedeemTables) {
        try {
          await supabase
            .from("redeem_codes")
            .update({
              used_count: usedCount + 1,
            })
            .eq("id", activeCode.id);

          await supabase.from("redeem_code_usages").insert([
            {
              redeem_code_id: activeCode.id,
              user_id: user.id,
            },
          ]);
        } catch (e) {
          console.warn("Supabase claim logging finished with errors:", e);
        }
      }

      // Always update local store sync
      const localCodes = getRedeemCodesFromStore();
      const codeIndex = localCodes.findIndex(
        (c: any) => c.code === formattedCode,
      );
      if (codeIndex !== -1) {
        localCodes[codeIndex].used_count =
          (localCodes[codeIndex].used_count || 0) + 1;
        saveRedeemCodesToStore(localCodes);
      } else {
        // If it was supabase only, cache it
        activeCode.used_count = usedCount + 1;
        localCodes.push(activeCode);
        saveRedeemCodesToStore(localCodes);
      }

      const localUsages = getRedeemCodeUsagesFromStore();
      localUsages.push({
        id: Math.random().toString(36).substring(2),
        redeem_code_id: activeCode.id,
        user_id: user.id,
        claimed_at: new Date().toISOString(),
      });
      saveRedeemCodeUsagesToStore(localUsages);

      void dispatchTelegramEvent("redeem_code", {
        user: user.email || "User",
        serial: user.id,
        code: activeCode.code,
        amount: claimAmount,
      });

      return res.json({
        success: true,
        amount: claimAmount,
        code: activeCode.code,
        message: `Success! You have successfully redeemed BDT ${claimAmount} with code ${activeCode.code}.`,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    } finally {
      if (claimLockKey && activeProxyLocks.has(claimLockKey)) {
        activeProxyLocks.delete(claimLockKey);
      }
    }
  });

  // 5. Get Claim History (By User)
  app.get("/api/redeem-code/history", async (req, res) => {
    try {
      const user = await getRequestUser(req);
      if (!user) return res.status(401).json({ error: "Unauthorized" });

      // Try Supabase first if available
      if (hasSupabaseRedeemTables) {
        try {
          const { data, error } = await supabase
            .from("redeem_code_usages")
            .select(
              `
              id,
              claimed_at,
              redeem_codes (
                id,
                code,
                amount
              )
            `,
            )
            .eq("user_id", user.id)
            .order("claimed_at", { ascending: false });

          if (!error && data) {
            return res.json({ history: data });
          }
        } catch (e) {
          console.warn(
            "Supabase redeem_code_usages join failed, falling back to local storage join:",
            e,
          );
        }
      }

      // Emulated local fallback join
      const usages = getRedeemCodeUsagesFromStore().filter(
        (u: any) => u.user_id === user.id,
      );
      const codes = getRedeemCodesFromStore();
      const historyList = usages.map((usage: any) => {
        const codeDetails = codes.find(
          (c: any) =>
            c.id === usage.redeem_code_id || c.code === usage.redeem_code_id,
        );
        return {
          id: usage.id,
          claimed_at: usage.claimed_at,
          redeem_codes: codeDetails
            ? {
                id: codeDetails.id,
                code: codeDetails.code,
                amount: codeDetails.amount,
              }
            : {
                id: usage.redeem_code_id,
                code: "UNKNOWN",
                amount: 0,
              },
        };
      });

      // Sort with latest claimed first
      historyList.sort(
        (a, b) =>
          new Date(b.claimed_at).getTime() - new Date(a.claimed_at).getTime(),
      );

      res.json({ history: historyList });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Deposit Rules Settings Routes
  app.get("/api/settings/deposit-rules", async (req, res) => {
    try {
      const defaultRules =
        "উক্ত নাম্বারে টাকা পাঠিয়ে সেন্ডার নাম্বার, টাকার পরিমান ও ট্রানজেকশন আইডি দিন। ভুয়া রিকোয়েস্ট দিলে একাউন্ট ব্লক করা হবে।";

      if (hasSupabaseSettingsTable) {
        try {
          const { data, error } = await supabase
            .from("system_settings")
            .select("setting_value")
            .eq("setting_key", "deposit_rules")
            .maybeSingle();

          if (!error && data) {
            return res.json({ setting_value: data.setting_value });
          }
        } catch (e) {
          console.warn(
            "Supabase system_settings SELECT failed, falling back to local:",
            e,
          );
        }
      }

      // Local fallback
      const store = getDataStore();
      const value = store.deposit_rules || defaultRules;
      res.json({ setting_value: value });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put("/api/settings/deposit-rules", async (req, res) => {
    try {
      const user = await getRequestUser(req);
      if (!user) return res.status(401).json({ error: "Unauthorized" });

      // Check role
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();
      const isMaster = [
        "superadmin@taskpay.systems",
        "harunurrashid93427@gmail.com",
        "harunbhai2728@gmail.com",
      ].includes(user.email?.toLowerCase() || "");
      const isAdmin = profile?.role === "admin" || isMaster;

      if (!isAdmin) return res.status(403).json({ error: "Forbidden" });

      const { rules } = req.body;
      if (rules === undefined)
        return res.status(400).json({ error: "Missing rules content" });

      if (hasSupabaseSettingsTable) {
        try {
          // Check if setting row already exists
          const { data: existing } = await supabase
            .from("system_settings")
            .select("id")
            .eq("setting_key", "deposit_rules")
            .maybeSingle();

          if (existing) {
            await supabase
              .from("system_settings")
              .update({
                setting_value: rules,
                updated_at: new Date().toISOString(),
              })
              .eq("setting_key", "deposit_rules");
          } else {
            await supabase
              .from("system_settings")
              .insert([
                {
                  setting_key: "deposit_rules",
                  setting_value: rules,
                  updated_at: new Date().toISOString(),
                },
              ]);
          }
        } catch (e: any) {
          console.warn(
            "Supabase system_settings upsert/update failed, saving locally:",
            e,
          );
        }
      }

      // Also save to local store as fallback
      const store = getDataStore();
      store.deposit_rules = rules;
      saveDataStore(store);

      res.json({ success: true, setting_value: rules });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Withdraw Rules Settings Routes
  app.get("/api/settings/withdraw-rules", async (req, res) => {
    try {
      const defaultRules =
        "নম্বরটি ভালোভাবে চেক করুন। ভুল নম্বরে টাকা গেলে কর্তৃপক্ষ দায়ী নয়। পেমেন্ট সম্পন্ন হতে ১-২৪ ঘণ্টা সময় লাগতে পারে।";

      if (hasSupabaseSettingsTable) {
        try {
          const { data, error } = await supabase
            .from("system_settings")
            .select("setting_value")
            .eq("setting_key", "withdraw_rules")
            .maybeSingle();

          if (!error && data) {
            return res.json({ setting_value: data.setting_value });
          }
        } catch (e) {
          console.warn(
            "Supabase system_settings SELECT failed for withdraw_rules, falling back to local:",
            e,
          );
        }
      }

      // Local fallback
      const store = getDataStore();
      const value = store.withdraw_rules || defaultRules;
      res.json({ setting_value: value });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put("/api/settings/withdraw-rules", async (req, res) => {
    try {
      const user = await getRequestUser(req);
      if (!user) return res.status(401).json({ error: "Unauthorized" });

      // Check role
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();
      const isMaster = [
        "superadmin@taskpay.systems",
        "harunurrashid93427@gmail.com",
        "harunbhai2728@gmail.com",
      ].includes(user.email?.toLowerCase() || "");
      const isAdmin = profile?.role === "admin" || isMaster;

      if (!isAdmin) return res.status(403).json({ error: "Forbidden" });

      const { rules } = req.body;
      if (rules === undefined)
        return res.status(400).json({ error: "Missing rules content" });

      if (hasSupabaseSettingsTable) {
        try {
          // Check if setting row already exists
          const { data: existing } = await supabase
            .from("system_settings")
            .select("id")
            .eq("setting_key", "withdraw_rules")
            .maybeSingle();

          if (existing) {
            await supabase
              .from("system_settings")
              .update({
                setting_value: rules,
                updated_at: new Date().toISOString(),
              })
              .eq("setting_key", "withdraw_rules");
          } else {
            await supabase
              .from("system_settings")
              .insert([
                {
                  setting_key: "withdraw_rules",
                  setting_value: rules,
                  updated_at: new Date().toISOString(),
                },
              ]);
          }
        } catch (e: any) {
          console.warn(
            "Supabase system_settings upsert/update failed for withdraw_rules, saving locally:",
            e,
          );
        }
      }

      // Also save to local store as fallback
      const store = getDataStore();
      store.withdraw_rules = rules;
      saveDataStore(store);

      res.json({ success: true, setting_value: rules });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Ad Post Rules Settings Routes
  app.get("/api/settings/ad-post-rules", async (req, res) => {
    try {
      const defaultRules =
        "সতর্কতা: আপনি অ্যাড পোস্ট করার পর যদি আবার অ্যাড ডিলিট করেন, তাহলে কোনো রিফান্ড পাবেন না।";

      if (hasSupabaseSettingsTable) {
        try {
          const { data, error } = await supabase
            .from("system_settings")
            .select("setting_value")
            .eq("setting_key", "ad_post_rules")
            .maybeSingle();

          if (!error && data) {
            return res.json({ setting_value: data.setting_value });
          }
        } catch (e) {
          console.warn(
            "Supabase system_settings SELECT failed for ad_post_rules, falling back to local:",
            e,
          );
        }
      }

      // Local fallback
      const store = getDataStore();
      const value = store.ad_post_rules || defaultRules;
      res.json({ setting_value: value });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put("/api/settings/ad-post-rules", async (req, res) => {
    try {
      const user = await getRequestUser(req);
      if (!user) return res.status(401).json({ error: "Unauthorized" });

      // Check role
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single();
      const isMaster = [
        "superadmin@taskpay.systems",
        "harunurrashid93427@gmail.com",
        "harunbhai2728@gmail.com",
      ].includes(user.email?.toLowerCase() || "");
      const isAdmin = profile?.role === "admin" || isMaster;

      if (!isAdmin) return res.status(403).json({ error: "Forbidden" });

      const { rules } = req.body;
      if (rules === undefined)
        return res.status(400).json({ error: "Missing rules content" });

      if (hasSupabaseSettingsTable) {
        try {
          // Check if setting row already exists
          const { data: existing } = await supabase
            .from("system_settings")
            .select("id")
            .eq("setting_key", "ad_post_rules")
            .maybeSingle();

          if (existing) {
            await supabase
              .from("system_settings")
              .update({
                setting_value: rules,
                updated_at: new Date().toISOString(),
              })
              .eq("setting_key", "ad_post_rules");
          } else {
            await supabase
              .from("system_settings")
              .insert([
                {
                  setting_key: "ad_post_rules",
                  setting_value: rules,
                  updated_at: new Date().toISOString(),
                },
              ]);
          }
        } catch (e: any) {
          console.warn(
            "Supabase system_settings upsert/update failed for ad_post_rules, saving locally:",
            e,
          );
        }
      }

      // Also save to local store as fallback
      const store = getDataStore();
      store.ad_post_rules = rules;
      saveDataStore(store);

      res.json({ success: true, setting_value: rules });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Referral System Routes
  app.post("/api/job/edit", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader) return res.status(401).json({ error: "No auth header" });
      const token = authHeader.replace(/^Bearer /i, "");
      const authRes = await supabase.auth.getUser(token);
      let user = authRes.data?.user;

      if (!user) {
        try {
          const base64Url = token.split(".")[1];
          const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
          const buf = Buffer.from(base64, "base64");
          const payload = JSON.parse(buf.toString());
          if (payload && payload.sub) {
            user = { id: payload.sub } as any;
          }
        } catch (e) {}
      }

      if (!user) return res.status(401).json({ error: "Unauthorized" });

      const { jobId, title, description, newPricePerWork, newMaxWorkers } =
        req.body;

      if (
        !jobId ||
        !title ||
        !description ||
        newPricePerWork === undefined ||
        newMaxWorkers === undefined
      ) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      // Fetch config
      const { data: configSnap } = await supabase
        .from("system_configuration")
        .select("job_posting_fee")
        .eq("id", 1)
        .maybeSingle();
      const jobFeePercent = configSnap?.job_posting_fee || 10;

      // Fetch existing job
      const { data: job, error: jobErr } = await supabase
        .from("jobs")
        .select("*")
        .eq("id", jobId)
        .single();
      if (jobErr || !job) {
        return res.status(404).json({ error: "Job not found" });
      }

      if (job.author_id !== user.id) {
        return res
          .status(403)
          .json({ error: "You are not the author of this job" });
      }

      const oldPrice = Number(job.reward);
      const oldWorkers = Number(job.slots);
      const newPrice = Number(newPricePerWork);
      const newWorkers = Number(newMaxWorkers);

      if (newPrice < oldPrice) {
        return res
          .status(400)
          .json({ error: "You can only increase the price per work" });
      }
      if (newWorkers < oldWorkers) {
        return res
          .status(400)
          .json({ error: "You can only increase the number of workers" });
      }

      const oldTotalCost = oldPrice * oldWorkers;
      const newTotalCost = newPrice * newWorkers;
      const extraCost = newTotalCost - oldTotalCost;
      const extraFee = extraCost * (jobFeePercent / 100);
      const extraGrandTotal = extraCost + extraFee;

      // Check balance if extraGrandTotal > 0
      if (extraGrandTotal > 0) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("depositBalance, heldBalance")
          .eq("id", user.id)
          .single();
        if (!profile)
          return res.status(404).json({ error: "Profile not found" });

        if (Number(profile.depositBalance) < extraGrandTotal) {
          return res
            .status(400)
            .json({
              error: `You need ${extraGrandTotal.toFixed(2)} BDT additional deposit balance.`,
            });
        }

        // Deduct from deposit balance and add to held balance
        const { error: profileErr } = await supabase
          .from("profiles")
          .update({
            depositBalance: Number(profile.depositBalance) - extraGrandTotal,
            heldBalance: Number(profile.heldBalance) + extraCost,
          })
          .eq("id", user.id);

        if (profileErr) {
          return res
            .status(500)
            .json({ error: "Failed to update wallet balance" });
        }
      }

      // Update category details
      let categoryData: any = {};
      try {
        if (job.category) categoryData = JSON.parse(job.category);
      } catch (e) {}

      const updatedCategory = {
        ...categoryData,
        pricePerWork: newPrice,
        maxWorkers: newWorkers,
        totalBudget: newTotalCost,
        serviceCharge: newTotalCost * (jobFeePercent / 100),
        grandTotal: newTotalCost + newTotalCost * (jobFeePercent / 100),
      };

      let newStatus = job.status;
      if (
        (job.status === "completed" || job.status === "full") &&
        newWorkers > oldWorkers
      ) {
        const { count: approvedCount } = await supabase
          .from("submissions")
          .select("*", { count: "exact", head: true })
          .eq("job_id", jobId)
          .eq("status", "approved");
        const finalApproved = approvedCount || 0;
        if (newWorkers > finalApproved) {
          newStatus = "open";
        }
      }

      // Update job
      const { error: updateErr } = await supabase
        .from("jobs")
        .update({
          title: title,
          description: description,
          reward: newPrice,
          slots: newWorkers,
          status: newStatus,
          category: JSON.stringify(updatedCategory),
        })
        .eq("id", jobId);

      if (updateErr) {
        return res.status(500).json({ error: "Failed to update job" });
      }

      const actor = await lookupProfileForTelegram(user.id);
      void dispatchTelegramEvent("job_edit", {
        user: actor?.displayName || "Poster",
        serial: actor?.serialNumber || user.id,
        jobTitle: title,
        jobId,
        details: `Reward: ${oldPrice} -> ${newPrice} BDT | Slots: ${oldWorkers} -> ${newWorkers}${extraGrandTotal > 0 ? ` | Added Budget: ${extraGrandTotal.toFixed(2)} BDT` : ""}`,
      });

      res.status(200).json({ status: "success" });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/dashboard-stats", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader) return res.status(401).json({ error: "No auth" });
      const token = authHeader.replace(/^Bearer /i, "");
      const authRes = await supabase.auth.getUser(token);
      let user = authRes.data?.user;

      if (!user) {
        try {
          const base64Url = token.split(".")[1];
          const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
          const buf = Buffer.from(base64, "base64");
          const payload = JSON.parse(buf.toString());
          if (payload && payload.sub) {
            user = { id: payload.sub } as any;
          }
        } catch (e) {}
      }

      if (!user) return res.status(401).json({ error: "Unauthorized" });

      const { data: userSubs, error } = await supabase
        .from("submissions")
        .select("proof, status")
        .eq("worker_id", user.id);

      if (error) throw error;

      let jobsCompleted = 0;
      let totalRevenue = 0;
      let auditPending = 0;

      for (const sub of userSubs || []) {
        if (sub.status === "approved") {
          jobsCompleted++;
          let reward = 0;
          if (sub.proof) {
            try {
              const p = JSON.parse(sub.proof);
              if (p.reward) reward = Number(p.reward);
            } catch (err) {}
          }
          totalRevenue += reward;
        } else if (sub.status === "pending") {
          auditPending++;
        }
      }

      res.json({
        jobsCompleted,
        totalRevenue,
        auditPending,
        activeQueues: 0,
      });
    } catch (err: any) {
      console.error("dashboard-stats error:", err);
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/security/ip-check", async (req, res) => {
    try {
      let ip = req.headers["x-forwarded-for"] || req.ip;
      if (typeof ip === "string") {
        ip = ip.split(",")[0].trim();
      }
      if (!ip || ip === "::1" || ip === "127.0.0.1") {
         return res.json({ ip: "127.0.0.1", vpn: false, ok: true });
      }
      const response = await fetch(`http://ip-api.com/json/${ip}?fields=status,message,proxy,hosting,query`);
      const data = await response.json();
      if (data && data.status === "success") {
        const isVpn = data.proxy === true || data.hosting === true;
        return res.json({ ip: data.query, vpn: isVpn, ok: true });
      }
      res.json({ ip, vpn: false, ok: false });
    } catch(e) {
      let ip = req.headers["x-forwarded-for"] || req.ip;
      if (typeof ip === "string") ip = ip.split(",")[0].trim();
      res.json({ ip, vpn: false, ok: false });
    }
  });

  app.post("/api/security/record-ip", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader) return res.status(401).json({ error: "Unauthorized" });
      const token = authHeader.replace(/^Bearer /i, "").trim();
      const { data: authData, error: authErr } = await supabase.auth.getUser(token);
      const authUser = authData?.user;
      if (authErr || !authUser) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const { event, ip: bodyIp, fingerprint } = req.body || {};
      const eventType: "registration" | "login" | "session" =
        event === "registration" ? "registration" : event === "login" ? "login" : "session";
      const clientIp = extractClientIp(req, bodyIp);
      const userAgent = req.headers["user-agent"] || "";

      const recorded = await recordUserIpEvent(
        authUser.id,
        eventType,
        clientIp,
        typeof fingerprint === "string" ? fingerprint : undefined,
        typeof userAgent === "string" ? userAgent : "",
      );

      if (eventType === "login") {
        const actor = await lookupProfileForTelegram(authUser.id);
        const geo = recorded?.geo;
        const locStr = [geo?.city, geo?.country].filter(Boolean).join(", ");
        const detailsParts = [];
        if (locStr) detailsParts.push(`Location: ${locStr}`);
        if (geo?.isp) detailsParts.push(`ISP: ${geo.isp}`);
        if (geo?.isVpn) detailsParts.push(`VPN/Proxy Detected`);

        void dispatchTelegramEvent("login", {
          user: actor?.displayName || authUser.email || "User",
          serial: actor?.serialNumber || authUser.id,
          email: actor?.email || authUser.email || "N/A",
          ip: clientIp,
          details: detailsParts.length > 0 ? detailsParts.join(" | ") : "Standard account login",
        });
      }

      return res.json({ success: true, ip: clientIp });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/admin/ip-details/:userId", async (req, res) => {
    try {
      const adminUser = await verifyStrictAdmin(req);
      if (!adminUser) {
        return res.status(403).json({ error: "Admin authorization required" });
      }
      const targetUserId = String(req.params.userId || "").trim();
      if (!targetUserId) {
        return res.status(400).json({ error: "Missing userId" });
      }

      const { data: targetProfile, error: profErr } = await supabase
        .from("profiles")
        .select("id, displayName, username, email, phone, serialNumber, last_ip_address, device_fingerprint, account_status, isBlocked, createdAt")
        .eq("id", targetUserId)
        .maybeSingle();

      if (profErr || !targetProfile) {
        return res.status(404).json({ error: "User not found" });
      }

      const logs = await loadUserIpLogs();
      const userIpLog = logs[targetUserId] || null;

      const ipsToMatch = new Set<string>();
      if (targetProfile.last_ip_address && targetProfile.last_ip_address !== "N/A") {
        ipsToMatch.add(targetProfile.last_ip_address);
      }
      if (userIpLog?.registrationIp) ipsToMatch.add(userIpLog.registrationIp);
      if (userIpLog?.lastLoginIp) ipsToMatch.add(userIpLog.lastLoginIp);

      let matchedAccounts: any[] = [];
      if (ipsToMatch.size > 0) {
        const ipList = Array.from(ipsToMatch);
        const { data: matches } = await supabase
          .from("profiles")
          .select("id, displayName, username, email, serialNumber, last_ip_address, isBlocked, account_status")
          .in("last_ip_address", ipList)
          .neq("id", targetUserId)
          .limit(25);
        if (matches) {
          matchedAccounts = matches;
        }
      }

      let liveGeo = null;
      if (targetProfile.last_ip_address && !userIpLog?.lastLoginMeta?.country) {
        liveGeo = await lookupIpGeoInfo(targetProfile.last_ip_address);
      }

      return res.json({
        profile: targetProfile,
        ipLog: userIpLog,
        liveGeo,
        matchedAccounts,
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/admin/telegram/settings", async (req, res) => {
    try {
      const adminUser = await verifyStrictAdmin(req);
      if (!adminUser) {
        return res.status(403).json({ error: "Admin authorization required" });
      }
      const settings = getTelegramSettings();
      return res.json({
        settings,
        defaultTemplates: DEFAULT_TELEGRAM_TOPIC_TEMPLATES,
        envFallbackConfigured: Boolean(
          process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID,
        ),
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.put("/api/admin/telegram/settings", async (req, res) => {
    try {
      const adminUser = await verifyStrictAdmin(req);
      if (!adminUser) {
        return res.status(403).json({ error: "Admin authorization required" });
      }
      const incoming = req.body?.settings;
      if (!incoming || typeof incoming !== "object") {
        return res.status(400).json({ error: "Invalid settings payload" });
      }
      const saved = await saveTelegramSettings(incoming);
      return res.json({ success: true, settings: saved });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/admin/telegram/test", async (req, res) => {
    try {
      const adminUser = await verifyStrictAdmin(req);
      if (!adminUser) {
        return res.status(403).json({ error: "Admin authorization required" });
      }
      const { botToken, chatId, threadId, topic } = req.body || {};
      if (typeof botToken !== "string" || (!chatId && chatId !== 0)) {
        return res.status(400).json({ error: "Bot Token and Chat ID are required" });
      }

      const topicKey: TelegramTopicKey = TELEGRAM_TOPIC_KEYS.includes(topic)
        ? topic
        : "deposit";
      const settings = getTelegramSettings();
      const customTpl = settings.topics?.[topicKey]?.customTemplate || "";

      const sampleText =
        topic && TELEGRAM_TOPIC_KEYS.includes(topic)
          ? renderTelegramTemplate(topicKey, customTpl, {
              user: "Test User",
              serial: "11111",
              email: "test@example.com",
              phone: "01700000000",
              amount: "500",
              netAmount: "450",
              fee: "50",
              method: "bKash",
              trxId: "TEST123456",
              jobTitle: "Sample Microjob",
              jobId: "JOB-TEST",
              subject: "Test Support Ticket",
              message: "This is a test message from Admin Panel.",
              sender: "Admin",
              status: "active",
              details: "Telegram bot connection verified successfully",
              code: "TESTCODE",
            })
          : `✅ <b>AH Task Pay Telegram Test</b>\n\nBot connection verified by Admin (${escapeTelegramHtml(adminUser.email || "Admin")}).`;

      const result = await sendTelegramApiMessage(
        String(botToken),
        String(chatId),
        sampleText,
        threadId ? String(threadId) : undefined,
      );
      if (!result.ok) {
        return res.status(400).json({ error: result.error || "Telegram test failed" });
      }
      return res.json({ success: true, message: "Test message sent successfully!" });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/telegram/event", async (req, res) => {
    try {
      const { topic, data } = req.body || {};
      if (
        !topic ||
        !["registration", "profile_update", "balance_transfer"].includes(topic)
      ) {
        return res.status(400).json({ error: "Unsupported Telegram event topic" });
      }

      const payload = data && typeof data === "object" ? data : {};

      if (topic === "registration") {
        const regUserId = typeof payload.userId === "string" ? payload.userId.trim() : "";
        if (!regUserId || notifiedRegistrations.has(regUserId)) {
          return res.json({ success: true });
        }

        let verifiedEmail = "";
        let verifiedName = "";
        let verifiedPhone = "";

        try {
          const { data: authUserRes } = await supabase.auth.admin.getUserById(regUserId);
          if (authUserRes?.user) {
            const createdMs = Date.parse(authUserRes.user.created_at || "");
            if (!isNaN(createdMs) && Date.now() - createdMs > 10 * 60 * 1000) {
              return res.status(403).json({ error: "Registration window expired" });
            }
            verifiedEmail = authUserRes.user.email || "";
            verifiedName =
              authUserRes.user.user_metadata?.full_name ||
              authUserRes.user.user_metadata?.username ||
              "";
            verifiedPhone = authUserRes.user.user_metadata?.phone || "";
          }
        } catch {}

        const profileRow = await lookupProfileForTelegram(regUserId);
        if (!verifiedEmail && !profileRow) {
          return res.status(404).json({ error: "Registered account not found" });
        }

        if (notifiedRegistrations.size > 500) {
          notifiedRegistrations.clear();
        }
        notifiedRegistrations.add(regUserId);

        const regIp = extractClientIp(req, payload.ip);
        const userAgent = typeof req.headers["user-agent"] === "string" ? req.headers["user-agent"] : "";
        const regRec = await recordUserIpEvent(
          regUserId,
          "registration",
          regIp,
          typeof payload.fingerprint === "string" ? payload.fingerprint : undefined,
          userAgent,
        );
        const locStr = [regRec?.geo?.city, regRec?.geo?.country].filter(Boolean).join(", ");
        const extraDetails = [
          `Username: ${profileRow?.username || payload.username || "N/A"}`,
          payload.referredBy ? `Referred By: ${payload.referredBy}` : "",
          locStr ? `Location: ${locStr}` : "",
        ]
          .filter(Boolean)
          .join(" | ");

        void dispatchTelegramEvent("registration", {
          user:
            profileRow?.displayName ||
            verifiedName ||
            (typeof payload.user === "string" ? payload.user : "New User"),
          serial: profileRow?.serialNumber || regUserId,
          email: profileRow?.email || verifiedEmail || "N/A",
          phone: profileRow?.phone || verifiedPhone || "N/A",
          ip: regIp,
          details: extraDetails,
        });

        return res.json({ success: true });
      }

      const authHeader = req.headers.authorization;
      if (!authHeader) return res.status(401).json({ error: "Unauthorized" });
      const token = authHeader.replace(/^Bearer /i, "").trim();
      const { data: authData, error: authErr } = await supabase.auth.getUser(token);
      const authUser = authData?.user;
      if (authErr || !authUser) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const actor = await lookupProfileForTelegram(authUser.id);
      if (topic === "profile_update") {
        void dispatchTelegramEvent("profile_update", {
          user: actor?.displayName || authUser.email || "User",
          serial: actor?.serialNumber || authUser.id,
          email: actor?.email || authUser.email || "N/A",
          details:
            typeof payload.details === "string" && payload.details.trim()
              ? payload.details.trim().slice(0, 200)
              : "Account settings updated",
        });
      } else if (topic === "balance_transfer") {
        void dispatchTelegramEvent("balance_transfer", {
          user: actor?.displayName || authUser.email || "User",
          serial: actor?.serialNumber || authUser.id,
          amount: Number(payload.amount || 0),
          netAmount: Number(payload.netAmount || payload.amount || 0),
          details:
            typeof payload.details === "string"
              ? payload.details.slice(0, 200)
              : "Wallet transfer",
        });
      }

      return res.json({ success: true });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // Account Info Change Requests (Email, Phone Number, Username)
  const loadAccountChangeRequests = async (): Promise<any[]> => {
    const store = getDataStore();
    if (Array.isArray(store.accountChangeRequests)) {
      return store.accountChangeRequests;
    }
    try {
      const { data: row } = await supabase
        .from("system_settings")
        .select("setting_value")
        .eq("setting_key", "account_change_requests")
        .maybeSingle();
      if (row?.setting_value) {
        const parsed = JSON.parse(row.setting_value);
        if (Array.isArray(parsed)) {
          store.accountChangeRequests = parsed;
          saveDataStore(store);
          return parsed;
        }
      }
    } catch {}
    return [];
  };

  const saveAccountChangeRequests = async (requests: any[]) => {
    const trimmed = requests.slice(0, 1000);
    const store = getDataStore();
    store.accountChangeRequests = trimmed;
    saveDataStore(store);
    await syncSetting("account_change_requests", JSON.stringify(trimmed));
  };

  app.get("/api/account/change-requests", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader) return res.status(401).json({ error: "Unauthorized" });
      const token = authHeader.replace(/^Bearer /i, "").trim();
      const { data: authData, error: authErr } = await supabase.auth.getUser(token);
      const authUser = authData?.user;
      if (authErr || !authUser) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const all = await loadAccountChangeRequests();
      const mine = all
        .filter((r: any) => r.userId === authUser.id)
        .sort(
          (a: any, b: any) =>
            new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime(),
        );
      return res.json({ requests: mine });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/account/change-request", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader) return res.status(401).json({ error: "Unauthorized" });
      const token = authHeader.replace(/^Bearer /i, "").trim();
      const { data: authData, error: authErr } = await supabase.auth.getUser(token);
      const authUser = authData?.user;
      if (authErr || !authUser) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const { type, newValue, reason } = req.body || {};
      if (!["email", "phone", "username"].includes(type)) {
        return res.status(400).json({ error: "Invalid request type" });
      }

      const rawVal = typeof newValue === "string" ? newValue.trim() : "";
      const cleanReason = typeof reason === "string" ? reason.trim().slice(0, 500) : "";

      if (!rawVal) {
        return res.status(400).json({ error: "Please enter a new value" });
      }
      if (!cleanReason) {
        return res.status(400).json({ error: "Please provide a reason for this change" });
      }

      const { data: profileRow, error: profileErr } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", authUser.id)
        .single();
      if (profileErr || !profileRow) {
        return res.status(404).json({ error: "User profile not found" });
      }

      let normalizedVal = rawVal;
      if (type === "email") {
        normalizedVal = rawVal.toLowerCase();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedVal)) {
          return res.status(400).json({ error: "Please enter a valid email address" });
        }
        if ((profileRow.email || authUser.email || "").toLowerCase() === normalizedVal) {
          return res.status(400).json({ error: "New email must be different from your current email" });
        }
        const { data: existingEmail } = await supabase
          .from("profiles")
          .select("id")
          .ilike("email", normalizedVal)
          .neq("id", authUser.id)
          .limit(1);
        if (existingEmail && existingEmail.length > 0) {
          return res.status(400).json({ error: "This email address is already registered to another account" });
        }
      } else if (type === "phone") {
        normalizedVal = rawVal.replace(/\s+/g, "");
        if (!/^[+0-9-]{6,20}$/.test(normalizedVal)) {
          return res.status(400).json({ error: "Please enter a valid phone number" });
        }
        if ((profileRow.phone || "").replace(/\s+/g, "") === normalizedVal) {
          return res.status(400).json({ error: "New phone number must be different from your current number" });
        }
        const { data: existingPhone } = await supabase
          .from("profiles")
          .select("id")
          .eq("phone", normalizedVal)
          .neq("id", authUser.id)
          .limit(1);
        if (existingPhone && existingPhone.length > 0) {
          return res.status(400).json({ error: "This phone number is already registered to another account" });
        }
      } else if (type === "username") {
        normalizedVal = rawVal.replace(/^@+/, "");
        if (!/^[a-zA-Z0-9_.-]{3,30}$/.test(normalizedVal)) {
          return res.status(400).json({
            error: "Username must be 3-30 characters (letters, numbers, _, ., - only, no spaces)",
          });
        }
        if ((profileRow.username || "").toLowerCase() === normalizedVal.toLowerCase()) {
          return res.status(400).json({ error: "New username must be different from your current username" });
        }
        const { data: existingUsername } = await supabase
          .from("profiles")
          .select("id")
          .ilike("username", normalizedVal)
          .neq("id", authUser.id)
          .limit(1);
        if (existingUsername && existingUsername.length > 0) {
          return res.status(400).json({ error: "This username is already taken" });
        }
      }

      const allRequests = await loadAccountChangeRequests();
      const hasPendingSame = allRequests.some(
        (r: any) => r.userId === authUser.id && r.type === type && r.status === "pending",
      );
      if (hasPendingSame) {
        return res.status(400).json({
          error: `You already have a pending ${type} change request. Please wait for admin review.`,
        });
      }

      const newRequest = {
        id: `acr_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        userId: authUser.id,
        userSerial: profileRow.serialNumber || null,
        displayName: profileRow.displayName || profileRow.name || authUser.email || "User",
        currentEmail: profileRow.email || authUser.email || "",
        currentPhone: profileRow.phone || "",
        currentUsername: profileRow.username || "",
        type,
        newValue: normalizedVal,
        reason: cleanReason,
        status: "pending",
        createdAt: new Date().toISOString(),
      };

      const nextList = [newRequest, ...allRequests];
      await saveAccountChangeRequests(nextList);

      const typeLabel =
        type === "email"
          ? "Email Change Request"
          : type === "phone"
            ? "Phone Number Change Request"
            : "Username Change Request";
      const oldValue =
        type === "email"
          ? newRequest.currentEmail
          : type === "phone"
            ? newRequest.currentPhone
            : newRequest.currentUsername;

      void dispatchTelegramEvent("profile_update", {
        user: newRequest.displayName,
        serial: newRequest.userSerial || authUser.id,
        email: newRequest.currentEmail || "N/A",
        ip: extractClientIp(req),
        details: `${typeLabel}: ${oldValue || "N/A"} -> ${newRequest.newValue} | Reason: ${cleanReason}`,
      });

      return res.json({ success: true, request: newRequest });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/admin/account-change-requests/review", async (req, res) => {
    try {
      const adminUser = await verifyStrictAdmin(req);
      if (!adminUser) {
        return res.status(403).json({ error: "Admin authorization required" });
      }

      const { requestId, action, adminNote } = req.body || {};
      if (!requestId || !["approve", "reject"].includes(action)) {
        return res.status(400).json({ error: "Invalid requestId or action" });
      }

      const allRequests = await loadAccountChangeRequests();
      const idx = allRequests.findIndex((r: any) => r.id === requestId);
      if (idx === -1) {
        return res.status(404).json({ error: "Request not found" });
      }
      const reqItem = allRequests[idx];
      if (reqItem.status !== "pending") {
        return res.status(400).json({ error: "This request has already been reviewed" });
      }

      const cleanNote = typeof adminNote === "string" ? adminNote.trim().slice(0, 300) : "";

      if (action === "approve") {
        const { data: targetProfile, error: profErr } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", reqItem.userId)
          .single();
        if (profErr || !targetProfile) {
          return res.status(404).json({ error: "Target user profile not found" });
        }

        if (reqItem.type === "email") {
          const isServiceKeyMissing =
            !process.env.SUPABASE_SERVICE_KEY && !process.env.SUPABASE_SERVICE_ROLE_KEY;
          if (isServiceKeyMissing) {
            return res.status(400).json({
              error: "SUPABASE_SERVICE_ROLE_KEY is required to update user login email.",
            });
          }
          const { error: authErr } = await supabase.auth.admin.updateUserById(reqItem.userId, {
            email: reqItem.newValue,
            email_confirm: true,
          });
          if (authErr) {
            return res.status(400).json({ error: `Failed to update Auth email: ${authErr.message}` });
          }
          const { error: dbErr } = await supabase
            .from("profiles")
            .update({ email: reqItem.newValue })
            .eq("id", reqItem.userId);
          if (dbErr) {
            return res.status(400).json({ error: `Failed to update profile email: ${dbErr.message}` });
          }
        } else if (reqItem.type === "phone") {
          const { error: dbErr } = await supabase
            .from("profiles")
            .update({ phone: reqItem.newValue })
            .eq("id", reqItem.userId);
          if (dbErr) {
            return res.status(400).json({ error: `Failed to update phone number: ${dbErr.message}` });
          }
        } else if (reqItem.type === "username") {
          const { error: dbErr } = await supabase
            .from("profiles")
            .update({ username: reqItem.newValue })
            .eq("id", reqItem.userId);
          if (dbErr) {
            return res.status(400).json({ error: `Failed to update username: ${dbErr.message}` });
          }
          try {
            const { data: existingAuth } = await supabase.auth.admin.getUserById(reqItem.userId);
            await supabase.auth.admin.updateUserById(reqItem.userId, {
              user_metadata: {
                ...(existingAuth?.user?.user_metadata || {}),
                username: reqItem.newValue,
              },
            });
          } catch {}
        }

        const typeLabelMap: Record<string, string> = {
          email: "ইমেইল",
          phone: "ফোন নম্বর",
          username: "ইউজারনেম",
        };
        const typeLabel = typeLabelMap[reqItem.type] || reqItem.type;

        // Send in-app notification
        await pushInAppNotification(
          reqItem.userId,
          `আপনার ${typeLabel} পরিবর্তনের আবেদন (${reqItem.newValue}) এপ্রুভ ও আপডেট করা হয়েছে।`,
          "approved",
        );

        void dispatchTelegramEvent("profile_update", {
          user: targetProfile.displayName || reqItem.displayName || "User",
          serial: targetProfile.serialNumber || reqItem.userSerial || reqItem.userId,
          email: reqItem.type === "email" ? reqItem.newValue : targetProfile.email || "N/A",
          ip: targetProfile.last_ip_address || "N/A",
          details: `Admin approved ${reqItem.type} change -> ${reqItem.newValue}`,
        });
      } else {
        // Reject: notify user
        try {
          const typeLabelMap: Record<string, string> = {
            email: "ইমেইল",
            phone: "ফোন নম্বর",
            username: "ইউজারনেম",
          };
          const typeLabel = typeLabelMap[reqItem.type] || reqItem.type;
          await pushInAppNotification(
            reqItem.userId,
            `আপনার ${typeLabel} পরিবর্তনের আবেদন (${reqItem.newValue}) রিজেক্ট করা হয়েছে।${cleanNote ? ` কারণ: ${cleanNote}` : ""}`,
            "rejected",
          );

          const { data: targetProfile } = await supabase
            .from("profiles")
            .select("displayName, email, serialNumber, last_ip_address")
            .eq("id", reqItem.userId)
            .maybeSingle();
          if (targetProfile) {
            void dispatchTelegramEvent("profile_update", {
              user: targetProfile.displayName || reqItem.displayName || "User",
              serial: targetProfile.serialNumber || reqItem.userSerial || reqItem.userId,
              email: targetProfile.email || "N/A",
              ip: targetProfile.last_ip_address || "N/A",
              details: `Admin rejected ${reqItem.type} change (${reqItem.newValue})${cleanNote ? ` | Note: ${cleanNote}` : ""}`,
            });
          }
        } catch {}
      }

      const updatedItem = {
        ...reqItem,
        status: action === "approve" ? "approved" : "rejected",
        adminNote: cleanNote || undefined,
        reviewedAt: new Date().toISOString(),
      };
      const nextList = [...allRequests];
      nextList[idx] = updatedItem;
      await saveAccountChangeRequests(nextList);

      return res.json({ success: true, request: updatedItem });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/referral/register", async (req, res) => {
    const origJson = res.json.bind(res);
    res.json = ((body: any) => {
      if (res.statusCode < 400 && body && !body.error) {
        void dispatchTelegramEvent("referral", {
          user: req.body?.newUserId || "New User",
          serial: req.body?.referrerCode || "N/A",
          details: `New referral linked using code ${req.body?.referrerCode || "N/A"}`,
        });
      }
      return origJson(body);
    }) as any;
    return registerReferral(req, res);
  });
  app.get("/api/referral/status", async (req, res) =>
    getReferralStatus(req, res),
  );
  app.post("/api/referral/claim", async (req, res) => {
    const origJson = res.json.bind(res);
    res.json = ((body: any) => {
      if (res.statusCode < 400 && body && !body.error) {
        void dispatchTelegramEvent("referral", {
          user: req.body?.userId || "User",
          serial: req.body?.userId || "N/A",
          details: `Referral reward claimed (${body.reward || body.amount || "bonus"} BDT)`,
        });
      }
      return origJson(body);
    }) as any;
    return claimReferralReward(req, res);
  });
  app.post("/api/admin/reset-referral-claims", async (req, res) =>
    resetAllReferralClaims(req, res),
  );
  app.post("/api/referral/reset-claims", async (req, res) =>
    resetAllReferralClaims(req, res),
  );

  app.get("/api/ping", (req, res) => {
    res.status(200).json({ status: "ok", timestamp: Date.now() });
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);

    // Run expired proof-image cleanup shortly after startup, then hourly
    setTimeout(() => {
      cleanupExpiredSubmissionImages()
        .then((count) => {
          if (count > 0) {
            console.log(`Auto-deleted proof images for ${count} reviewed submissions (24h retention).`);
          }
        })
        .catch(console.error);
    }, 15000);

    // Background task to expire old referrals and clean up 24h-old reviewed proof images
    setInterval(
      async () => {
        try {
          const now = new Date().toISOString();
          const { error } = await supabase
            .from("referrals")
            .update({ status: "expired" })
            .eq("status", "pending")
            .not("expiration_date", "is", null)
            .lt("expiration_date", now);
          if (error) console.error("Error expiring referrals:", error);
        } catch (err) {
          console.error("Interval error expiring referrals:", err);
        }

        try {
          const count = await cleanupExpiredSubmissionImages();
          if (count > 0) {
            console.log(`Hourly cleanup: deleted proof images for ${count} reviewed submissions.`);
          }
        } catch (err) {
          console.error("Interval error cleaning up images:", err);
        }
      },
      1000 * 60 * 60,
    ); // Check every hour
  });
}
startServer();
