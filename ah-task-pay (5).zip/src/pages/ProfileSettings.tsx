import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { User, Lock, ShieldCheck, Key, ArrowLeft, CheckCircle2, AlertTriangle, X, BellRing } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { askNotificationPermission } from '../lib/pushNotifications';

export default function ProfileSettings() {
  const { profile, user } = useAuth();
  const navigate = useNavigate();
  
  const [name, setName] = useState(profile?.displayName || '');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showDeletionModal, setShowDeletionModal] = useState(false);
  const [deletionReason, setDeletionReason] = useState('');
  const [deletionLoading, setDeletionLoading] = useState(false);

  const handleUpdateName = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    setError('');
    setSuccess('');
    
    try {
      await supabase.from('profiles').update({ displayName: name }).eq('id', user.id);
      setSuccess('Profile name updated successfully!');
    } catch (err: any) {
      setError(err.message || 'Failed to update name');
    } finally {
      setLoading(false);
    }
  };

  const handleRequestDeletion = async () => {
    if (!user) return;
    if (!deletionReason.trim()) {
       setError('Please provide a reason for deletion');
       return;
    }
    setDeletionLoading(true);
    setError('');
    
    try {
       await supabase.from('profiles').update({
          account_status: 'pending_deletion',
          deletion_reason: deletionReason
       }).eq('id', user.id);
       
       setSuccess('Your account deletion request has been submitted and is pending admin approval.');
       setShowDeletionModal(false);
    } catch(err: any) {
       setError(err.message || 'Failed to request deletion');
    } finally {
       setDeletionLoading(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setError('New passwords do not match');
      return;
    }
    
    setLoading(true);
    setError('');
    setSuccess('');
    
    try {
      // With Supabase, changing password while logged in just requires calling updateUser
      // Supabase's auth.updateUser doesn't strictly verify old password client-side, 
      // but it requires a valid session.
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });
      if (error) throw error;
      
      setSuccess('Password changed successfully!');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      setError(err.message || 'Failed to change password. Please re-login if issues persist.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4">
        <button 
          onClick={() => navigate(-1)}
          className="bg-white dark:bg-slate-800 p-3 rounded-2xl text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 shadow-sm border border-gray-100 dark:border-slate-700 transition-all"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div>
          <h1 className="text-3xl font-black text-gray-900 dark:text-slate-100 tracking-tight uppercase">Profile Settings</h1>
          <p className="text-gray-500 dark:text-slate-400 font-medium">Manage your personal information and security.</p>
        </div>
      </div>

      {(error || success) && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-2xl border font-bold text-sm ${
            error ? 'bg-red-50 dark:bg-red-950/20 border-red-100 dark:border-red-900/50 text-red-600 dark:text-red-400' : 'bg-green-50 dark:bg-green-950/20 border-green-100 dark:border-green-900/50 text-green-600 dark:text-green-400'
          }`}
        >
          {error || success}
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Name Update */}
        <section className="bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] border border-gray-100 dark:border-slate-700 shadow-sm space-y-6 transition-colors">
          <div className="flex items-center gap-3">
             <div className="bg-blue-50 dark:bg-blue-950/30 p-2 rounded-xl text-blue-600 dark:text-blue-400">
                <User className="w-6 h-6" />
             </div>
             <h2 className="text-xl font-black text-gray-900 dark:text-slate-100 uppercase">Change Name</h2>
          </div>

          <form onSubmit={handleUpdateName} className="space-y-4">
             <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 dark:text-slate-500 uppercase tracking-widest ml-1">Full Name</label>
                <div className="relative">
                   <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 dark:text-slate-500" />
                   <input 
                      type="text"
                      required
                      value={name}
                      onChange={e => setName(e.target.value)}
                      className="w-full pl-12 pr-4 py-4 bg-gray-50 dark:bg-slate-700 border border-transparent dark:border-slate-600 rounded-2xl focus:ring-2 focus:ring-primary-500 outline-none transition-all font-medium dark:text-white"
                   />
                </div>
             </div>
             <motion.button
                whileTap={{ scale: 0.98 }}
                disabled={loading}
                className="w-full py-4 bg-gray-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black text-sm uppercase tracking-widest shadow-lg shadow-gray-200 dark:shadow-none hover:bg-gray-800 dark:hover:bg-slate-200 disabled:opacity-50 transition-colors"
             >
                {loading ? 'Updating...' : 'Save Name'}
             </motion.button>
          </form>
        </section>

        {/* Password Update */}
        <section className="bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] border border-gray-100 dark:border-slate-700 shadow-sm space-y-6 transition-colors">
          <div className="flex items-center gap-3">
             <div className="bg-orange-50 dark:bg-orange-950/30 p-2 rounded-xl text-orange-600 dark:text-orange-400">
                <Lock className="w-6 h-6" />
             </div>
             <h2 className="text-xl font-black text-gray-900 dark:text-slate-100 uppercase">Security</h2>
          </div>

          <form onSubmit={handleChangePassword} className="space-y-4">
             <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 dark:text-slate-500 uppercase tracking-widest ml-1">New Password</label>
                <input 
                   type="password"
                   required
                   value={newPassword}
                   onChange={e => setNewPassword(e.target.value)}
                   className="w-full px-4 py-4 bg-gray-50 dark:bg-slate-700 border border-transparent dark:border-slate-600 rounded-2xl focus:ring-2 focus:ring-primary-500 outline-none transition-all font-medium dark:text-white"
                />
             </div>
             <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 dark:text-slate-500 uppercase tracking-widest ml-1">Confirm New Password</label>
                <input 
                   type="password"
                   required
                   value={confirmPassword}
                   onChange={e => setConfirmPassword(e.target.value)}
                   className="w-full px-4 py-4 bg-gray-50 dark:bg-slate-700 border border-transparent dark:border-slate-600 rounded-2xl focus:ring-2 focus:ring-primary-500 outline-none transition-all font-medium dark:text-white"
                />
             </div>
             <motion.button
                whileTap={{ scale: 0.98 }}
                disabled={loading}
                className="w-full py-4 bg-primary-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-lg shadow-primary-200 dark:shadow-none hover:bg-primary-700 disabled:opacity-50 transition-colors"
             >
                {loading ? 'Processing...' : 'Update Password'}
             </motion.button>
          </form>
        </section>
      </div>

      <div className="bg-primary-600 p-8 rounded-[2.5rem] text-white flex flex-col md:flex-row items-center justify-between gap-6">
         <div className="flex items-center gap-4">
            <div className="bg-white/20 p-4 rounded-2xl">
               <ShieldCheck className="w-10 h-10" />
            </div>
            <div>
               <h3 className="text-2xl font-black uppercase tracking-tight">Account Safety</h3>
               <p className="text-primary-100 font-medium">Your data is encrypted and saved securely with AH Task Pay.</p>
            </div>
         </div>
         <div className="bg-white/10 px-6 py-3 rounded-full font-bold text-sm">Verified User</div>
      </div>

      <div className="mt-8 bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] border border-gray-100 dark:border-slate-700 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 transition-colors">
         <div className="flex items-center gap-4">
            <div className="bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 p-4 rounded-2xl">
               <BellRing className="w-8 h-8" />
            </div>
            <div>
               <h3 className="text-xl font-black text-gray-900 dark:text-white uppercase tracking-tight">Push Notifications</h3>
               <p className="text-gray-500 dark:text-slate-400 font-medium text-sm">Get real-time updates for approvals and withdrawals on your device.</p>
            </div>
         </div>
         <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={() => user && askNotificationPermission(user.id)}
            className="px-6 py-3 bg-blue-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200 dark:shadow-none whitespace-nowrap"
         >
            Enable Notifications
         </motion.button>
      </div>

      {/* Account Deletion Section */}
      <section className="bg-red-50 dark:bg-red-950/20 p-8 rounded-[2.5rem] border border-red-100 dark:border-red-900/50 shadow-sm space-y-6 transition-colors mt-8">
        <div className="flex items-center gap-3">
           <div className="bg-red-100 dark:bg-red-900/40 p-2 rounded-xl text-red-600 dark:text-red-400">
              <AlertTriangle className="w-6 h-6" />
           </div>
           <h2 className="text-xl font-black text-red-900 dark:text-red-400 uppercase">Danger Zone</h2>
        </div>
        <p className="text-red-700 dark:text-red-300 font-medium text-sm">
          Once your account is deleted, all of your data, balances, and history will be permanently lost. This action cannot be undone.
        </p>
        <motion.button
           whileTap={{ scale: 0.98 }}
           onClick={() => setShowDeletionModal(true)}
           className="px-6 py-3 bg-red-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-red-700 transition-colors shadow-lg shadow-red-200 dark:shadow-none"
        >
           Request Account Deletion
        </motion.button>
      </section>

      {/* Deletion Modal */}
      {showDeletionModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-slate-900 rounded-[2rem] w-full max-w-md p-6 sm:p-8 shadow-2xl border border-gray-100 dark:border-slate-800"
          >
            <div className="flex justify-between items-center mb-6">
               <h3 className="text-xl font-black text-gray-900 dark:text-white flex items-center gap-2">
                 <AlertTriangle className="w-6 h-6 text-red-500" />
                 Delete Account
               </h3>
               <button onClick={() => setShowDeletionModal(false)} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                 <X className="w-5 h-5" />
               </button>
            </div>
            
            <p className="text-sm text-gray-500 dark:text-slate-400 mb-6 font-medium">
              Please enter the reason for requesting account deletion. An administrator will review your request.
            </p>
            
            <textarea
               value={deletionReason}
               onChange={(e) => setDeletionReason(e.target.value)}
               placeholder="Why are you leaving?"
               rows={4}
               className="w-full p-4 mb-6 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-red-500 font-medium text-sm text-gray-900 dark:text-white resize-none"
            ></textarea>
            
            <div className="flex gap-4">
               <button
                  onClick={() => setShowDeletionModal(false)}
                  className="flex-1 py-3 text-sm font-bold text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-slate-800 rounded-xl hover:bg-gray-200 dark:hover:bg-slate-700 transition-colors"
               >
                  Cancel
               </button>
               <button
                  onClick={handleRequestDeletion}
                  disabled={deletionLoading || !deletionReason.trim()}
                  className="flex-1 py-3 text-sm font-bold text-white bg-red-600 rounded-xl hover:bg-red-700 transition-colors disabled:opacity-50"
               >
                  {deletionLoading ? 'Submitting...' : 'Submit Request'}
               </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
