import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { User, Lock, ShieldCheck, Key, ArrowLeft, CheckCircle2, AlertTriangle, X, Mail, Phone } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

export default function ProfileSettings() {
  const { profile, user } = useAuth();
  const navigate = useNavigate();
  
  const [name, setName] = useState(profile?.displayName || '');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showDeletionModal, setShowDeletionModal] = useState(false);
  const [deletionReason, setDeletionReason] = useState('');
  const [deletionLoading, setDeletionLoading] = useState(false);

  const handleUpdateName = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    setError('');
    setSuccess('');
    
    try {
      await supabase.from('profiles').update({ displayName: name }).eq('id', user.id);
      setSuccess('Profile name updated successfully!');
    } catch (err: any) {
      setError(err.message || 'Failed to update name');
    } finally {
      setLoading(false);
    }
  };

  const handleRequestDeletion = async () => {
    if (!user) return;
    if (!deletionReason.trim()) {
       setError('Please provide a reason for deletion');
       return;
    }
    setDeletionLoading(true);
    setError('');
    
    try {
       await supabase.from('profiles').update({
          account_status: 'pending_deletion',
          deletion_reason: deletionReason
       }).eq('id', user.id);
       
       setSuccess('Your account deletion request has been submitted and is pending admin approval.');
       setShowDeletionModal(false);
    } catch(err: any) {
       setError(err.message || 'Failed to request deletion');
    } finally {
       setDeletionLoading(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setError('New passwords do not match');
      return;
    }
    
    setLoading(true);
    setError('');
    setSuccess('');
    
    try {
      // With Supabase, changing password while logged in just requires calling updateUser
      // Supabase's auth.updateUser doesn't strictly verify old password client-side, 
      // but it requires a valid session.
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });
      if (error) throw error;
      
      setSuccess('Password changed successfully!');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      setError(err.message || 'Failed to change password. Please re-login if issues persist.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 pb-12">
      <div className="flex items-center gap-4">
        <button 
          onClick={() => navigate(-1)}
          className="bg-white dark:bg-[#1E293B] p-3 rounded-2xl text-slate-500 dark:text-slate-400 hover:text-[#0B3D9E] dark:hover:text-white shadow-sm border border-slate-200 dark:border-slate-700/80 transition-all"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div>
          <h1 className="text-3xl font-black font-display text-slate-900 dark:text-slate-100 tracking-tight uppercase">Profile Settings</h1>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Manage your personal information and security.</p>
        </div>
      </div>

      {(error || success) && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-2xl border font-bold text-sm ${
            error ? 'bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400' : 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900/50 text-emerald-600 dark:text-emerald-400'
          }`}
        >
          {error || success}
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Personal Details */}
        <section className="bg-white dark:bg-[#1E293B] p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-700/80 shadow-sm space-y-6 transition-colors">
          <div className="flex items-center gap-3">
             <div className="bg-blue-50 dark:bg-blue-950/50 p-2 rounded-xl text-[#0B3D9E] dark:text-blue-400">
                <User className="w-6 h-6" />
             </div>
             <h2 className="text-xl font-black font-display text-slate-900 dark:text-slate-100 uppercase">Personal Details</h2>
          </div>

          <form onSubmit={handleUpdateName} className="space-y-4">
             <div className="space-y-2">
                <label className="text-xs font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
                <div className="relative">
                   <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 dark:text-slate-500" />
                   <input 
                      type="text"
                      required
                      value={name}
                      onChange={e => setName(e.target.value)}
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl focus:ring-2 focus:ring-[#0B3D9E] outline-none transition-all font-medium text-slate-900 dark:text-white"
                   />
                </div>
             </div>

             {/* Registered Email (Read-only) */}
             <div className="space-y-2">
                <div className="flex justify-between items-center ml-1">
                   <label className="text-xs font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">Email Address</label>
                   <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase flex items-center gap-1">
                      <Lock className="w-3 h-3" /> Read Only
                   </span>
                </div>
                <div className="relative">
                   <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 dark:text-slate-500" />
                   <input 
                      type="email"
                      readOnly
                      disabled
                      value={profile?.email || user?.email || 'N/A'}
                      className="w-full pl-12 pr-4 py-4 bg-slate-100/80 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/70 rounded-2xl text-slate-500 dark:text-slate-400 font-medium cursor-not-allowed"
                   />
                </div>
             </div>

             {/* Phone Number (Read-only) */}
             <div className="space-y-2">
                <div className="flex justify-between items-center ml-1">
                   <label className="text-xs font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">Phone Number</label>
                   <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase flex items-center gap-1">
                      <Lock className="w-3 h-3" /> Read Only
                   </span>
                </div>
                <div className="relative">
                   <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 dark:text-slate-500" />
                   <input 
                      type="text"
                      readOnly
                      disabled
                      value={profile?.phone || 'Not provided'}
                      className="w-full pl-12 pr-4 py-4 bg-slate-100/80 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/70 rounded-2xl text-slate-500 dark:text-slate-400 font-medium cursor-not-allowed tabular-nums"
                   />
                </div>
             </div>

             <motion.button
                whileTap={{ scale: 0.98 }}
                disabled={loading}
                className="w-full py-4 bg-[#07266E] hover:bg-[#0B3D9E] text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-lg shadow-blue-900/15 dark:shadow-none disabled:opacity-50 transition-colors mt-2"
             >
                {loading ? 'Updating...' : 'Save Name'}
             </motion.button>
          </form>
        </section>

        {/* Password Update */}
        <section className="bg-white dark:bg-[#1E293B] p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-700/80 shadow-sm space-y-6 transition-colors">
          <div className="flex items-center gap-3">
             <div className="bg-orange-50 dark:bg-orange-950/40 p-2 rounded-xl text-[#F97316] dark:text-[#FB923C]">
                <Lock className="w-6 h-6" />
             </div>
             <h2 className="text-xl font-black font-display text-slate-900 dark:text-slate-100 uppercase">Security</h2>
          </div>

          <form onSubmit={handleChangePassword} className="space-y-4">
             <div className="space-y-2">
                <label className="text-xs font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest ml-1">New Password</label>
                <input 
                   type="password"
                   required
                   value={newPassword}
                   onChange={e => setNewPassword(e.target.value)}
                   className="w-full px-4 py-4 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl focus:ring-2 focus:ring-[#0B3D9E] outline-none transition-all font-medium text-slate-900 dark:text-white"
                />
             </div>
             <div className="space-y-2">
                <label className="text-xs font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest ml-1">Confirm New Password</label>
                <input 
                   type="password"
                   required
                   value={confirmPassword}
                   onChange={e => setConfirmPassword(e.target.value)}
                   className="w-full px-4 py-4 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl focus:ring-2 focus:ring-[#0B3D9E] outline-none transition-all font-medium text-slate-900 dark:text-white"
                />
             </div>
             <motion.button
                whileTap={{ scale: 0.98 }}
                disabled={loading}
                className="w-full py-4 bg-[#F97316] hover:bg-[#EA580C] text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-lg shadow-orange-500/20 dark:shadow-none disabled:opacity-50 transition-colors"
             >
                {loading ? 'Processing...' : 'Update Password'}
             </motion.button>
          </form>
        </section>
      </div>

      <div className="mt-8 bg-gradient-to-br from-[#041645] via-[#07266E] to-[#0B3D9E] p-8 rounded-[2.5rem] text-white flex flex-col md:flex-row items-center justify-between gap-6 border border-blue-800/40 shadow-xl">
         <div className="flex items-center gap-4">
            <div className="bg-white/15 p-4 rounded-2xl border border-white/15">
               <ShieldCheck className="w-10 h-10 text-[#FB923C]" />
            </div>
            <div>
               <h3 className="text-2xl font-black font-display uppercase tracking-tight">Account Safety</h3>
               <p className="text-blue-200 font-medium">Your data is encrypted and saved securely with AH Task Pay.</p>
            </div>
         </div>
         <div className="bg-white/15 border border-white/15 px-6 py-3 rounded-full font-bold text-sm">Verified User</div>
      </div>

      {/* Account Deletion Section */}
      <section className="mt-8 bg-white dark:bg-[#1E293B] p-8 rounded-[2.5rem] border border-red-200 dark:border-red-900/50 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 transition-colors">
         <div className="flex items-center gap-4">
            <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-2xl text-red-600 dark:text-red-400">
               <AlertTriangle className="w-10 h-10" />
            </div>
            <div>
               <h3 className="text-xl font-black font-display text-slate-900 dark:text-white uppercase tracking-tight">Danger Zone</h3>
               <p className="text-slate-500 dark:text-slate-400 font-medium text-sm mt-1">Once deleted, your account data and balances are permanently lost.</p>
            </div>
         </div>
         <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowDeletionModal(true)}
            className="px-6 py-4 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900/50 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-red-100 dark:hover:bg-red-900/40 transition-colors whitespace-nowrap"
         >
            Request Account Deletion
         </motion.button>
      </section>

      {/* Deletion Modal */}
      {showDeletionModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-[#1E293B] rounded-[2rem] w-full max-w-md p-6 sm:p-8 shadow-2xl border border-slate-200 dark:border-slate-700/80"
          >
            <div className="flex justify-between items-center mb-6">
               <h3 className="text-xl font-black font-display text-slate-900 dark:text-white flex items-center gap-2">
                 <AlertTriangle className="w-6 h-6 text-red-500" />
                 Delete Account
               </h3>
               <button onClick={() => setShowDeletionModal(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                 <X className="w-5 h-5" />
               </button>
            </div>
            
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-6 font-medium">
              Please enter the reason for requesting account deletion. An administrator will review your request.
            </p>
            
            <textarea
               value={deletionReason}
               onChange={(e) => setDeletionReason(e.target.value)}
               placeholder="Why are you leaving?"
               rows={4}
               className="w-full p-4 mb-6 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-red-500 font-medium text-sm text-slate-900 dark:text-white resize-none"
            ></textarea>
            
            <div className="flex gap-4">
               <button
                  onClick={() => setShowDeletionModal(false)}
                  className="flex-1 py-3 text-sm font-bold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
               >
                  Cancel
               </button>
               <button
                  onClick={handleRequestDeletion}
                  disabled={deletionLoading || !deletionReason.trim()}
                  className="flex-1 py-3 text-sm font-bold text-white bg-red-600 rounded-xl hover:bg-red-700 transition-colors disabled:opacity-50"
               >
                  {deletionLoading ? 'Submitting...' : 'Submit Request'}
               </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
