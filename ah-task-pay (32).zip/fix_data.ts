import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf-8');
content = content.replace(/data = modifiedData;/g, '');
fs.writeFileSync('server.ts', content);
